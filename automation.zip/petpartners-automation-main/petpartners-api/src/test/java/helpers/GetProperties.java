package helpers;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class GetProperties {
    private static GetProperties getProperties = null;
    private String host;
    private String user;
    private String password;
    private String gatewayUrl;
    private String trustCommerce;
    private String browser;
    private String urlOrcaWeb;
    private String sqlServer;
    private String sqlUser;
    private String sqlPassword;

    private String urlOrcaGroupWeb;

    private boolean isEnabledOrcaMfa;

    private String urlPpiWeb;

    private GetProperties() {
        Properties properties = new Properties();
        String propFileName = System.getProperty("propertyFile") == null ? "qa.properties" : System.getProperty("propertyFile");
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
        if (inputStream != null) {
            try {
                properties.load(inputStream);
                host = properties.getProperty("host");
                user = properties.getProperty("user");
                password = properties.getProperty("password");
                gatewayUrl = properties.getProperty("gatewayUrl");
                trustCommerce = properties.getProperty("trustCommerce");
                browser = properties.getProperty("browser");
                urlOrcaWeb = properties.getProperty("urlOrcaWeb");
                sqlServer = properties.getProperty("sqlServer");
                sqlUser = properties.getProperty("sqlUser");
                sqlPassword = properties.getProperty("sqlPassword");
                urlOrcaGroupWeb = properties.getProperty("urlOrcaGroupWeb");
                isEnabledOrcaMfa = Boolean.parseBoolean(properties.getProperty("isEnabledOrcaMFA"));
                urlPpiWeb = properties.getProperty("urlPPIWeb");
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public static GetProperties getInstance() {
        if (getProperties == null)
            getProperties = new GetProperties();
        return getProperties;
    }

    public String getUrlOrcaGroupWeb() {
        return urlOrcaGroupWeb;
    }

    public String getHost() {
        return host;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public String getGatewayUrl() {
        return gatewayUrl;
    }

    public String getTrustCommerce() {
        return trustCommerce;
    }

    public String getBrowser() {
        return browser;
    }

    public String getUrlOrcaWeb() {
        return urlOrcaWeb;
    }

    public String getSqlServer() {
        return sqlServer;
    }

    public String getSqlUser() {
        return sqlUser;
    }

    public String getSqlPassword() {
        return sqlPassword;
    }

    public boolean isEnabledOrcaMfa() {
        return isEnabledOrcaMfa;
    }

    public String getUrlPpiWeb() {
        return urlPpiWeb;
    }
}
