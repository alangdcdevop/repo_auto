package runner;

import configuration.CommonValues;
import gifBuilder.ScreenShot;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.common.FooterSection;
import runner.stepsOrca.BaseSteps;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class CommonSteps extends BaseSteps {

    FooterSection footerSection = new FooterSection();

    @And("i save random phone number on {}")
    public void iSaveRandomPhoneNumberOnPHONE(String variable) {
        long theRandomNum = (long) (Math.random()*Math.pow(10,10));
        CommonValues.variables.put(variable, "(111) " + String.valueOf(theRandomNum).substring(3,6) + "-" + String.valueOf(theRandomNum).substring(6));
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }


    @Then("verify the message is displayed")
    public void verifyTheSuccessfullyAlertIsDisplayed(String expectedResult) throws Exception {
        String actualResult = alertSection.successfullyAlertLabel.getText();
        expectedResult = this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),
                "ERROR the message is not successfully, actual: [" + actualResult + "] vs expected: [" + expectedResult + "]");
    }

    @When("I get the logged user name on {}")
    public void iGetTheLoggedUserNameOnLoggerUser(String variable) throws Exception {
        String value=footerSection.getUserLogged();
        CommonValues.variables.put(variable,value);
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }

    @And("go to the tab {string}")
    public void goToTheLinkForThePolicyNumber(String tabTitle) throws Exception {
        ScreenShot.addScreen(this.getClass().getName()+"> go to the tab: "+tabTitle);
        Thread.sleep(5000);
        List<String> tabList=new ArrayList<String>(Session.getInstance().getDriver().getWindowHandles());
        Map<String, Integer> titlePositionTab= new HashMap<>();
        Logger.log(Level.INFO,this.getClass().getName()+"> Number of Tabs Open: "+tabList.size());
        for (int i=0;i<tabList.size();i++) {
            Session.getInstance().getDriver().switchTo().window(tabList.get(i));
            titlePositionTab.put(Session.getInstance().getDriver().getTitle(),i);
            Logger.log(Level.INFO,this.getClass().getName()+"> Tab: "+Session.getInstance().getDriver().getTitle());
        }
        if (!titlePositionTab.containsKey(this.replaceConfigurationValues(tabTitle)))
            throw new Exception("The tab name "+this.replaceConfigurationValues(tabTitle)+" does not exist! review if the tab name");

        Session.getInstance().getDriver().switchTo().window(tabList.get(titlePositionTab.get(this.replaceConfigurationValues(tabTitle))));
        Logger.log(Level.INFO,this.getClass().getName()+"> Current Tab Page: "+Session.getInstance().getDriver().getTitle());
        ScreenShot.addScreen(this.getClass().getName()+"> Current Tab Page: "+Session.getInstance().getDriver().getTitle());
    }

    @And("go to the latest tab opened")
    public void goToTheLatestTabOpened() throws InterruptedException {
        ScreenShot.addScreen(this.getClass().getName()+"> go to the new tab opened ");
        Thread.sleep(5000);
        List<String> tabList=new ArrayList<String>(Session.getInstance().getDriver().getWindowHandles());
        Session.getInstance().getDriver().switchTo().window(tabList.get(tabList.size()-1));
        Logger.log(Level.INFO,this.getClass().getName()+"> go to the new tab opened ");
        ScreenShot.addScreen(this.getClass().getName()+"> go to the new tab opened ");
    }
}