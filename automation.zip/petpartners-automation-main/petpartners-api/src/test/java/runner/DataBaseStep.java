package runner;

import configuration.CommonValues;
import helpers.GetProperties;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import utils.Level;
import utils.Logger;
import utils.SqlDBClient;

import java.sql.SQLException;
import java.util.Random;

public class DataBaseStep extends BaseStep {

    SqlDBClient sqlDBClient = new SqlDBClient();

    @And("^I connect to the database \"(orca|group)\" to get the column \"(.*)\" running the next query$")
    public void iConnectToTheDatabaseToRunTheNextQuery(String databaseName,String columnName, String query) throws SQLException, ClassNotFoundException {
        // todo  if we have several DB here add a switch case
        switch (databaseName.toLowerCase()){
            case "orca":
                sqlDBClient.setDataBase("orca");
                break;
            case "group":
                sqlDBClient.setDataBase("group");
                break;
            default:
                sqlDBClient.setDataBase("orca");
                break;

        }


        sqlDBClient .setUser(GetProperties.getInstance().getSqlUser())
                    .setPwd(GetProperties.getInstance().getSqlPassword())
                    .setServer(GetProperties.getInstance().getSqlServer());

        queryResult=sqlDBClient.executeQuery(sqlDBClient.getConnection(), this.replaceConfigurationValues(query),columnName);
    }

    @And("^I get the (first|last|random) value of query result and save on (.*)$")
    public void iGetTheFirstValueOfQueryResultAndSaveOnValue(String criteria, String nameVariable) {

       int position= criteria.contains("first")?
                     0:criteria.contains("last")?queryResult.size()-1:
                       new Random().nextInt(queryResult.size()-1) +1;

        CommonValues.variables.put(nameVariable, queryResult.get(position));
        Logger.log(Level.INFO,this.getClass().getName()+" variable: ["+nameVariable+"] value: ["+CommonValues.variables.get(nameVariable)+"]");
    }

    @And("verify the {} is equal to {}")
    public void verifyTheValueIsEqualToVariable(String  variable, String expectedResult) {
        Logger.log(Level.INFO,this.getClass().getName()+"expected result query: " +this.replaceConfigurationValues(expectedResult)+ " vs actual result: "+this.replaceConfigurationValues(variable));
        Assertions.assertEquals(this.replaceConfigurationValues(expectedResult),this.replaceConfigurationValues(variable),"ERROR the values are not the same");
    }

    @And("verify the query result have at least {int} result")
    public void verifyTheQueryResultHaveAtLeastResult(int amountResult) {
        Logger.log(Level.INFO,this.getClass().getName()+" query result size: "+queryResult.size()+" >= amount expected: "+amountResult);
        Assertions.assertTrue(queryResult.size() >= amountResult,"ERROR the size of result is < "+amountResult);
    }

    @Then("verify the value {string} is not equal to {string}")
    public void verifyTheValueIsNotEqualTo(String value1, String value2) {
        value1= replaceConfigurationValues(value1);
        value2=replaceConfigurationValues(value2);
        Logger.log(Level.INFO,this.getClass().getName()+"the values are not equal: value1: "+value1+ "vs value2: "+value2);

        Assertions.assertNotEquals(value1,value2, "ERROR! the values are equal: value1: "+value1+ "vs value2: "+value2);
    }
}
