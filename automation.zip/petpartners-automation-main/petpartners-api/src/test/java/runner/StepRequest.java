package runner;

import api.ApiConfiguration;
import api.RequestEnum;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.github.fge.jsonschema.SchemaVersion;
import com.github.fge.jsonschema.cfg.ValidationConfiguration;
import com.github.fge.jsonschema.main.JsonSchemaFactory;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import configuration.CommonValues;
import configuration.Configuration;
import factoryRequest.FactoryRequest;
import factoryRequest.RequestInformation;
import helpers.GetProperties;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import utils.FileUtils;
import utils.JsonHelper;
import utils.Level;
import utils.Logger;

import java.io.File;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static configuration.Configuration.*;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import static org.hamcrest.Matchers.equalTo;

public class StepRequest extends BaseStep{
    @Given("I have access to {}")
    public void iHaveAccessToApiQuote(String nameApi) {
        requestInformation= new RequestInformation();
        requestInformation.addHeader(CONTENT_TYPE,APPLICATION_JSON);
    }

    @Given("I am logged in api-pet to use the AccessToken")
    public void iAmLoggedInApiPet() {

        JSONObject body = new JSONObject();
        body.put("username", USER);
        body.put("password", PASSWORD);
        body.put("application","orca");

        requestInformation= new RequestInformation();
        requestInformation.addHeader(CONTENT_TYPE,APPLICATION_JSON);
        requestInformation.setUrl(Configuration.host +ApiConfiguration.LOGIN.getApiUrl())
                          .setBody(body.toString());
        response=FactoryRequest.make(RequestEnum.POST.getMethod()).send(requestInformation);
        response.then().statusCode(200);
        String token=response.then().extract().path(ACCESS_TOKEN);

        requestInformation.addHeader(AUTHORIZATION,BEARER+token);
    }


    @When("I send a {} request {} using body")
    public void iSendAPOSTRequestLOGINUsingBody(RequestEnum request, ApiConfiguration url, String body) {
        requestInformation.setUrl(Configuration.host +url.getApiUrl())
                          .setBody(this.replaceConfigurationValues(body));
        response=FactoryRequest.make(request.getMethod()).send(requestInformation);
    }

    @And("I add {int} days from today in the variable {} with format {}")
    public void iCreateANewDate(int days, String variable,String format) {
        Date dt = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(dt);
        c.add(Calendar.DATE, days);
        if (format.toLowerCase().equals("millisecond")){
            CommonValues.variables.put(variable, c.getTimeInMillis()+"");
            Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"] using milliseconds");
        }else{
            CommonValues.variables.put(variable, new SimpleDateFormat(format).format(c.getTime()));
            Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"] using format: "+format);
        }

    }


    @Then("I expected the response code should be {int}")
    public void iExpectedTheResponseCodeShouldBe(int expectedCode) {
        Assertions.assertEquals(expectedCode,response.getStatusCode(),"ERROR the response code is different actual: "+response.getStatusCode()+" vs expected: "+expectedCode+
                requestInformation.getInformation()+"\n**Response Information**\nbody: "+response.body().asString()+"\nresponse code: "+response.getStatusCode());
    }

    @And("I expected the response body should be")
    public void iExpectedTheResponseBodyShouldBe(String expectedResult) throws JsonProcessingException {
        JsonHelper.assertAreEqualJson(this.replaceConfigurationValues(expectedResult),response.body().asString(),"ERROR! The json response are not equals");
    }

    @And("I expected the response body should have text")
    public void iExpectedTheResponseBodyShouldHaveText(String expectedResult)  {
        Assertions.assertTrue(response.body().asString().contains(expectedResult),
                "ERROR! The expected text not in response, actual: "+response.body().asString()+ "does not contains: "+expectedResult);
    }

    @And("I expected {} attribute {string} should be {}")
    public void iExpectedTheAttributeShouldBeTrue(String type,String attribute, String expectedValue) {
        switch (type.toLowerCase()){
            case "int":
                response.then().body(attribute,equalTo(Integer.parseInt(expectedValue)));
                break;
            case "boolean":
                response.then().body(attribute,equalTo(Boolean.parseBoolean(expectedValue)));
                break;
            default:
                response.then().body(attribute,equalTo(expectedValue));
                break;
        }
    }

    @And("I schema should be equals to {}")
    public void iSchemaShouldBeEqualsToJsonSchemaSendRegistrationJson(String jsonSchemaPath) {
        JsonSchemaFactory jsonSchemaFactory = JsonSchemaFactory.newBuilder()
                .setValidationConfiguration(ValidationConfiguration.newBuilder()
                        .setDefaultVersion(SchemaVersion.DRAFTV4).freeze()).freeze();
        response.then()
                .body(matchesJsonSchemaInClasspath(jsonSchemaPath).using(jsonSchemaFactory));

    }

    @When("I send a {} request {} using body {string} replacing")
    public void iSendAPOSTRequestREGISTRATIONUsingBodyWith(RequestEnum request, ApiConfiguration url, String pathFile, Map<String,String> attributeToUpdate) throws URISyntaxException {
        String body=FileUtils.readFile(new File("").getAbsolutePath()+"/src/test/resources/"+pathFile);

        for (String attribute: attributeToUpdate.keySet()) {
            body=body.replace(attribute,attributeToUpdate.get(attribute));
        }
        body=this.replaceConfigurationValues(body);
        requestInformation.setUrl(Configuration.host +url.getApiUrl())
                .setBody(body);
        response=FactoryRequest.make(request.getMethod()).send(requestInformation);
    }

    @And("I send a {} request {} using {} with body")
    public void iSendARequestWithBody(RequestEnum request, ApiConfiguration url, String id,String body) {
        String urlValue= url.getApiUrl().replace("{id}",id);
        requestInformation.setUrl(this.replaceConfigurationValues(Configuration.host +urlValue))
                .setBody(this.replaceConfigurationValues(body));
        response=FactoryRequest.make(request.getMethod()).send(requestInformation);
    }

    @And("I send a {} request {} passing dynamic values in body")
    public void iSendARequestPassingDynamicValuesInBody(RequestEnum request, ApiConfiguration url,Map<String,String> attributeToUpdate) {
        String urlValue= url.getApiUrl();
        for (String attribute: attributeToUpdate.keySet()) {
            urlValue= urlValue.replace("{"+ attribute + "}",attributeToUpdate.get(attribute));
        }
        requestInformation.setUrl(this.replaceConfigurationValues(Configuration.host +urlValue));
        response=FactoryRequest.make(request.getMethod()).send(requestInformation);
    }

    @And("I get a random value on {}")
    public void iGetARandomValueOnEMAIL(String variable) {
        CommonValues.variables.put(variable,new Date().getTime()+"");
        Logger.log(Level.INFO,this.getClass().getName()+" save the variable ["+variable+"] value: "+CommonValues.variables.get(variable));

    }

    @When("I use the header Authorization with value Bearer {}")
    public void iUseTheHeaderAuthorizationWithValueBearerTOKEN(String value) {
        requestInformation.addHeader(AUTHORIZATION,BEARER+this.replaceConfigurationValues(value));
    }

    @When("I send a {} request {} using the file {string}")
    public void iSendAPOSTRequestATTACHMENTUsingTheFile(RequestEnum request, ApiConfiguration url,String file) {
        String resourcesPath=new File("").getAbsolutePath()+"/src/test/resources/";
        requestInformation.setUrl(Configuration.host +url.getApiUrl())
                .addHeader(CONTENT_TYPE,MULTIPART_FORM_DATA)
                .addMultipart("files",resourcesPath+file);
        response=FactoryRequest.make(request.getMethod()).send(requestInformation);
        // reset the multipart for next request
        requestInformation.addMultipart(null,null);
        requestInformation.addHeader(CONTENT_TYPE,APPLICATION_JSON);
    }


    @And("^I am going to use the (gateway|default|trustCommerce) url for next request$")
    public void iAmGoingToUseTheGatewayUrlForNextRequest(String urlHost) {

        switch (urlHost){
            case "gateway":
                host = GetProperties.getInstance().getGatewayUrl();
                break;
            case"trustCommerce":
                host = GetProperties.getInstance().getTrustCommerce();
                break;
            default:
                host = GetProperties.getInstance().getHost();
                break;
        }
        Logger.log(Level.INFO,this.getClass().getName()+" url host to use: "+ host);
    }

    @And("I save {string} value on {}")
    public void iSaveValueOnNAME(String value, String nameVariable) {
        CommonValues.variables.put(nameVariable,value);
        Logger.log(Level.INFO,this.getClass().getName()+" save the variable ["+nameVariable+"] value: "+CommonValues.variables.get(nameVariable));
    }

    @And("I save the {} in {}")
    public void iSaveAttributeOnVariable(String attribute, String variableName) {
        String value=response.then().extract().path(attribute)+"";
        CommonValues.variables.put(variableName,value);
        Logger.log(Level.INFO,this.getClass().getName()+" save the variable "+variableName+" value: "+CommonValues.variables.get(variableName));
    }

    @And("I save json object of attribute {} in {}")
    public void iSaveJsonObjectOfAttributeDataInJson(String attribute,String variableName) {
        CommonValues.variables.put(variableName,new JSONObject(response.body().asString()).get(attribute).toString());
        Logger.log(Level.INFO,this.getClass().getName()+" save the variable "+variableName+" value: "+CommonValues.variables.get(variableName));
    }

    @When("I send a {} request {} using params")
    public void iSendAPOSTRequestGetUsingParams(RequestEnum request, ApiConfiguration urlValue, Map <String,String> params) {
        requestInformation.setUrl(this.replaceConfigurationValues(Configuration.host +urlValue.getApiUrl()));
        for (String key:params.keySet())
            requestInformation.addQueryParams(key,this.replaceConfigurationValues(params.get(key)));

        response=FactoryRequest.make(request.getMethod()).send(requestInformation);
        requestInformation.cleanParams();
    }

    @And("I remove the [] for {}")
    public void iRemoveTheForVariable(String variableName) {
        CommonValues.variables.put(variableName,CommonValues.variables.get(variableName).replace("[","").replace("]",""));
        Logger.log(Level.INFO,this.getClass().getName()+" remove [] from the variable "+variableName+" value: "+CommonValues.variables.get(variableName));
    }

    /**
     * https://support.smartbear.com/alertsite/docs/monitors/api/endpoint/jsonpath.html
     * @param expression
     * @param variable
     */
    @And("I execute json expression {string} saving the result {}")
    public void iExecuteJsonExpression(String expression, String variable) {
        String value=JsonPath.read(response.body().asString(),this.replaceConfigurationValues(expression)).toString();

        CommonValues.variables.put(variable,value);
        Logger.log(Level.INFO,this.getClass().getName()+" save the variable "+variable+" value: "+CommonValues.variables.get(variable)+" using the expresion: "+this.replaceConfigurationValues(expression));
    }

    /**
     * https://support.smartbear.com/alertsite/docs/monitors/api/endpoint/jsonpath.html
     * @param attributeName --> expression jsonpath
     */
    @And("I update the {} adding the json object to the attribute {string}")
    public void iUpdateTheDataJsonBodyAddingTheJsonObjectToTheAttribute(String completeJson, String attributeName,String subJsonValue) {
        attributeName=replaceConfigurationValues(attributeName);
        subJsonValue=replaceConfigurationValues(subJsonValue);
        DocumentContext val=JsonPath.parse(replaceConfigurationValues(completeJson)).set(attributeName,JsonPath.parse(subJsonValue).read("$"));
        CommonValues.variables.put(completeJson,val.jsonString());
        Logger.log(Level.INFO,this.getClass().getName()+" update the variable "+completeJson+" with the value: "+CommonValues.variables.get(completeJson));
    }

    @And("I add {int} year from {} in the variable {} with format {}")
    public void iAddYeartoSpecificDate(int addYear,String fromDate,String newVariable,String format) {
        Date dt = new Date(Long.parseLong(this.replaceConfigurationValues(fromDate)));
        Calendar c = Calendar.getInstance();
        c.setTime(dt);
        c.add(Calendar.YEAR, addYear);
        CommonValues.variables.put(newVariable, new SimpleDateFormat(format).format(c.getTime()));
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(newVariable)+"] in ["+newVariable+"]");
    }

    @And("remove the next attributes from: {}")
    public void removeTheNextAttributesFromVariable(String jsonVariable, List<String> attributeToDeleteList) {
        String jsonVariableValue=replaceConfigurationValues(jsonVariable);
        JSONObject json = new JSONObject(jsonVariableValue);

        for (String attributeToDelete:attributeToDeleteList) {
            json.remove(attributeToDelete);

        }
        CommonValues.variables.put(jsonVariable,json.toString());
        Logger.log(Level.INFO,this.getClass().getName()+" remove the variables ["+attributeToDeleteList.toString()+"] in the json: "+CommonValues.variables.get(jsonVariable));


    }

    @And("I expected the response body should not have text")
    public void iExpectedTheResponseBodyShouldNotHaveText(String expectedResult)  {
        Assertions.assertFalse(response.body().asString().contains(expectedResult),
                "ERROR! The expected text in response, actual: "+response.body().asString()+ "does contains: "+expectedResult);
    }
}
