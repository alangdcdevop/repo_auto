package runner.stepsGroupOrca;

import entities.orca.certificate.CertificateProductDetailEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orcaGroup.certificate.GroupAttachmentsPage;
import pages.orcaGroup.certificate.GroupCertificateDashboardPage;
import pages.orcaGroup.certificate.GroupCertificateDetailPage;
import runner.stepsOrca.BaseSteps;

import java.util.List;
import java.util.Map;

public class CertificateStep extends BaseSteps {

    GroupCertificateDashboardPage groupCertificateDashboardPage= new GroupCertificateDashboardPage();
    GroupCertificateDetailPage groupCertificateDetailPage= new GroupCertificateDetailPage();
    GroupAttachmentsPage attachmentsPage = new GroupAttachmentsPage();
    @And("I search certificate using the criteria:")
    public void iSearchCetificateUsingTheCriteria(Map <String ,String>searchCriteria) throws Exception {
        for (String control:searchCriteria.keySet()) {
            if (groupCertificateDashboardPage.textBoxMap.containsKey(control))
                groupCertificateDashboardPage.textBoxMap.get(control).setText(this.replaceConfigurationValues(searchCriteria.get(control)));
        }
        groupCertificateDashboardPage.runSearchButton.click();
    }

    @When("I click on {string} Link on the Search Table Result - Certificate Dashboard")
    public void iClickOnLinkOnTheSearchTableResultCertificateDashboard(String linkValue) throws Exception {
        groupCertificateDashboardPage.searchResultTable.clickOnLinkCellContains(this.replaceConfigurationValues(linkValue));
    }

    @And("I click on {string} tab in Certificate Details")
    public void iClickOnTabInCertificateDetails(String tabName) throws Exception {
        groupCertificateDetailPage.clickOnTab(this.replaceConfigurationValues(tabName));
    }

    /*Deductible Tracker*/
    @And("I click on {string} Link in Pet\\(s) tab")
    public void iClickOnLinkInPetSTab(String linkName) throws Exception {
        groupCertificateDetailPage.deductibleTrackerLink.click();
    }

    @Then("I verify the {string} column is displayed")
    public void iVerifyTheColumnIsDisplayed(String expectedResult) throws Exception {
        List<String> headers=groupCertificateDetailPage.deductibleTable.getAllHeaderLabel();
        Assertions.assertTrue(headers.contains(this.replaceConfigurationValues(expectedResult)),"ERROR the column: ["+this.replaceConfigurationValues(expectedResult)+"] is not displayed");
    }

    @And("I click on {string} link in Coverage tab - Certificate Detail")
    public void iClickOnLinkInCoverageTabCertificateDeetail(String linkName) throws Exception {
        if (!groupCertificateDetailPage.linkMap.containsKey(linkName))
            throw new Exception("ERROR> the link name: ["+linkName+"] does not exist");
        groupCertificateDetailPage.linkMap.get(linkName).controlIsClickable();
        groupCertificateDetailPage.linkMap.get(linkName).controlIsDisplayed();
        groupCertificateDetailPage.linkMap.get(linkName).click();

    }

    @Then("The column {string} should be displayed")
    public void theColumnDeductibleShouldBeDisplayed(String columName) throws Exception {
        Assertions.assertTrue(groupCertificateDetailPage.coveragePeriodTable.getAllHeaderLabel().contains(columName),"ERROR the column "+columName+" is not displayed");
    }

    @And("The Pet Details table should be displayed the next value")
    public void thePetDetailsTableShouldBeDisplayedTheNextValue(String value) throws Exception {
        Assertions.assertTrue(groupCertificateDetailPage.coveragePeriodTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(value)),
                "ERROR> the value: ["+this.replaceConfigurationValues(value)+"] is not displayed in the table");
    }

    @Then("I verify the {string} table with the next data in Coverage tab - Certificate Detail")
    public void iVerifyTheTableWithTheNextDataInCoverageTabCertificateDetail(String table, List<CertificateProductDetailEntity> tableDataExpectedResult) throws Exception {
        int product=0;
        int benefit=1;
        int limitApplied=2;
        int limitRemaining=3;
        boolean isTableEqual=true;
        String msgError="";
        List <List<String>> tableActualResult=groupCertificateDetailPage.productDetailTable.getTableValue();

        // we start from 1 because the posotion 0 is the name of columns
        for (int i = 1; i < tableDataExpectedResult.size(); i++) {
            CertificateProductDetailEntity expected = tableDataExpectedResult.get(i);
            List<String> actual= tableActualResult.get(i);

            if ( !actual.get(product).equals(expected.getProductColumn())||
                    !actual.get(benefit).equals(expected.getBenefitColumn()) ||
                    !actual.get(limitApplied).equals(expected.getAnnualLimitAppliedColumn())||
                    !actual.get(limitRemaining).equals(expected.getAnnualLimitRemainingColumn())  ){

                msgError=msgError+"\nERROR! the row ["+i+"] has different values: " +
                        "\nthe actual value: [ "+actual.get(product)+" | "+actual.get(benefit)+" | "+actual.get(limitApplied)+" | "+actual.get(limitRemaining)+" ]"+
                        "\nthe expected value: [ "+expected.getProductColumn()+" | "+expected.getBenefitColumn()+" | "+expected.getAnnualLimitAppliedColumn()+" | "+expected.getAnnualLimitRemainingColumn()+" ]";

                isTableEqual=false;
            }

        }
        Assertions.assertTrue(isTableEqual,"ERROR the values in product table are not the same: "+msgError);
    }

    @DataTableType
    public CertificateProductDetailEntity getEntity(Map<String,String> data){
        CertificateProductDetailEntity entity= new CertificateProductDetailEntity();
        entity.setAnnualLimitRemainingColumn(data.get("Annual Limit Remaining"))
                .setProductColumn(data.get("Product"))
                .setAnnualLimitAppliedColumn(data.get("Annual Limit Applied"))
                .setBenefitColumn(data.get("Benefit"));

        return entity;
    }


    @And("I verify the columns names are displayed in Product Details table")
    public void iVerifyTheColumnsNamesAreDisplayedInProductDetailsTable(List<String> expectedResult) throws Exception {
        Assertions.assertTrue(groupCertificateDetailPage.productDetailTable.verifyAllHeaderLabel(expectedResult),
                "Some labels in the table are missing, actual [" + groupCertificateDetailPage.productDetailTable.getAllHeaderLabel().toString() + " vs expected [" + expectedResult.toString() + "]");


    }

    @And("^I verify the (Active|Upcoming) coverage period should be$")
    public void iVerifyTheActiveCoveragePeriodShouldBe(String type,String expectedResult) throws Exception {
        String actualResult=groupCertificateDetailPage.getCoveragePeriod(type);
        expectedResult= this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),"ERROR the message: ["+actualResult+"] does not contains: ["+expectedResult+"]");
    }

    @And("I enter the {string} in Note TextBox  - Employee Details")
    public void iEnterTheNoteInNote(String note) throws Exception {
        groupCertificateDetailPage.noteTextbox.setText(note);
    }

    @Then("I Verify {string} display on customer search results Table")
    public void iVerifyDisplayOnCustomerSearchResultsTable(String value) throws Exception {
        Assertions.assertTrue(groupCertificateDetailPage.customerDetailsTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(value)), "ERROR! the value : [" + this.replaceConfigurationValues(value) + "] is not displayed in the customer search result section");
    }

    @And("I click on {string} link in Employee\\(s) tab - Certificate Detail")
    public void iClickOnLinkInEmployeeSTabCertificateDetail(String linkname) throws Exception {
        groupCertificateDetailPage.iconLink.controlIsClickable();
        groupCertificateDetailPage.iconLink.click();
    }

    @And("I check the important note checkbox in Employee Details")
    public void iClickOnImportantNote() throws Exception {
        groupCertificateDetailPage.noteCheckbox.click();
    }
    @And("I verify the columns names are displayed in Employee\\(s) Details table")
    public void iVerifyTheColumnsNamesAreDisplayedInEmployeeSDetailsTable(List<String> expectedResult) throws Exception {
        Assertions.assertTrue(groupCertificateDetailPage.customerDetailsTable.verifyAllHeaderLabel(expectedResult), "Some labels in the table are missing, actual [" + groupCertificateDetailPage.customerDetailsTable.getAllHeaderLabel().toString() + " vs expected [" + expectedResult.toString() + "]");
    }

    @And("I click on Save button in Employee Details")
    public void iClickOnSaveButton() throws Exception {
        groupCertificateDetailPage.saveButton.click();
    }

    @Then("verify the next control values in Certificate Details Page")
    public void verifyTheNextControlValuesInCertificateDetailsPage(Map <String,String> expectedValuesData) throws Exception {
        for (String control:expectedValuesData.keySet()) {
          String actualValue = this.groupCertificateDetailPage.labelValueMap.get(control).getText();
          String expectedValue = this.replaceConfigurationValues(expectedValuesData.get(control));
          Assertions.assertTrue(actualValue.contains(expectedValue),"ERROR the values are different actual["+actualValue+"] vs expected: ["+expectedValue+"]");
        }
   }

    @And("I click on [Add New] button on the attachments tab")
    public void iClickOnAddNewButtonOnTheAttachmentsTab() throws Exception {
        attachmentsPage.addNewButton.click();
    }

    @When("I click on {string} button on the attachment details page")
    public void iClickOnButtonOnTheAttachmentDetailsPage(String button) throws Exception {
        if(button.contains("Return Certificate")){
            attachmentsPage.returnCertificateButton.click();
        } else if (button.contains("Save")) {
            attachmentsPage.attachmentDetailsSaveButton.click();
        }
    }

    @Then("I verify {string} display on the attachment tab")
    public void iVerifyDisplayOnTheAttachmentTab(String expectedResult) throws Exception {
        String actualResult = attachmentsPage.addNewButton.getText();
        expectedResult = this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult));

    }

    @Then("I verify the pet age display on the pet details table with next value")
    public void iVerifyThePetAgeDisplayOnThePetDetailsTableWithNextValue(Map<String, String> age) throws Exception {
        Assertions.assertTrue(groupCertificateDetailPage.coveragePeriodTable.checkIfValueIsDisplayedInTable(age.get("Age")),
                "ERROR: " + this.replaceConfigurationValues(age.get("Age")) + "  is not displayed");

    }
}