package runner.stepsGroupOrca;

import io.cucumber.java.en.And;
import pages.orca.claim.ClaimSearch;
import pages.orcaGroup.ClaimSections;
import pages.orcaGroup.MenuSections;
import runner.stepsOrca.BaseSteps;

import java.util.Map;

public class GroupClaimDashboardStep extends BaseSteps {
    MenuSections menuSections = new MenuSections();
    ClaimSections claimSections = new ClaimSections();
    ClaimSearch claimSearch = new ClaimSearch();
    @And("I search claims using the criteria:")
    public void iSearchClaimsUsingTheCriteria(Map<String,String> searchCriteriaMap) throws Exception {
        menuSections.menuOption.get("Claims").click();
        claimSections.searchForClaimsButton.click();
        for ( String textboxName: searchCriteriaMap.keySet()) {
            claimSearch.textBoxMap.get(textboxName).clearSetText(this.replaceConfigurationValues(searchCriteriaMap.get(textboxName)));
        }
        claimSearch.runSearchButton.click();
    }

    @And("click on link {string} in claim search result")
    public void clickOnLinkInClaimSearchResult(String linkName) throws Exception {
        claimSearch.clickClaimResult(this.replaceConfigurationValues(linkName));
    }
}
