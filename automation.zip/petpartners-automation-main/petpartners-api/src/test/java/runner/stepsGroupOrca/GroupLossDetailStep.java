package runner.stepsGroupOrca;

import io.cucumber.java.en.And;
import pages.orcaGroup.GroupLossDetailsPage;
import runner.stepsOrca.BaseSteps;

public class GroupLossDetailStep extends BaseSteps {

    GroupLossDetailsPage groupLossDetailsPage = new GroupLossDetailsPage();
    @And("I select {string} in [Date Of Service] Calendar on Group Loss Detail")
    public void iSelectInDateOfServiceCalendarOnGroupLossDetail(String value) throws Exception {
        groupLossDetailsPage.dateOfServiceTextBox.click();
        groupLossDetailsPage.dateOfServiceTextBox.setTextAndTab(this.replaceConfigurationValues(value));

    }

    @And("I select {string} in [Pet] Combobox on Group Loss Detail")
    public void iSelectInPetComboboxOnGroupLossDetail(String value) throws Exception {
        groupLossDetailsPage.petSelect.selectValue(this.replaceConfigurationValues(value));
    }

    @And("I click on [Group Pet Coverage Info] button on Group Loss Detail")
    public void iClickOnGroupPetCoverageInfoButtonOnGroupLossDetail() throws Exception {
        groupLossDetailsPage.viewProductsForPetButton.click();
    }
}
