package runner.stepsGroupOrca;

import configuration.CommonValues;
import entities.orca.IncidentEntity;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.JavascriptExecutor;
import pages.orcaGroup.GroupAddIncidentPage;
import pages.orcaGroup.GroupLossDetailsPage;
import runner.stepsOrca.BaseSteps;
import session.Session;
import utils.Level;
import utils.Logger;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

public class GroupLossSteps extends BaseSteps {

    GroupLossDetailsPage groupLossDetailsPage = new GroupLossDetailsPage();
    GroupAddIncidentPage groupAddIncidentPage = new GroupAddIncidentPage();

    @And("fill the Overview in group Loss Detail section")
    public void fillTheOverviewInGroupLossDetailSection(Map<String, String> overViewDetailValues) throws Exception {
        if (overViewDetailValues.containsKey("Date of Service")) {
            groupLossDetailsPage.dateOfServiceTextBox.click();
            groupLossDetailsPage.dateOfServiceTextBox.setTextAndTab(this.replaceConfigurationValues(overViewDetailValues.get("Date of Service")));
        }
        if (overViewDetailValues.containsKey("Pet")) {
            if (this.replaceConfigurationValues(overViewDetailValues.get("Pet")).equals("FIRST_VALUE")) {
                groupLossDetailsPage.petSelect.firstValue();
            } else {
                groupLossDetailsPage.petSelect.selectValue(this.replaceConfigurationValues(overViewDetailValues.get("Pet")));
            }

        }
        if (overViewDetailValues.containsKey("Vet")) {
            if (this.replaceConfigurationValues(overViewDetailValues.get("Vet")).equals("FIRST_VALUE")) {
                groupLossDetailsPage.vetSelect.firstValue();
            } else {
                groupLossDetailsPage.vetSelect.selectValue(this.replaceConfigurationValues(overViewDetailValues.get("Vet")));
            }
        }

    }

    @And("fill the Approved section")
    public void fillTheApprovedSection(Map<String, String> approvedSetionValues) throws Exception {
        for (String key : approvedSetionValues.keySet()) {
            if (groupLossDetailsPage.approvedTableCell.containsKey(key) && groupLossDetailsPage.approvedTableCell.get(key).getTypeCell().equals("input")) {
                if (key.equals("Procedure")) {
                    groupLossDetailsPage.approvedTable.setTextSelect(groupLossDetailsPage.approvedTableCell.get(key).getPosition(), 1, this.replaceConfigurationValues(approvedSetionValues.get(key)).split(" ")[0], this.replaceConfigurationValues(approvedSetionValues.get(key)));
                } else {
                    groupLossDetailsPage.approvedTable.setText(groupLossDetailsPage.approvedTableCell.get(key).getPosition(), 1, this.replaceConfigurationValues(approvedSetionValues.get(key)));
                }
            } else if (groupLossDetailsPage.approvedTableCell.containsKey(key) && groupLossDetailsPage.approvedTableCell.get(key).getTypeCell().equals("select")) {
                groupLossDetailsPage.approvedTable.select(groupLossDetailsPage.approvedTableCell.get(key).getPosition(), 1, this.replaceConfigurationValues(approvedSetionValues.get(key)));
            }
        }
    }

    @And("find a vet to add to the option in group Loss Detail section")
    public void findAVetToAddToTheOptionInGroupLostDetailSection() throws Exception {
        groupLossDetailsPage.findVetButton.click();
        groupLossDetailsPage.vetSearchModal.stateProvinceSelect.firstValue();
        groupLossDetailsPage.vetSearchModal.clickOnSelectButton(1, "c");
    }

    @And("click on [{}] button in group approved section")
    public void clickOnSendToInvestigatorButton(String buttonName) throws Exception {
        groupLossDetailsPage.controlApprovedButton.get(buttonName).click();
    }

    @And("click on [{}] button in group loss detail - overview page")
    public void clickOnSaveButtonInGroupLossDetailOverviewPage(String nameControl) throws Exception {
        if (groupLossDetailsPage.controlOverviewButton.containsKey(nameControl))
            groupLossDetailsPage.controlOverviewButton.get(nameControl).click();
        else
            throw new Exception("the button " + nameControl + " does not exist in loss detail overview page");
    }
    @And("create a new incident in group loss details")
    public void createANewIncidentInGroupLossDetails(Map<String, String> values) throws Exception {
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();

        groupLossDetailsPage.incidentsPlusButton.click();
        groupAddIncidentPage.createANewIncidentButton.click();
        IncidentEntity incidentEntity = new IncidentEntity();

        incidentEntity.setOnSetDate(this.replaceConfigurationValues(values.get("date")))
                .setIncidentTypeInitial(this.replaceConfigurationValues(values.get("incidentTypeInitial")))
                .setIncidentType(this.replaceConfigurationValues(values.get("incidentType")));


        groupAddIncidentPage.groupCreateIncident(incidentEntity);
        Thread.sleep(2000);
        groupLossDetailsPage.approvedTable.selectFirstValue(groupLossDetailsPage.approvedTableCell.get("Incident").getPosition(), 1);
        js.executeScript("window.scrollBy(0,400)");
        groupLossDetailsPage.controlApprovedButton.get("Save").click();


    }
    @And("I click on a link view loss details")
    public void iClickOnALinkViewLossDetails() throws Exception {
        groupLossDetailsPage.viewLossDetailsLink.click();
    }
    @Then("verify the denial Reason")
    public void verifyTheDenialReason(String expectedReason) throws Exception {
        String actualreason = groupLossDetailsPage.denialReasonHeader.getText();
        expectedReason = this.replaceConfigurationValues(expectedReason);
        Assertions.assertTrue(actualreason.contains(expectedReason),
                "Wrong denial reason, actual: [" + actualreason + "] vs expected: [" + expectedReason + "]");

    }

    @And("i subtract {int} months from today in the variable {} with format {}")
    public void iSubtractMonthsFromToday(int days, String variable, String format) {
        Date dt = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(dt);
        c.add(Calendar.MONTH, days*-1);
        CommonValues.variables.put(variable, new SimpleDateFormat(format).format(c.getTime()));
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variable) + "] in [" + variable + "]");

    }


    @Then("I verify the Warning alert massage on the group loss details page")
    public void iVerifyTheWarningAlertMassageOnTheGroupLossDetailsPage(String expectedResult) throws Exception {
        String actualResult = groupLossDetailsPage.duplicateWarningLabel.getText();
        expectedResult = this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),
                "ERROR the message is not successfully, actual: [" + actualResult + "] vs expected: [" + expectedResult + "]");

    }
}
