package runner.stepsGroupOrca;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.interactions.Actions;
import pages.orcaGroup.GroupPetCoverageInfoPage;
import pages.orcaGroup.MenuSections;
import runner.stepsOrca.BaseSteps;
import session.Session;

import java.util.Map;

public class GroupPetCoverageInfoStep extends BaseSteps {
    GroupPetCoverageInfoPage groupPetCoverageInfoPage = new GroupPetCoverageInfoPage();
    MenuSections menuSections = new MenuSections();
    @Then("I verify the overview section the next values on Group Pet Coverage Info")
    public void iVerifyTheOverviewSectionTheNextValuesOnGroupPetCoverageInfo(Map<String,String> controlExpectedResult) throws Exception {
        for (String controlName:controlExpectedResult.keySet()) {
            String actualResult=groupPetCoverageInfoPage.getValueForLabel(controlName);
            String expectedResult=this.replaceConfigurationValues(controlExpectedResult.get(controlName));
            Assertions.assertEquals(expectedResult,actualResult,"ERROR the values for ["+controlName+"] are different, expected: "+expectedResult+ "vs actual: "+actualResult);

        }
    }

    @And("I verify the overview section tooltips for next controls on Group Pet Coverage Info")
    public void iVerifyTheOverviewSectionTooltipsForNextControlsOnGroupPetCoverageInfo(Map<String,String> controlExpectedResult) throws Exception {
        for (String controlName:controlExpectedResult.keySet()) {
            String actualResult=groupPetCoverageInfoPage.getToolTipForLabel(controlName);
            String expectedResult=this.replaceConfigurationValues(controlExpectedResult.get(controlName));
            Assertions.assertEquals(expectedResult,actualResult,"ERROR the tooltip for ["+controlName+"] are different, expected: "+expectedResult+ "vs actual: "+actualResult);

        }



    }

    @And("I click on any site out of modal")
    public void iClickOnAnySiteOutOfModal() {
        new Actions(Session.getInstance().getDriver()).moveByOffset(10,10).click().perform();
    }

    @And("I verify {string} display on the plan overview page")
    public void iVerifyDisplayOnThePlanOverviewPage(String value) throws Exception {
        Assertions.assertTrue(menuSections.lookBackPeriodLabel.getText().contains(value),
                "ERROR! the value : [" + value + "] is not displayed in the Plan overview page");

    }
}
