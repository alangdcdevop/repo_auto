package runner.stepsOrca;

import pages.orca.common.AlertSection;
import pages.orca.common.MenuSection;
import runner.BaseStep;

public class BaseSteps extends BaseStep {
    protected MenuSection menuSection = new MenuSection();
    protected AlertSection alertSection= new AlertSection();
}
