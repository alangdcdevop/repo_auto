package runner.stepsOrca;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.JavascriptExecutor;
import pages.orca.claim.ClaimDetails;
import session.Session;

public class ClaimDetailsSteps extends BaseSteps {
    ClaimDetails claimDetails = new ClaimDetails();

    @And("I click on [{}] link under claims attachment tab")
    public void iClickOnLinkUnderClaimsAttachmentTab(String sLink)  throws Exception {
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,500)");
        claimDetails.claimsResultLink.controlIsDisplayed(10);
        claimDetails.claimsResultLink.click();
    }

    @Then("I verify [{}] document type label in claims page")
    public void iVerifyDocumentTypeLabelInClaimsPage(String sDocType) {
        Assertions.assertTrue(claimDetails.claimAttachmentTabDocTypeLabelsMap.get(sDocType).controlIsDisplayed(10),
                "ERROR: " + sDocType + " is not displayed");
    }
}
