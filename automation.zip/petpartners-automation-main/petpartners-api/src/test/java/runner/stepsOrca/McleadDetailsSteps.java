package runner.stepsOrca;

import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.orca.mclead.McleadDetailsPage;

public class McleadDetailsSteps {

    McleadDetailsPage mcleadDetailsPage = new McleadDetailsPage();

    @Then("verify salesforceid in mclead details page")
    public void verifySalesforceidInMcleadDetailsPage() throws Exception {
        Assertions.assertTrue(mcleadDetailsPage.salesforceIdTextBox.getTextAttribute("value").length() > 0,
                "ERROR: SalesforceId is not displayed");
    }
}
