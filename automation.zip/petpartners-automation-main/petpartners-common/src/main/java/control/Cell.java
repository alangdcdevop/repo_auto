package control;

public class Cell {
    private int position;
    private String typeCell;
    private String nameCell;

    public Cell() {
    }

    public Cell(int position, String typeCell, String nameCell) {
        this.position = position;
        this.typeCell = typeCell;
        this.nameCell = nameCell;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getTypeCell() {
        return typeCell;
    }

    public void setTypeCell(String typeCell) {
        this.typeCell = typeCell;
    }

    public String getNameCell() {
        return nameCell;
    }

    public void setNameCell(String nameCell) {
        this.nameCell = nameCell;
    }
}
