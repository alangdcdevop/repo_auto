package control;

import gifBuilder.ScreenShot;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import session.Session;
import utils.Level;
import utils.Logger;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class ControlBase {
    protected By locator;
    protected WebElement control;

    public ControlBase(By locator) {
        this.locator = locator;
    }

    protected void findControl() throws Exception {
        try {
            this.control = Session.getInstance().getDriver().findElement(this.locator);
            WebDriverWait explicitWait = new WebDriverWait(Session.getInstance().getDriver(), Duration.ofSeconds(30));
           explicitWait.until(ExpectedConditions.presenceOfElementLocated(this.locator));
              Logger.log(Level.INFO, this.getClass().getName() + "> locator [" + locator + "] amount found element: [" + Session.getInstance().getDriver().findElements(this.locator).size() + "]");
        } catch (NoSuchElementException exception) {
            Logger.log(Level.ERROR, this.getClass().getName() + "> *** the locator : [" + this.locator + "] was not found, Error message detail: \n" + exception.getMessage());
            throw new Exception(Level.ERROR + " " + this.getClass().getName() + "> the locator : [" + this.locator + "] was not found, please review if the locator is able to found the control\nError message detail: \n" + exception.getMessage());
        } catch (Exception e) {
            Logger.log(Level.ERROR, this.getClass().getName() + "> the locator : [" + this.locator + "] can not be found, Error message detail:\n " + e.getMessage());
            throw new Exception(Level.ERROR + "" + this.getClass().getName() + "> the locator : [" + this.locator + "] can not be found, Error message detail:\n " + e.getMessage());
        }
    }

    public void click() throws Exception {
        ScreenShot.addScreen(this.getClass().getName() + "> Click on [" + this.locator + "] " + this.getClass().getSimpleName());
        this.findControl();
        Logger.log(Level.INFO, this.getClass().getName() + "> Click on [" + this.locator + "] " + this.getClass().getSimpleName());
        this.control.click();
        ScreenShot.addScreen(this.getClass().getName() + "> Click on [" + this.locator + "] " + this.getClass().getSimpleName());
    }

    public boolean controlIsDisplayed() {
        try {
            ScreenShot.addScreen(this.getClass().getName() + "> Is control [" + this.locator + "] " + this.getClass().getSimpleName() + " displayed?");
            this.findControl();
            Logger.log(Level.INFO, this.getClass().getName() + "> Is control [" + this.locator + "] " + this.getClass().getSimpleName() + " displayed?: " + this.control.isDisplayed());
            return this.control.isDisplayed();
        } catch (Exception e) {
            ScreenShot.addScreen(this.getClass().getName() + "> Is control [" + this.locator + "] " + this.getClass().getSimpleName() + " displayed?");
            return false;
        } finally {
            ScreenShot.addScreen(this.getClass().getName() + "> Is control [" + this.locator + "] " + this.getClass().getSimpleName() + " displayed?");
        }
    }

    public void controlIsClickable() throws Exception {
        this.findControl();
        WebDriverWait explicitWait = new WebDriverWait(Session.getInstance().getDriver(), Duration.ofSeconds(15));
       explicitWait.until(ExpectedConditions.elementToBeClickable(this.locator));
        Logger.log(Level.INFO, this.getClass().getName() + "> Wait control [" + this.locator + "] " + this.getClass().getSimpleName() + " is clickable");
    }


    public boolean controlIsDisplayed(int timeout) {
        try {
            ScreenShot.addScreen(this.getClass().getName() + "> Is control [" + this.locator + "] " + this.getClass().getSimpleName() + " displayed?");
            Session.getInstance().getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(timeout));
            this.findControl();
            Logger.log(Level.INFO, this.getClass().getName() + "> control [" + this.locator + "] " + this.getClass().getSimpleName() + " is displayed: " + true);
            return true;
        } catch (Exception e) {
            Logger.log(Level.INFO, this.getClass().getName() + "> control [" + this.locator + "] " + this.getClass().getSimpleName() + " is displayed: false");
            Session.getInstance().getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
            return false;
        } finally {
            Session.getInstance().getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
            ScreenShot.addScreen(this.getClass().getName() + "> Is control [" + this.locator + "] " + this.getClass().getSimpleName() + " displayed?");
        }
    }

    public String getText() throws Exception {
        ScreenShot.addScreen(this.getClass().getName() + "> Get text from [" + this.locator + "] get text");
        Thread.sleep(1000);
        this.findControl();
        Logger.log(Level.INFO, this.getClass().getName() + "> Get text from [" + this.locator + "] " + this.getClass().getSimpleName() + ", value: [" + this.control.getText() + "]");
        ScreenShot.addScreen(this.getClass().getName() + "> Get text from [" + this.locator + "] get text");
        return this.control.getText();
    }

    public String getTextAttribute(String attribute) throws Exception {
        ScreenShot.addScreen(this.getClass().getName() + "> Get text from [" + this.locator + "] get text");
        this.findControl();
        Logger.log(Level.INFO, this.getClass().getName() + "> Get text from [" + this.locator + "] " + this.getClass().getSimpleName() + ", value: [" + this.control.getAttribute(attribute) + "]");
        ScreenShot.addScreen(this.getClass().getName() + "> Get text from [" + this.locator + "] get text");
        return this.control.getAttribute(attribute);
    }

    public String getCssAttribute(String attribute) throws Exception {
        ScreenShot.addScreen(this.getClass().getName() + "> Get css from [" + this.locator + "] get text");
        this.findControl();
        Logger.log(Level.INFO, this.getClass().getName() + "> Get css from [" + this.locator + "] " + this.getClass().getSimpleName() + ", value: [" + this.control.getCssValue(attribute) + "]");
        ScreenShot.addScreen(this.getClass().getName() + "> Get css from [" + this.locator + "] get text");
        return this.control.getCssValue(attribute);
    }
    public String getLocatorXpathString() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Get xpath locator [" + this.locator + "] " + this.getClass().getSimpleName() + ", value: [" + this.locator.toString().replace("By.xpath: ", "") + "]");
        return this.locator.toString().replace("By.xpath: ", "");
    }

    public boolean controlIsNotDisplayed(int timeoutSecond) {
        try {
            ScreenShot.addScreen(this.getClass().getName() + "> Is control [" + this.locator + "] " + this.getClass().getSimpleName() + " not displayed?");
            Session.getInstance().getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(timeoutSecond));
            WebDriverWait explicitWait = new WebDriverWait(Session.getInstance().getDriver(), Duration.ofSeconds(15));
            explicitWait.until(ExpectedConditions.numberOfElementsToBe(this.locator, 0));
            this.findControl();
            Logger.log(Level.INFO, this.getClass().getName() + "> control [" + this.locator + "] " + this.getClass().getSimpleName() + " is not displayed: " + true);
            return true;
        } catch (Exception e) {
            Logger.log(Level.INFO, this.getClass().getName() + "> control [" + this.locator + "] " + this.getClass().getSimpleName() + " is not displayed: false");
            Session.getInstance().getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            return false;
        } finally {
            Session.getInstance().getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            ScreenShot.addScreen(this.getClass().getName() + "> Is control [" + this.locator + "] " + this.getClass().getSimpleName() + " not displayed?");
        }
    }

    public boolean controlIsTextboxEmpty(String attribute) throws Exception {
        ScreenShot.addScreen(this.getClass().getName() + "> Get text from [" + this.locator + "] get text");
        this.findControl();
        Logger.log(Level.INFO, this.getClass().getName() + "> Get text from [" + this.locator + "] " + this.getClass().getSimpleName() + ", value: [" + this.control.getAttribute(attribute) + "]");
        ScreenShot.addScreen(this.getClass().getName() + "> Get text from [" + this.locator + "] get text");
        return this.control.getAttribute(attribute).isEmpty();
    }

    public boolean controlIsSelectDropdownEmpty(String attribute, String value) throws Exception {
        ScreenShot.addScreen(this.getClass().getName() + "> Get text from [" + this.locator + "] get text");
        this.findControl();
        Logger.log(Level.INFO, this.getClass().getName() + "> Get text from [" + this.locator + "] " + this.getClass().getSimpleName() + ", value: [" + this.control.getAttribute(attribute) + "]");
        ScreenShot.addScreen(this.getClass().getName() + "> Get text from [" + this.locator + "] get text");
        return this.control.getAttribute(attribute).isEmpty() || this.control.getAttribute(attribute).contains(value);
    }

    public void waitUntilControlIsDisplayed() throws Exception {
        this.findControl();
        WebDriverWait explicitWait = new WebDriverWait(Session.getInstance().getDriver(), Duration.ofSeconds(15));
        explicitWait.until(ExpectedConditions.visibilityOfElementLocated(this.locator));
        Logger.log(Level.INFO, this.getClass().getName() + "> Wait control [" + this.locator + "] " + this.getClass().getSimpleName() + " is clickable");
    }
}
