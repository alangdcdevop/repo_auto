package control;

import gifBuilder.ScreenShot;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import utils.Level;
import utils.Logger;

public class TextBox extends ControlBase {


    public TextBox(By locator) {
        super(locator);
    }

    public void setText(String value) throws Exception {
        ScreenShot.addScreen(this.getClass().getName() + "> Set on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + value + "]");
        this.findControl();
        Logger.log(Level.INFO, this.getClass().getName() + "> Set on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + value + "]");
        if (!value.equals(""))
            this.control.sendKeys(value);
        ScreenShot.addScreen(this.getClass().getName() + "> Set on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + value + "]");
    }

    public void setTextAndTab(String value) throws Exception {
        ScreenShot.addScreen(this.getClass().getName() + "> Set on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + value + "] + tab action");
        this.findControl();
        Logger.log(Level.INFO, this.getClass().getName() + "> Set on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + value + "] + tab action");
        this.control.sendKeys(value + Keys.TAB);
        ScreenShot.addScreen(this.getClass().getName() + "> Set on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + value + "] + tab action");
    }

    public void setTextAndEnter(String value) throws Exception {
        ScreenShot.addScreen(this.getClass().getName() + "> Set on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + value + "] + enter action");
        this.findControl();
        Logger.log(Level.INFO, this.getClass().getName() + "> Set on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + value + "] + enter action");
        this.control.sendKeys(value + Keys.ENTER);
        ScreenShot.addScreen(this.getClass().getName() + "> Set on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + value + "] + enter action");
    }

    public void clearSetText(String value) throws Exception {
        ScreenShot.addScreen(this.getClass().getName() + "> Clear and Set on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + value + "] ");
        this.findControl();
        Logger.log(Level.INFO, this.getClass().getName() + "> Clear and Set on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + value + "] ");
        this.control.clear();
        this.control.sendKeys(value);
        ScreenShot.addScreen(this.getClass().getName() + "> Clear and Set on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + value + "] ");
    }

    public void selectTextOption(String initialLetterOption, String finalOption) throws Exception {
        ScreenShot.addScreen(this.getClass().getName() + "> Custom Select Option on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + finalOption + "]");

        this.findControl();
        Thread.sleep(1000);
        Logger.log(Level.INFO, this.getClass().getName() + "> Custom Select Option on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + finalOption + "]");

        Logger.log(Level.INFO, this.getClass().getName() + "> Set on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + initialLetterOption + "]");
        this.control.sendKeys(initialLetterOption);
        Logger.log(Level.INFO, this.getClass().getName() + "> Click on [" + this.locator + "]" + this.getClass().getSimpleName());
        this.control.click();
        ScreenShot.addScreen(this.getClass().getName() + "> Custom Select Option on [" + this.locator + "]" + this.getClass().getSimpleName() + " the value: [" + finalOption + "]");
        Thread.sleep(1000);
        Label option = new Label(By.xpath("//li/a[contains(.,'" + finalOption + "')]"));
        option.click();


    }

    public void clear() throws Exception {
        ScreenShot.addScreen(this.getClass().getName() + "> Clear on [" + this.locator + "]" + this.getClass().getSimpleName());
        this.findControl();
        Logger.log(Level.INFO, this.getClass().getName() + "> Clear on [" + this.locator + "]" + this.getClass().getSimpleName());
        this.control.clear();
        ScreenShot.addScreen(this.getClass().getName() + "> Clear on [" + this.locator + "]" + this.getClass().getSimpleName());
    }

}
