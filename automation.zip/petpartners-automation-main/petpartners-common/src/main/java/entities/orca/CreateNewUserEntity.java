package entities.orca;

public class CreateNewUserEntity {

    private String firstName = "";
    private String lastName = "";
    private String domain = "";
    private String userName = "";
    private String emailAddress = "";

    private String administrator = "";
    private String claimSpecialist = "";
    private String test = "";

    public CreateNewUserEntity() {
    }

    public void setAdministrator(String administrator) {
        this.administrator = administrator;
    }

    public void setClaimSpecialist(String claimSpecialist) {
        this.claimSpecialist = claimSpecialist;
    }

    public void setTest(String test) {
        this.test = test;
    }

    public String getAdministrator() {
        return administrator;
    }

    public String getClaimSpecialist() {
        return claimSpecialist;
    }

    public String getTest() {
        return test;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getDomain() {
        return domain;
    }

    public String getUserName() {
        return userName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }
}
