package entities.orca;

public class IncidentEntity {

    private String onSetDate = "";
    private String incidentType = "";
    private String incidentTypeInitial = "";
    private String incidentClass = "";
    private String openDiagnosis = "";
    private String denialCode = "";


    public IncidentEntity() {
    }

    public String getIncidentTypeInitial() {
        return incidentTypeInitial;
    }

    public IncidentEntity setIncidentTypeInitial(String incidentTypeInitial) {
        this.incidentTypeInitial = incidentTypeInitial;
        return this;
    }

    public String getOnSetDate() {
        return onSetDate;
    }

    public IncidentEntity setOnSetDate(String onSetDate) {
        this.onSetDate = onSetDate;
        return this;
    }

    public String getIncidentType() {
        return incidentType;
    }

    public IncidentEntity setIncidentType(String incidentType) {
        this.incidentType = incidentType;
        return this;
    }

    public String getIncidentClass() {
        return incidentClass;
    }

    public IncidentEntity setIncidentClass(String incidentClass) {
        this.incidentClass = incidentClass;
        return this;
    }

    public String getOpenDiagnosis() {
        return openDiagnosis;
    }

    public IncidentEntity setOpenDiagnosis(String openDiagnosis) {
        this.openDiagnosis = openDiagnosis;
        return this;
    }

    public String getDenialCode() {
        return denialCode;
    }

    public IncidentEntity setDenialCode(String denialCode) {
        this.denialCode = denialCode;
        return this;
    }
}
