package entities.orca;

public class MCleadCustomerDetail {

    public String firstName = "";
    public String middleName = "";
    public String lastName = "";
    public String address1 = "";
    public String address2 = "";
    public String city = "";
    public String stateProvince = "";
    public String postalCode = "";
    public String email = "";
    public String phone = "";
    public String sendEmail = "";

    public MCleadCustomerDetail() {
    }

    public MCleadCustomerDetail setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public MCleadCustomerDetail setMiddleName(String middleName) {
        this.middleName = middleName;
        return this;
    }

    public MCleadCustomerDetail setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public MCleadCustomerDetail setAddress1(String address1) {
        this.address1 = address1;
        return this;
    }

    public MCleadCustomerDetail setAddress2(String address2) {
        this.address2 = address2;
        return this;
    }

    public MCleadCustomerDetail setCity(String city) {
        this.city = city;
        return this;
    }

    public MCleadCustomerDetail setStateProvince(String stateProvince) {
        this.stateProvince = stateProvince;
        return this;
    }

    public MCleadCustomerDetail setPostalCode(String postalCode) {
        this.postalCode = postalCode;
        return this;
    }

    public MCleadCustomerDetail setEmail(String email) {
        this.email = email;
        return this;
    }

    public MCleadCustomerDetail setPhone(String phone) {
        this.phone = phone;
        return this;
    }

    public MCleadCustomerDetail setSendEmail(String sendEmail) {
        this.sendEmail = sendEmail;
        return this;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getAddress1() {
        return address1;
    }

    public String getAddress2() {
        return address2;
    }

    public String getCity() {
        return city;
    }

    public String getStateProvince() {
        return stateProvince;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getSendEmail() {
        return sendEmail;
    }
}
