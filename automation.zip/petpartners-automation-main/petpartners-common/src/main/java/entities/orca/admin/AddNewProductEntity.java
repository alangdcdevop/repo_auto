package entities.orca.admin;

public class AddNewProductEntity {
    public String products = "";
    public String ratingType = "";
    public String termDays = "";
    public String maxAge = "";
    public String minAge = "";

    public AddNewProductEntity() {
    }

    public AddNewProductEntity setProducts(String products) {
        this.products = products;
        return this;
    }

    public AddNewProductEntity setRatingType(String ratingType) {
        this.ratingType = ratingType;
        return this;
    }
    public AddNewProductEntity setTermDays(String termDays) {
        this.termDays = termDays;
        return this;
    }
    public AddNewProductEntity setMaxAge(String maxAge) {
        this.maxAge = maxAge;
        return this;
    }
    public AddNewProductEntity setMinAge(String minAge) {
        this.minAge = minAge;
        return this;
    }

    public String getProducts() {
        return products;
    }
    public String getRatingType() {
        return ratingType;
    }
    public String getTermDays() {
        return termDays;
    }
    public String getMaxAge() {
        return maxAge;
    }
    public String getMinAge() {
        return minAge;
    }
}
