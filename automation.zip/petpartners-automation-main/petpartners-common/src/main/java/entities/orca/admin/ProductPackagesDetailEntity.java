package entities.orca.admin;

public class ProductPackagesDetailEntity {
    public String ppCode = "";
    public String ppDisplay = "";

    public ProductPackagesDetailEntity() {
    }

    public ProductPackagesDetailEntity setCode(String ppCode) {
        this.ppCode = ppCode;
        return this;
    }

    public ProductPackagesDetailEntity setDisplay(String ppDisplay) {
        this.ppDisplay = ppDisplay;
        return this;
    }

    public String getCode() {
        return ppCode;
    }

    public String getDisplay() {
        return ppDisplay;
    }

}
