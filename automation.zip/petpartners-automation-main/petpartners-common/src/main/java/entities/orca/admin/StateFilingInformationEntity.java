package entities.orca.admin;

public class StateFilingInformationEntity {
    public String state = "";
    public String marketChannel = "";
    public String underwriter = "";
    public String targetversion = "";
    public String effectiveOn = "";


    public StateFilingInformationEntity() {
    }

    public StateFilingInformationEntity setSate(String state) {
        this.state = state;
        return this;
    }

    public StateFilingInformationEntity setMarketChannel(String marketChannel) {
        this.marketChannel = marketChannel;
        return this;
    }

    public StateFilingInformationEntity setUnderwriter(String underwriter) {
        this.underwriter = underwriter;
        return this;
    }

    public StateFilingInformationEntity setTargetversion(String targetversion) {
        this.targetversion = targetversion;
        return this;
    }

    public StateFilingInformationEntity seteffectiveOn(String effectiveOn) {
        this.effectiveOn = effectiveOn;
        return this;
    }


    public String getState() {
        return state;
    }

    public String getMarketChannel() {
        return marketChannel;
    }

    public String getUnderwriter() {
        return underwriter;
    }

    public String getTargetversion() {
        return targetversion;
    }

    public String getEffectiveOn() {
        return effectiveOn;
    }


}
