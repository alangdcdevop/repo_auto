package entities.orca.breeder;

public class BreederDetailsOverviewEntity {
    public String bdFirstName = "";
    public String bdLastName = "";
    public String bdEmail = "";
    public String bdPhoneNo = "";
    public String bdAddress1 = "";
    public String bdAddress2 = "";
    public String bdCity = "";
    public String bdState = "";
    public String bdPostalCode = "";

    public BreederDetailsOverviewEntity() {
    }

    public String getBdFirstName() {
        return this.bdFirstName;
    }

    public BreederDetailsOverviewEntity setBdFirstName(String bdFirstName) {
        this.bdFirstName = bdFirstName;
        return this;
    }

    public String getBdLastName() {
        return this.bdLastName;
    }

    public BreederDetailsOverviewEntity setBdLastName(String bdLastName) {
        this.bdLastName = bdLastName;
        return this;
    }

    public String getBdEmail() {
        return this.bdEmail;
    }

    public BreederDetailsOverviewEntity setBdEmail(String bdEmail) {
        this.bdEmail = bdEmail;
        return this;
    }

    public String getBdPhoneNo() {
        return this.bdPhoneNo;
    }

    public BreederDetailsOverviewEntity setBdPhoneNo(String bdPhoneNo) {
        this.bdPhoneNo = bdPhoneNo;
        return this;
    }

    public String getBdAddress1() {
        return this.bdAddress1;
    }

    public BreederDetailsOverviewEntity setBdAddress1(String bdAddress1) {
        this.bdAddress1 = bdAddress1;
        return this;
    }

    public String getBdAddress2() {
        return this.bdAddress2;
    }

    public BreederDetailsOverviewEntity setBdAddress2(String bdAddress2) {
        this.bdAddress2 = bdAddress2;
        return this;
    }

    public String getBdCity() {
        return this.bdCity;
    }

    public BreederDetailsOverviewEntity setBdCity(String bdCity) {
        this.bdCity = bdCity;
        return this;
    }

    public String getBdState() {
        return this.bdState;
    }

    public BreederDetailsOverviewEntity setBdState(String bdState) {
        this.bdState = bdState;
        return this;
    }

    public String getBdPostalCode() {
        return this.bdPostalCode;
    }

    public BreederDetailsOverviewEntity setBdPostalCode(String bdPostalCode) {
        this.bdPostalCode = bdPostalCode;
        return this;
    }
}
