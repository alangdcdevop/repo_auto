package entities.orca.breeder;

public class LitterSearchEntity {
    private String litterRegistrationNo;

    public LitterSearchEntity() {
    }

    public String getLitterRegistrationNo() {
        return this.litterRegistrationNo;
    }

    public LitterSearchEntity setLitterRegistrationNo(String litterRegistrationNo) {
        this.litterRegistrationNo = litterRegistrationNo;
        return this;
    }

    public LitterSearchEntity(String litterRegistrationNo) {
        this.litterRegistrationNo = litterRegistrationNo;
    }
}
