package entities.orca.certificate;

public class CertificateProductDetailEntity {
    private String productColumn;
    private String benefitColumn;
    private String annualLimitAppliedColumn;
    private String annualLimitRemainingColumn;

    public CertificateProductDetailEntity(){}

    public String getProductColumn() {
        return productColumn;
    }

    public CertificateProductDetailEntity setProductColumn(String productColumn) {
        this.productColumn = productColumn;
        return this;
    }

    public String getBenefitColumn() {
        return benefitColumn;
    }

    public CertificateProductDetailEntity setBenefitColumn(String benefitColumn) {
        this.benefitColumn = benefitColumn;
        return this;
    }

    public String getAnnualLimitAppliedColumn() {
        return annualLimitAppliedColumn;
    }

    public CertificateProductDetailEntity setAnnualLimitAppliedColumn(String annualLimitAppliedColumn) {
        this.annualLimitAppliedColumn = annualLimitAppliedColumn;
        return this;

    }

    public String getAnnualLimitRemainingColumn() {
        return annualLimitRemainingColumn;
    }

    public CertificateProductDetailEntity setAnnualLimitRemainingColumn(String annualLimitRemainingColumn) {
        this.annualLimitRemainingColumn = annualLimitRemainingColumn;
        return this;
    }
}
