package entities.orca.partner;

public class PartnerDetailOverviewEntity {
    //Partner Detail Overview
    public String partnerName = "";
    public String partnerCode = "";
    public String defaultAffinityGroup = "";
    public String partnerType = "";
    public String npn = "";

    public PartnerDetailOverviewEntity() {
    }

    public String getPartnerName() {
        return partnerName;
    }

    public PartnerDetailOverviewEntity setPartnerName(String partnerName) {
        this.partnerName = partnerName;
        return this;
    }

    public String getPartnerCode() {
        return partnerCode;
    }

    public PartnerDetailOverviewEntity setPartnerCode(String partnerCode) {
        this.partnerCode = partnerCode;
        return this;
    }

    public String getDefaultAffinityGroup() {return defaultAffinityGroup;}

    public PartnerDetailOverviewEntity setDefaultAffinityGroup(String defaultAffinityGroup) {
        this.defaultAffinityGroup = defaultAffinityGroup;
        return this;
    }

    public String getPartnerType() {
        return partnerType;
    }

    public PartnerDetailOverviewEntity setPartnerType(String partnerType) {
        this.partnerType = partnerType;
        return this;
    }

    public String getNpn() {
        return npn;
    }

    public PartnerDetailOverviewEntity setNpn(String npn) {
        this.npn = npn;
        return this;
    }
}
