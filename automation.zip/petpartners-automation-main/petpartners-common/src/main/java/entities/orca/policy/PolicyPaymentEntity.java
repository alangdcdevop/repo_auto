package entities.orca.policy;

public class PolicyPaymentEntity {
    String paymentType = "";
    String creditCardType = "";
    String cardNumber = "";
    String expirationDate = "";
    String cvv = "";




    public PolicyPaymentEntity(){


    }
    public String getPaymentType() {

        return paymentType;
    }

    public String getCreditCardType() {
        return creditCardType;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public String getCvv() {
        return cvv;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public void setCreditCardType(String creditCardType) {
        this.creditCardType = creditCardType;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

}
