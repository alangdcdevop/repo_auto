package entities.orca.policy;

public class PremiumTrackerEntity {
    private String cpId;
    private String effectiveOn;
    private String endOn;
    private String netPremium;
    private String billedPremium;

    public PremiumTrackerEntity(){}


    public String getCpId() {
        return cpId;
    }

    public String getEffectiveOn() {
        return effectiveOn;
    }

    public String getEndOn() {
        return endOn;
    }

    public String getNetPremium() {
        return netPremium;
    }

    public String getBilledPremium() {
        return billedPremium;
    }

    public PremiumTrackerEntity setCpId(String cpId) {
        this.cpId = cpId;
        return this;
    }

    public PremiumTrackerEntity setEffectiveOn(String effectiveOn) {
        this.effectiveOn = effectiveOn;
        return this;
    }

    public PremiumTrackerEntity setEndOn(String endOn) {
        this.endOn = endOn;
        return this;
    }

    public PremiumTrackerEntity setNetPremium(String netPremium) {
        this.netPremium = netPremium;
        return this;
    }

    public PremiumTrackerEntity setBilledPremium(String billedPremium) {
        this.billedPremium = billedPremium;
        return this;
    }
}
