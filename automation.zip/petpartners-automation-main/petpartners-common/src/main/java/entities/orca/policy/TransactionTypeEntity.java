package entities.orca.policy;

public class TransactionTypeEntity {
    private String transactionType;
    private String paymentType;
    private String description;
    private String createdOn;
    private String amount;
    private String balance;

    public TransactionTypeEntity(){}


    public String getTransactionType() {
        return transactionType;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public String getDescription() {
        return description;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public String getAmount() {
        return amount;
    }

    public String getBalance() {
        return balance;
    }

    public TransactionTypeEntity setTransactionType(String transactionType) {
        this.transactionType = transactionType;
        return this;
    }

    public TransactionTypeEntity setPaymentType(String paymentType) {
        this.paymentType = paymentType;
        return this;
    }

    public TransactionTypeEntity setDescription(String description) {
        this.description = description;
        return this;
    }

    public TransactionTypeEntity setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
        return this;
    }

    public TransactionTypeEntity setAmount(String amount) {
        this.amount = amount;
        return this;
    }

    public TransactionTypeEntity setBalance(String balance) {
        this.balance = balance;
        return this;
    }
}