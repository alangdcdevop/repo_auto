package entities.ppi;

public class ChangeCovCompleteEnrollmentEntity {

    private String firstNameOnCard = "";
    private String lastNameOnCard = "";
    private String cardNumber = "";
    private String expiresMM = "";
    private String expiresYYYY = "";
    private String expiresCVC = "";

    public ChangeCovCompleteEnrollmentEntity() {
    }

    public ChangeCovCompleteEnrollmentEntity(String firstName, String lastName, String cardNumber, String expiresMM, String expireYYYY
            , String cvc) {
        this.firstNameOnCard = firstName;
        this.lastNameOnCard = lastName;
        this.cardNumber = cardNumber;
        this.expiresMM = expiresMM;
        this.expiresYYYY = expireYYYY;
        this.expiresCVC = cvc;
    }

    public String getFirstNameOnCard() {
        return firstNameOnCard;
    }

    public ChangeCovCompleteEnrollmentEntity setFirstNameOnCard(String firstNameOnCard) {
        this.firstNameOnCard = firstNameOnCard;
        return this;
    }

    public String getLastNameOnCard() {
        return lastNameOnCard;
    }

    public ChangeCovCompleteEnrollmentEntity setLastNameOnCard(String lastNameOnCard) {
        this.lastNameOnCard = lastNameOnCard;
        return this;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public ChangeCovCompleteEnrollmentEntity setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
        return this;
    }

    public String getExpiresMM() {
        return expiresMM;
    }

    public ChangeCovCompleteEnrollmentEntity setExpiresMM(String expiresMM) {
        this.expiresMM = expiresMM;
        return this;
    }

    public String getExpireYYYY() {
        return expiresYYYY;
    }

    public ChangeCovCompleteEnrollmentEntity setExpireYYYY(String expireYYYY) {
        this.expiresYYYY = expireYYYY;
        return this;
    }

    public String getCvc() {
        return expiresCVC;
    }

    public ChangeCovCompleteEnrollmentEntity setCvc(String cvc) {
        this.expiresCVC = cvc;
        return this;
    }
}
