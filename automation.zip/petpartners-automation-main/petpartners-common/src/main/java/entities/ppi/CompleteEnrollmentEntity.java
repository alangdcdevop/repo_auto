package entities.ppi;

public class CompleteEnrollmentEntity {

    private String firstName = "";
    private String lastName = "";
    private String address = "";
    private String aptSuite = "";
    private String city = "";
    private String state = "";
    private String zipCode = "";
    private String phoneNumber = "";
    private String emailAddress = "";
    private String groupCode = "";
    private String nameOnCard = "";
    private String cardNumber = "";
    private String expiresMM = "";
    private String expireYYYY = "";
    private String cvc = "";
    private String agreePaperLess = "";
    private String agreeApplication = "";

    public CompleteEnrollmentEntity() {
    }

    public CompleteEnrollmentEntity(String firstName, String lastName, String address, String aptSuite, String city
            , String state, String zipCode, String emailAddress, String groupCode, String nameOnCard, String cardNumber, String expiresMM, String expireYYYY
            , String cvc, String agreePaperLess, String agreeApplication) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.aptSuite = aptSuite;
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
        this.emailAddress = emailAddress;
        this.groupCode = groupCode;
        this.nameOnCard = nameOnCard;
        this.cardNumber = cardNumber;
        this.expiresMM = expiresMM;
        this.expireYYYY = expireYYYY;
        this.cvc = cvc;
        this.agreePaperLess = agreePaperLess;
        this.agreeApplication = agreeApplication;
    }

    public CompleteEnrollmentEntity(String firstName, String lastName, String address, String aptSuite, String phoneNumer, String emailAddress, String nameOnCard, String cardNumber, String expiresMM, String expireYYYY
            , String cvc) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.aptSuite = aptSuite;
        this.phoneNumber = phoneNumer;
        this.emailAddress = emailAddress;
        this.nameOnCard = nameOnCard;
        this.cardNumber = cardNumber;
        this.expiresMM = expiresMM;
        this.expireYYYY = expireYYYY;
        this.cvc = cvc;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public CompleteEnrollmentEntity setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }

    public String getFirstName() {
        return firstName;
    }

    public CompleteEnrollmentEntity setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public String getLastName() {
        return lastName;
    }

    public CompleteEnrollmentEntity setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public String getAddress() {
        return address;
    }

    public CompleteEnrollmentEntity setAddress(String address) {
        this.address = address;
        return this;
    }

    public String getAptSuite() {
        return aptSuite;
    }

    public CompleteEnrollmentEntity setAptSuite(String aptSuite) {
        this.aptSuite = aptSuite;
        return this;
    }

    public String getCity() {
        return city;
    }

    public CompleteEnrollmentEntity setCity(String city) {
        this.city = city;
        return this;
    }

    public String getState() {
        return state;
    }

    public CompleteEnrollmentEntity setState(String state) {
        this.state = state;
        return this;
    }

    public String getZipCode() {
        return zipCode;
    }

    public CompleteEnrollmentEntity setZipCode(String zipCode) {
        this.zipCode = zipCode;
        return this;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public CompleteEnrollmentEntity setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
        return this;
    }

    public String getGroupCode() {
        return groupCode;
    }

    public CompleteEnrollmentEntity setGroupCode(String groupCode) {
        this.groupCode = groupCode;
        return this;
    }

    public String getNameOnCard() {
        return nameOnCard;
    }

    public CompleteEnrollmentEntity setNameOnCard(String nameOnCard) {
        this.nameOnCard = nameOnCard;
        return this;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public CompleteEnrollmentEntity setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
        return this;
    }

    public String getExpiresMM() {
        return expiresMM;
    }

    public CompleteEnrollmentEntity setExpiresMM(String expiresMM) {
        this.expiresMM = expiresMM;
        return this;
    }

    public String getExpireYYYY() {
        return expireYYYY;
    }

    public CompleteEnrollmentEntity setExpireYYYY(String expireYYYY) {
        this.expireYYYY = expireYYYY;
        return this;
    }

    public String getCvc() {
        return cvc;
    }

    public CompleteEnrollmentEntity setCvc(String cvc) {
        this.cvc = cvc;
        return this;
    }

    public String getAgreePaperLess() {
        return agreePaperLess;
    }

    public CompleteEnrollmentEntity setAgreePaperLess(String agreePaperLess) {
        this.agreePaperLess = agreePaperLess;
        return this;
    }

    public String getAgreeApplication() {
        return agreeApplication;
    }

    public CompleteEnrollmentEntity setAgreeApplication(String agreeApplication) {
        this.agreeApplication = agreeApplication;
        return this;
    }
}
