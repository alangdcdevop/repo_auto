package entities.ppi;

public class CoverageEntity {
    public String planDetail = "";
    public String deductible = "";
    public String coinsurance = "";
    public String annualLimit = "";
    public String availableUpgrades = "";

    public CoverageEntity() {
    }

    public CoverageEntity setPlanDetail(String planDetail) {
        this.planDetail = planDetail;
        return this;
    }

    public CoverageEntity setDeductible(String deductible) {
        this.deductible = deductible;
        return this;
    }

    public CoverageEntity setCoinsurance(String coinsurance) {
        this.coinsurance = coinsurance;
        return this;
    }

    public CoverageEntity setAnnualLimit(String annualLimit) {
        this.annualLimit = annualLimit;
        return this;
    }

    public CoverageEntity setAvailableUpgrades(String availableUpgrades) {
        this.availableUpgrades = availableUpgrades;
        return this;
    }

    public String getPlanDetail() {
        return planDetail;
    }

    public String getDeductible() {
        return deductible;
    }

    public String getCoinsurance() {
        return coinsurance;
    }

    public String getAnnualLimit() {
        return annualLimit;
    }

    public String getAvailableUpgrades() {
        return availableUpgrades;
    }
}
