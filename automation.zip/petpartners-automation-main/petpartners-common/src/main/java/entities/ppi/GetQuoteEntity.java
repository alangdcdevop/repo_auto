package entities.ppi;

public class GetQuoteEntity {

    private String petName;
    private String zipCode = "";
    private String dogOrCatOption;
    private String petBreed;
    private String petAge;
    private String noOryesPetDiagnosed;
    private String emailAdress;

    // activate certificate
    private String petpartnersCertificate;
    private String akcReuniteEnrollment;
    private String activationCode;
    private String zipCodeCertificate;
    private String lookUpPet;
    private String cancel;


    public GetQuoteEntity() {
    }

    public GetQuoteEntity(String petName, String zipCode, String dogOrCatOption, String petBreed, String petAge, String noOryesPetDiagnosed, String emailAdress) {
        this.petName = petName;
        this.zipCode = zipCode;
        this.dogOrCatOption = dogOrCatOption;
        this.petBreed = petBreed;
        this.petAge = petAge;
        this.noOryesPetDiagnosed = noOryesPetDiagnosed;
        this.emailAdress = emailAdress;
    }

    public GetQuoteEntity setPetName(String petName) {
        this.petName = petName;
        return this;
    }

    public GetQuoteEntity setZipCode(String zipCode) {
        this.zipCode = zipCode;
        return this;
    }

    public GetQuoteEntity setDogOrCatOption(String dogOrCatOption) {
        this.dogOrCatOption = dogOrCatOption;
        return this;
    }

    public GetQuoteEntity setPetBreed(String petBreed) {
        this.petBreed = petBreed;
        return this;
    }

    public GetQuoteEntity setPetAge(String petAge) {
        this.petAge = petAge;
        return this;
    }

    public GetQuoteEntity setNoOryesPetDiagnosed(String noOryesPetDiagnosed) {
        this.noOryesPetDiagnosed = noOryesPetDiagnosed;
        return this;
    }

    public GetQuoteEntity setEmailAdress(String emailAdress) {
        this.emailAdress = emailAdress;
        return this;
    }

    public GetQuoteEntity setPetpartnersCertificate(String petpartnersCertificate) {
        this.petpartnersCertificate = petpartnersCertificate;
        return this;
    }

    public GetQuoteEntity setAkcReuniteEnrollment(String akcReuniteEnrollment) {
        this.akcReuniteEnrollment = akcReuniteEnrollment;
        return this;
    }

    public GetQuoteEntity setActivationCode(String activationCode) {
        this.activationCode = activationCode;
        return this;
    }

    public GetQuoteEntity setZipCodeCertificate(String zipCodeCertificate) {
        this.zipCodeCertificate = zipCodeCertificate;
        return this;
    }

    public GetQuoteEntity setLookUpPet(String lookUpPet) {
        this.lookUpPet = lookUpPet;
        return this;
    }

    public GetQuoteEntity setCancel(String cancel) {
        this.cancel = cancel;
        return this;
    }

    public String getPetName() {
        return petName;
    }

    public String getZipCode() {
        return zipCode;
    }

    public String getDogOrCatOption() {
        return dogOrCatOption;
    }

    public String getPetBreed() {
        return petBreed;
    }

    public String getPetAge() {
        return petAge;
    }

    public String getNoOryesPetDiagnosed() {
        return noOryesPetDiagnosed;
    }

    public String getEmailAdress() {
        return emailAdress;
    }

    public String getPetpartnersCertificate() {
        return petpartnersCertificate;
    }

    public String getAkcReuniteEnrollment() {
        return akcReuniteEnrollment;
    }

    public String getActivationCode() {
        return activationCode;
    }

    public String getZipCodeCertificate() {
        return zipCodeCertificate;
    }

    public String getLookUpPet() {
        return lookUpPet;
    }

    public String getCancel() {
        return cancel;
    }
}
