package factoryBrowser;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import utils.Level;
import utils.Logger;

import java.time.Duration;

public class ChromeHeadless implements IBrowser {
    @Override
    public WebDriver create() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless", "--window-size=2120,1400", "--no-sandbox", "--disable-dev-shm-usage", "--ignore-certificate-errors","--remote-allow-origins=*");
        ChromeDriver driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        driver.manage().window().maximize();
        Logger.log(Level.INFO, this.getClass().getName() + "> Creating browser with --headless --window-size=2120,1400");
        return driver;
    }
}
