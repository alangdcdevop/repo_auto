package factoryBrowser;

import java.util.HashMap;
import java.util.Map;

public class FactoryBrowser {

    private static Map<String,IBrowser> browserMap = new HashMap<>();
    public static IBrowser make(String typeBrowser) {
        browserMap.put("chrome",new Chrome());
        browserMap.put("firefox",new FireFox());
        browserMap.put("edge",new Edge());
        browserMap.put("grid_chrome",new GridChrome());
        browserMap.put("grid_edge",new GridEdge());
        browserMap.put("grid_firefox",new GridFireFox());
        browserMap.put("headless",new ChromeHeadless());

        return browserMap.containsKey(typeBrowser.toLowerCase())?
                        browserMap.get(typeBrowser.toLowerCase()):
                        browserMap.get("chrome");
    }
}
