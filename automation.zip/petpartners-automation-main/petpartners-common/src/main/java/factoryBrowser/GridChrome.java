package factoryBrowser;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import utils.Level;
import utils.Logger;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class GridChrome implements IBrowser {
    @Override
    public WebDriver create() {
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments( "--no-sandbox");
        RemoteWebDriver browser = null;
        try {
            browser = new RemoteWebDriver(new URL("http://selenium-hub:4444/wd/hub"), chromeOptions);
            browser.manage().window().setSize(new Dimension(2100, 1200));
            browser.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
            Logger.log(Level.INFO, this.getClass().getName() + "> Creating CHROME browser with http://selenium-hub:4444/wd/hub");
            return browser;
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException("FAILED!! - The selenium grid driver can not be created," + e.getMessage());
        }
    }
}
