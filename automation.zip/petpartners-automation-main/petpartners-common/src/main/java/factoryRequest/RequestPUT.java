package factoryRequest;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.io.File;

import static io.restassured.RestAssured.given;

public class RequestPUT implements IRequest {
    @Override
    public Response send(RequestInformation requestInformation) {
        RequestSpecification request;

        if (requestInformation.getMultiPartValue() == null) {
            request = given()
                    .headers(requestInformation.getHeaders())
                    .queryParams(requestInformation.getQueryParams())
                    .body(requestInformation.getBody())
                    .log().all();
        } else {
            request = given()
                    .headers(requestInformation.getHeaders())
                    .queryParams(requestInformation.getQueryParams())
                    .body(requestInformation.getBody())
                    .multiPart(requestInformation.getMultiPartKey(), new File(requestInformation.getMultiPartValue()))
                    .log().all();
        }

        Response response = request.when().put(requestInformation.getUrl());
        response.then().log().all();
        return response;
    }
}
