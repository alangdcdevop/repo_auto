package pages.akc;

import control.Button;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class CertificateOfferPage {
    public Button activateCoverageButton = new Button(By.xpath("//header[contains(@class,\"blue-header\")]//a[@title=\"Activate Coverage\"]"));

    public CertificateOfferPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }
}
