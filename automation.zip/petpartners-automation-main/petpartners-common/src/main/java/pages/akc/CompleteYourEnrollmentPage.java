package pages.akc;

import control.*;
import entities.akc.CompleteEnrollmentEntity;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class CompleteYourEnrollmentPage {

    public Label completeYourEnrollmentLabel = new Label(By.xpath("//h1[text()='Complete your enrollment']"));
    public Label policyOverviewCostLabel = new Label(By.xpath("//div[@class=\"pet-overview__premium-price\"]/span"));

    public TextBox firstNameTextBox = new TextBox(By.xpath("//input[@id='customer-firstName']"));
    public TextBox lastNameTextBox = new TextBox(By.xpath("//input[@id='customer-lastName']"));
    public TextBox addressTextBox = new TextBox(By.xpath("//input[@id='customer-address-address1']"));
    public TextBox aptSuiteEtcTextBox = new TextBox(By.xpath("//input[@id='customer-address-address2']"));
    public TextBox cityTextBox = new TextBox(By.xpath("//input[@id='customer-address-city']"));
    public Select stateTextBox = new Select(By.xpath("//select[@id='customer-address-stateProvId']"));
    public TextBox zipCodeTextBox = new TextBox(By.xpath("//input[@id='customer-address-zipCode']"));
    public TextBox phoneNumberTextBox = new TextBox(By.xpath("//input[@id='customer-phoneNumber']"));
    public TextBox emailAddressTextBox = new TextBox(By.xpath("//input[@id='customer-emailAddress']"));
    public TextBox groupCodeTextBox = new TextBox(By.xpath("//input[@id='affinity-group-code']"));
    public TextBox nameOnCardTextBox = new TextBox(By.xpath("//input[@id='customer-paymentInfo-nameOnCard']"));
    public TextBox cardNumberTextBox = new TextBox(By.xpath("//input[@id='customer-paymentInfo-cardNumber']"));
    public TextBox expiresMMTextBox = new TextBox(By.xpath("//input[@id='customer-paymentInfo-expirationMonth']"));
    public TextBox expiresYYYYTextBox = new TextBox(By.xpath("//input[@id='customer-paymentInfo-expirationYear']"));
    public TextBox expiresCVCTextBox = new TextBox(By.xpath("//input[@id='customer-paymentInfo-cvc']"));

    public Button applyButton = new Button(By.xpath("//span[text()='Apply']"));
    public RadioButton iAgreeToGoPaperlessOption = new RadioButton(By.xpath("//input[@name='electronic-delivery']"));
    public RadioButton iAgreeThatByCheckingOption = new RadioButton(By.xpath("//input[@name='e-consent']"));
    public RadioButton byCheckingBoxOption = new RadioButton(By.xpath("//input[@name=\"fee-disclosure\"]"));
    public Button enrollNowButton = new Button(By.xpath("//button[@title='Submit my enrollment']"));


    // use different billing
    public Link useDifferentBillingAddressLink = new Link(By.xpath("//label[contains(.,'Use a different billing Address')]"));
    public TextBox differentAddressTextBox = new TextBox(By.xpath("//input[@id=\"customer-paymentInfo-address-address1\"]"));
    public TextBox differentAptSuiteTextBox = new TextBox(By.xpath("//input[@id=\"customer-paymentInfo-address-address2\"]"));
    public TextBox differentCityTextBox = new TextBox(By.xpath("//input[@id=\"customer-paymentInfo-address-city\"]"));
    public Select differentStateSelect = new Select(By.xpath("//select[@id=\"customer-paymentInfo-address-stateProvId\"]"));
    public TextBox differentZipCodeTextBox = new TextBox(By.xpath("//input[@id=\"customer-paymentInfo-address-zipCode\"]"));

    public Link editPlanDetailsLink = new Link(By.xpath("//button[contains(text(),'Edit plan details')]"));
    public Link removePlanLink = new Link(By.xpath("//button[contains(text(),'Remove Plan')]"));
    public Button removePlanYesButton = new Button(By.xpath("//button[contains(text(),'Yes')]"));
    public Button removePlanNoButton = new Button(By.xpath("//button[contains(text(),'No')]"));
    public Link showTermDetailsLink = new Link(By.xpath("//button[contains(text(),'Term Details')]"));
    public Button showTermDeductible = new Button(By.xpath("//li[contains(text(),'Deductible')]"));
    public Button showTermCoinsurance = new Button(By.xpath("//li[contains(text(),'Coinsurance')]"));
    public Button showTermIncident = new Button(By.xpath("//li[contains(text(),'Incident')]"));
    public Button showTermAnnual = new Button(By.xpath("//li[contains(text(),'Annual')]"));

    public Label cartIsEmptyLabel = new Label(By.xpath("//*[@class = 'heading']//*[text() ='Your cart is empty!']"));

    public Button addAnotherPetSave = new Button(By.xpath("//button[contains(text(),'Add Another Pet')]"));

    public Map<String, ControlBase> controls = new HashMap<>();

    public CompleteYourEnrollmentPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        controls.put("FIRST NAME", firstNameTextBox);
        controls.put("LAST NAME", lastNameTextBox);
        controls.put("ADDRESS", addressTextBox);
        controls.put("APT, SUITE, ETC.", aptSuiteEtcTextBox);
        controls.put("CITY", cityTextBox);
        controls.put("STATE", stateTextBox);
        controls.put("ZIP CODE", zipCodeTextBox);
        controls.put("PHONE NUMBER", phoneNumberTextBox);
        controls.put("EMAIL ADDRESS", emailAddressTextBox);
        controls.put("Group Code", groupCodeTextBox);
        controls.put("NAME ON CARD", nameOnCardTextBox);
        controls.put("CARD NUMBER", cardNumberTextBox);
        controls.put("EXPIRES MM", expiresMMTextBox);
        controls.put("EXPIRES YYYY", expiresYYYYTextBox);
        controls.put("EXPIRES CVC", expiresCVCTextBox);
    }

    public void fillCompleteYourEnrollmentComplete(CompleteEnrollmentEntity completeEnrollmentEntity) throws Exception {
        if (!completeEnrollmentEntity.getFirstName().isEmpty())
            this.firstNameTextBox.clearSetText(completeEnrollmentEntity.getFirstName());
        if (!completeEnrollmentEntity.getLastName().isEmpty())
            this.lastNameTextBox.clearSetText(completeEnrollmentEntity.getLastName());
        if (!completeEnrollmentEntity.getAddress().isEmpty())
            this.addressTextBox.clearSetText(completeEnrollmentEntity.getAddress());
        if (!completeEnrollmentEntity.getAptSuiteEtc().isEmpty())
            this.aptSuiteEtcTextBox.clearSetText(completeEnrollmentEntity.getAptSuiteEtc());

        if (!completeEnrollmentEntity.getCity().isEmpty())
            this.cityTextBox.setText(completeEnrollmentEntity.getCity());

        if (!completeEnrollmentEntity.getState().isEmpty())
            this.stateTextBox.selectValue(completeEnrollmentEntity.getState());

        if (!completeEnrollmentEntity.getZipCode().isEmpty())
            this.zipCodeTextBox.setText(completeEnrollmentEntity.getZipCode());

        if (!completeEnrollmentEntity.getPhoneNumber().isEmpty())
            this.phoneNumberTextBox.clearSetText(completeEnrollmentEntity.getPhoneNumber());

        if (!completeEnrollmentEntity.getEmailAddress().isEmpty())
            this.emailAddressTextBox.setText(completeEnrollmentEntity.getEmailAddress());

        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,500)");
        this.nameOnCardTextBox.setText(completeEnrollmentEntity.getNameOnCard());
        this.cardNumberTextBox.setText(completeEnrollmentEntity.getCardNumber());
        this.expiresMMTextBox.setText(completeEnrollmentEntity.getExpiresMM());
        this.expiresYYYYTextBox.setText(completeEnrollmentEntity.getExpiresYYYY());
        this.expiresCVCTextBox.setText(completeEnrollmentEntity.getExpiresCVC());

        if (completeEnrollmentEntity.isUsingDifferentBilling()) {
            useDifferentBillingAddressLink.click();
            differentAddressTextBox.setText(completeEnrollmentEntity.getDifferentAddress());
            differentAptSuiteTextBox.setText(completeEnrollmentEntity.getDifferentAptSuiteEtc());
            differentCityTextBox.setText(completeEnrollmentEntity.getDifferentCity());
            differentStateSelect.selectValueUsingXpath(completeEnrollmentEntity.getDifferentState());
            differentZipCodeTextBox.setText(completeEnrollmentEntity.getDifferentZipCode());
        }

        js.executeScript("window.scrollBy(0,500)");
        if (!completeEnrollmentEntity.getGroupCode().isEmpty())
            this.groupCodeTextBox.setText(completeEnrollmentEntity.getGroupCode());

        this.iAgreeThatByCheckingOption.select();
        this.iAgreeThatByCheckingOption.select();
        if (byCheckingBoxOption.controlIsDisplayed(10))
            this.byCheckingBoxOption.select();

        this.enrollNowButton.click();
    }


}
