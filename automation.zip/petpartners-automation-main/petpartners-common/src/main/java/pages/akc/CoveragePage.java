package pages.akc;

import control.*;
import entities.akc.CoverageEntity;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class CoveragePage {

    public Label customizeYourPlanLabel = new Label(By.xpath("//h2[text()='Customize Your Plan']"));
    public Button activateInitial30DayOnlyButton = new Button(By.xpath("//button[@id=\"activate-30-day\"]"));
    public Button activateCertAndContinueCustomPlan = new Button(By.xpath("//button[@id=\"activate-enroll\"]"));
    public Button activateAnnualPlan = new Button(By.xpath("//button[@id=\"enroll-in-annual-plan\"]"));

    public Select deductibleSelect = new Select(By.xpath("//select[@id=\"deductible-amount\"]"));
    public Select coinsuranceSelect = new Select(By.xpath("//select[@id=\"coinsurance-amount\"]"));
    public Select annualLimitSelect = new Select(By.xpath("//select[@id=\"annual-level\"]"));
    public Select incidentLimitSelect = new Select(By.xpath("//select[@id=\"incident-level\"]"));

    public RadioButton examPlusOption = new RadioButton(By.xpath("//input[@id=\"NP_EXAM\"]/parent::label"));
    public RadioButton breedingCoverageOption = new RadioButton(By.xpath("//input[@id=\"BREEDER\"]/parent::label"));
    public RadioButton supportPlusOption = new RadioButton(By.xpath("//input[@id=\"FINAL_RESPECTS\"]/parent::label"));
    public RadioButton defenderPlusOption = new RadioButton(By.xpath("//input[@id=\"NP_DEFENDER_PLUS\"]/parent::label"));
    public RadioButton defenderOption = new RadioButton(By.xpath("//input[@id=\"NP_DEFENDER\"]/parent::label"));
    public RadioButton hereditaryPlusOption = new RadioButton(By.xpath("//input[@id=\"NP_INHERITED\"]/parent::label"));

    public Button addToCartButton = new Button(By.xpath("//span[text()='Add to Cart']"));

    public Link emailQuoteLink = new Link(By.xpath("//button[@id=\"email-quote-modal-button\"]"));

    //dialog
    public Button submitButton = new Button(By.xpath("//span[text()='Submit']"));
    public Label messageDialog = new Label(By.xpath("//div[@id='save-quote-success-modal']//p"));
    public Button closeButton = new Button(By.xpath("//div[@class=\"modal modal-small\"]/button[text()='Close']"));

    public Map<String, Select> selectMap = new HashMap<>();
    public Map<String, RadioButton> radioButtonMap = new HashMap<>();

    // edit pet detail
    public Link editPetLink = new Link(By.xpath("//button[@title='Return to previous Step']"));
    public Label priceMonthLabel = new Label(By.xpath("//div[@class='pet-overview__premium-price']/span"));

    public CoveragePage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        selectMap.put("DEDUCTIBLE", deductibleSelect);
        selectMap.put("COINSURANCE", coinsuranceSelect);
        selectMap.put("ANNUAL LIMIT", annualLimitSelect);
        selectMap.put("INCIDENT LIMIT", incidentLimitSelect);

        radioButtonMap.put("ExamPlus", examPlusOption);
        radioButtonMap.put("HereditaryPlus", hereditaryPlusOption);
        radioButtonMap.put("BreedingCoverage", breedingCoverageOption);
        radioButtonMap.put("SupportPlus", supportPlusOption);
        radioButtonMap.put("DefenderPlus", defenderPlusOption);
        radioButtonMap.put("Defender", defenderOption);

    }

    public Label getPetAgeLabel(String age) {
        Label petAge = new Label(By.xpath("//div[@class='pet-overview__details']/div[contains(text(),'" + age + "')]"));
        return petAge;

    }

    public Label getBreedLabel(String breed) {
        Label petBreed = new Label(By.xpath("//div[@class='pet-overview__details']/div[contains(text(),'" + breed + "')]"));
        return petBreed;

    }

    /*
  options custom / basic
   */
    public void selectPlanDetail(String option) throws Exception {
        Button planDetailButton = new Button(By.xpath("//label[@class='toggle__label']"));
        Label descriptionLabel = new Label(By.xpath("//div[contains(text(),'This option has preset limits') and @class='margin-top--1']"));

        if (descriptionLabel.controlIsDisplayed()) {
            //basic is selected
            if (option.toLowerCase().equals("custom")) {
                planDetailButton.click();  // from basic to custom
            }
        } else {
            //custom is selected
            if (option.toLowerCase().equals("basic")) {
                planDetailButton.click();  // from custom to basic
            }
        }
    }

    public void fillCoverageOption(CoverageEntity coverageEntity) throws Exception {
        Button planDetailButton = new Button(By.xpath("//label[@class='toggle__label']"));
        Label descriptionLabel = new Label(By.xpath("//div[contains(text(),'This option has preset limits') and @class='margin-top--1']"));

        if (coverageEntity.planDetail.toLowerCase().equals("custom")) {
            if (descriptionLabel.controlIsDisplayed()) {
                planDetailButton.click();
            }
            this.deductibleSelect.selectValue(coverageEntity.deductible);
            this.coinsuranceSelect.selectValue(coverageEntity.coinsurance);
            this.annualLimitSelect.selectValue(coverageEntity.annualLimit);

        } else {
            if (coverageEntity.planDetail.toLowerCase().equals("basic")) {
                planDetailButton.click();  // from custom to basic
            }
        }
    }
}