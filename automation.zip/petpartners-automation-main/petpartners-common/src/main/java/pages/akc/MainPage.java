package pages.akc;

import control.Button;
import control.Link;
import control.Select;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class MainPage {
    public Button getQuoteButton = new Button(By.xpath("//div[@class=\"nav-top__contact nav-top_img\"]//a[text()='Get Quote']"));
    public Button getQuoteFooterButton = new Button(By.xpath("//button[text()='Get Quote']"));
    public Link loginLink = new Link(By.xpath("//a[text()='Login']"));
    public TextBox petNameTextBox = new TextBox(By.id("pet-name"));
    public TextBox zipCodeTextBox = new TextBox(By.id("zipcode"));
    public Button activateCoverage = new Button(By.xpath("//a[@class=\"button activate__certificate\"]"));
    public Select signUpPopUpClose = new Select(By.xpath("//div[@title ='Close']"));

    public MainPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }
}
