package pages.akc;

import control.Label;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class MainPortalPage {
    public Label welcomeLabel = new Label(By.xpath("//h4[contains(.,'Welcome to your Customer Portal!')]"));

    public MainPortalPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }
}
