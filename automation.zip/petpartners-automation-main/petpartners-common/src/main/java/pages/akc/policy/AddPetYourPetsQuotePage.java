package pages.akc.policy;

import control.*;
import entities.akc.AddPetYourPetsQuoteEntity;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class AddPetYourPetsQuotePage {
    public TextBox petNameTextBox = new TextBox(By.xpath("//input[@formcontrolname='petName']"));
    public RadioButton dogPetTypeOption = new RadioButton(By.xpath("//input[@formcontrolname='speciesId' and @value='1']"));
    public RadioButton catPetTypeOption = new RadioButton(By.xpath("//input[@formcontrolname='speciesId' and @value='2']"));
    public Select petBreedSelect = new Select(By.xpath("//select[@formcontrolname=\"breedId\"]"));
    public Select petAgeSelect = new Select(By.xpath("//select[@formcontrolname=\"petAge\"]"));
    public RadioButton yesHasYourPetOption = new RadioButton(By.xpath("//input[@formcontrolname='hasQualifyingConditions' and @ng-reflect-value='true']"));
    public RadioButton noHasYourPetOption = new RadioButton(By.xpath("//input[@formcontrolname='hasQualifyingConditions' and @ng-reflect-value='false']"));
    public Button chooseCoverageButton = new Button(By.xpath("//button[@class='button__quote button--lg']"));

    public void fillGetQuote(AddPetYourPetsQuoteEntity addPetQuoteEntity) throws Exception {
        Logger.log(Level.INFO, this.getClass().getName() + "> Fill QUOTE: " + this.getClass().getSimpleName());
        Thread.sleep(1000);
        this.petNameTextBox.setText(addPetQuoteEntity.petName);
        Thread.sleep(2000);

        if (addPetQuoteEntity.getPetType().toLowerCase().equals("dog"))
            this.dogPetTypeOption.click();
        else if (addPetQuoteEntity.getPetType().toLowerCase().equals("cat"))
            this.catPetTypeOption.click();
        Thread.sleep(8000);
        petBreedSelect.controlIsDisplayed();
        petBreedSelect.controlIsClickable();
        petBreedSelect.selectValue(addPetQuoteEntity.getPetBreed());
        Thread.sleep(1000);
        petAgeSelect.selectValue(addPetQuoteEntity.getPetAge());

        if (addPetQuoteEntity.getHasYourPetEverBeenDiagnosed().toLowerCase().equals("yes")) {
            this.yesHasYourPetOption.click();
        } else if (addPetQuoteEntity.getHasYourPetEverBeenDiagnosed().toLowerCase().equals("no")) {
            this.noHasYourPetOption.click();
        }

        this.chooseCoverageButton.click();
        Thread.sleep(3000);
    }
}