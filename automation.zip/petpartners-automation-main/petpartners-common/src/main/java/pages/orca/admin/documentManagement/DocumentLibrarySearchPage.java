package pages.orca.admin.documentManagement;

import control.Button;
import control.Select;
import control.Table;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;
import java.util.HashMap;
import java.util.Map;


public class DocumentLibrarySearchPage {

    public Button searchButton = new Button(By.xpath("//button[text() = 'Search']"));
    public Button clearButton = new Button(By.xpath("//button[text() = 'Clear']"));
    public Table searchResultsTable = new Table(By.xpath("//table[@class='table table-bordered']"));
    public Button uploadDocumentButton = new Button(By.xpath("//button[text()=' Upload Document ']"));
    public Button nextButton = new Button(By.xpath("//button[normalize-space()='Next']"));

    public Table summaryTable = new Table (By.xpath("//div[@class='col-8']//div[@class='card-body']"));

    public TextBox termDays = new TextBox(By.xpath("//input[@formcontrolname='termDays']"));
    public Map<String, Select> searchOptions = new HashMap<>();
    public Map<String,Select> documentInformation = new HashMap<>();
    public Map<String,Button> commonButton = new HashMap<>();
    public DocumentLibrarySearchPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        searchOptions.put("Market Channel", new Select(By.xpath("//select[@formcontrolname='marketChannelId']")));
        searchOptions.put("Document Version", new Select(By.xpath("//select[@formcontrolname='documentVersionId']")));
        searchOptions.put("Select State", new Select(By.xpath("//select[@formcontrolname='stateProvId']")));
        searchOptions.put("Document Type", new Select(By.xpath("//select[@formcontrolname='documentTypeId']")));
        searchOptions.put("Product", new Select(By.xpath("//select[@formcontrolname='productId']")));

        documentInformation.put("Document Version",new Select(By.xpath("//select[@formcontrolname='documentVersionId']")));
        documentInformation.put("Market Channel" , new Select(By.xpath("//select[@formcontrolname='documentVersionId']")));
        documentInformation.put("Document Type" ,new Select(By.xpath("//select[@formcontrolname='documentTypeId']")));
        documentInformation.put("Product" ,new Select(By.xpath("//select[@formcontrolname='productId']")));
        documentInformation.put("State" , new Select(By.xpath("//select[@formcontrolname='stateProvId']")));

        commonButton.put("Previous", new Button(By.xpath("//button[normalize-space()='Previous']")));
        commonButton.put("Exit",new Button(By.xpath("//button[normalize-space()='Exit']")));
        commonButton.put("Next",new Button(By.xpath("//button[normalize-space()='Next']")));
        commonButton.put("Yes ,I want to exit",new Button(By.xpath("//button[normalize-space()='Yes, I want to Exit']")));

    }
}
