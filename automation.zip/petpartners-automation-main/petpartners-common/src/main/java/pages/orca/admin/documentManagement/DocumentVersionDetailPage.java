package pages.orca.admin.documentManagement;

import control.Button;
import control.Checkbox;
import control.Label;
import control.TextBox;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class DocumentVersionDetailPage {

    public TextBox displayTextBox = new TextBox(By.xpath("//label[contains(.,'Display')]/parent::*/input"));
    public TextBox documentVersionIdTextBox = new TextBox(By.xpath("//label[contains(.,'Document Version Id')]/parent::*/input"));
    public TextBox createdOnTextBox = new TextBox(By.xpath("//label[contains(.,'Created On')]/parent::*/input"));
    public TextBox modifiedOnTextBox = new TextBox(By.xpath("//label[contains(.,'Modified On')]/parent::*/input"));
    public Checkbox activeCheckBox = new Checkbox(By.xpath("//label[contains(.,'Active')]/parent::*/input"));
    public Button cancelButton = new Button(By.xpath("//button[contains(.,'Cancel')]"));
    public Button saveButton = new Button(By.xpath("//button[contains(.,'Save')]"));
    public Button documentEditButton = new Button(By.xpath("//button[@class='btn btn-info ms-auto']"));

    //Associations
    public Button addAssociationsButton = new Button(By.xpath("//button[contains(.,'Add Associations')]"));
    public Button removeDocAreaButton = new Button(By.xpath("//ng-select[@formcontrolname='documentAreaId']//span[@title='Clear all']"));
    public Button associationsSaveButton = new Button(By.xpath("//button[@id='saveButton']"));
    public Button associationsEditButton = new Button(By.xpath("//button[@class='btn btn-info me-1']"));
    public Label  warningMessage = new Label(By.xpath("//strong[normalize-space()='Document Area Selection Required']"));
    public TextBox documentTypeTextBox =  new TextBox(By.xpath("//pp-document-version-document-type[last()]//span[contains(.,'Document Type')]/..//input"));
    public TextBox documentAreaTextBox =  new TextBox(By.xpath("//pp-document-version-document-type[last()]//span[contains(.,'Document Area')]/..//input"));
    public TextBox productTextBox =  new TextBox(By.xpath("//pp-document-version-document-type[last()]//span[contains(.,'Product')]/..//input"));

    public Map<String, TextBox> textBoxMap = new HashMap<>();
    public DocumentVersionDetailPage(){
        textBoxMap.put("Document Version Id",documentVersionIdTextBox);
        textBoxMap.put("Display",displayTextBox);
        textBoxMap.put("Created On",createdOnTextBox);
        textBoxMap.put("Modified On",modifiedOnTextBox);
    }
}