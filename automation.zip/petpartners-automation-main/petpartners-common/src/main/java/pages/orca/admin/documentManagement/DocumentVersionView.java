package pages.orca.admin.documentManagement;

import control.Button;
import control.Table;
import org.openqa.selenium.By;

public class DocumentVersionView {

    public Button createDocumentVersionButton = new Button(By.xpath("//button[text()='Create a Document Version']"));
    public Table documentVersionTable =  new Table(By.xpath("//table[@class='table table-bordered']"));

}