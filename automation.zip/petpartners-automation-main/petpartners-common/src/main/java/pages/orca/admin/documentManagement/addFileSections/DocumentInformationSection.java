package pages.orca.admin.documentManagement.addFileSections;

import control.Select;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class DocumentInformationSection {
    public Select documentVersionSelect = new Select(By.xpath("//select[@formcontrolname=\"documentVersionId\"]"));
    public Select documentTypeSelect = new Select(By.xpath("//select[@formcontrolname=\"documentTypeId\"]"));
    public Select selectStateSelect = new Select(By.xpath("//select[@formcontrolname=\"stateProvId\"]"));
    public Select marketChannelSelect = new Select(By.xpath("//select[@formcontrolname=\"marketChannelId\"]"));
    public Select productSelect = new Select(By.xpath("//select[@formcontrolname=\"productId\"]"));

    public Map<String,Select> controlSelect =  new HashMap<>();

    public DocumentInformationSection (){
        controlSelect.put("Document Version",documentVersionSelect);
        controlSelect.put("Document Type",documentTypeSelect);
        controlSelect.put("Select State",selectStateSelect);
        controlSelect.put("Market Channel",marketChannelSelect);
        controlSelect.put("Product",productSelect);
    }

}
