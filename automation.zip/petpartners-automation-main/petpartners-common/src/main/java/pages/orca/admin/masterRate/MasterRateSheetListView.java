package pages.orca.admin.masterRate;

import control.Button;
import control.Table;
import org.openqa.selenium.By;

public class MasterRateSheetListView {
    public Button addMasterRateSheetButton = new Button(By.xpath("//button[contains(text(),'Add Master Rate Sheet')]"));
    public Table masterRateSheetTable = new Table(By.xpath("//table"));
}
