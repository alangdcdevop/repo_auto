package pages.orca.admin.productManagement;

import control.Button;
import control.Select;
import org.openqa.selenium.By;
import pages.orca.admin.productManagement.addNewFilingSections.*;

public class AddNewFilingPage {
    public Button nextButton = new Button(By.xpath("//button[contains(text(),'Next')]"));
    public Button previewButton = new Button(By.xpath("//button[contains(text(),'Previous')]"));
    public Button completeButton = new Button(By.xpath("//button[contains(text(),'Complete')]"));
    public Button exitButton = new Button(By.xpath("//button[contains(text(),'Exit')]"));
    public StateFilingInformationSection stateFilingInformationSection = new StateFilingInformationSection();
    public StateRulesSection stateRulesSection = new StateRulesSection();
    public ChooseProductSection chooseProductSection = new ChooseProductSection();
    public SetRatesSection setRatesSection = new SetRatesSection();
    public SummaryReviewSection summaryReviewSection = new SummaryReviewSection();
    public SelectDocumentsSection selectDocumentsSection = new SelectDocumentsSection();

    public  Select selectUnderwriter = new Select(By.xpath("//select[@formcontrolname='underwriterId']"));

}
