package pages.orca.admin.productManagement;

import control.*;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;
import java.util.HashMap;
import java.util.Map;

public class ProductManagementPage {

    public Select productTypeDropDown = new Select(By.cssSelector(".form-select.ng-untouched.ng-pristine"));
    public TextBox codeTextBox = new TextBox(By.xpath("//input[@formcontrolname='code']"));
    public TextBox displayTextBox = new TextBox(By.xpath("//input[@formcontrolname='display']"));
    public Table productListTable = new Table(By.xpath("//table[@class='table table-bordered']"));
    public TextBox quantityTextBox = new TextBox(By.xpath("//input[@formcontrolname='quantity']"));
    public Link productLink = new Link(By.xpath(" //a[contains(text(),' CompanionPlus ')]"));
    public Button packagedetailEditButton = new Button(By.xpath("//button[@class='btn btn-info ms-auto']"));
    public Map<String, Button> productManagement = new HashMap<>();

    public ProductManagementPage() {

        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        productManagement.put("Add Product", new Button(By.xpath("//button[text()='Add Product']")));
        productManagement.put("Save", new Button(By.id("saveButton")));
        productManagement.put("Edit", new Button(By.xpath("//div[@class='card-header']//button[@type='button']")));
    }
}
