package pages.orca.admin.productManagement;

import control.Button;
import control.Checkbox;
import control.TextBox;
import entities.orca.admin.AddNewProductEntity;
import entities.orca.admin.ProductPackagesDetailEntity;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class ProductPackageDetailPage {
    public TextBox codeTextBox = new TextBox(By.xpath("//input[@formcontrolname='code']"));
    public TextBox displayTextBox = new TextBox(By.xpath("//input[@formcontrolname='display']"));
    public Button productPackageDetailSaveButton = new Button(By.xpath("//button[@id ='saveButton']"));
    public Button addParentProductButton = new Button(By.xpath("//button[contains(text(),'Add Parent Product')]"));
    public Button packageEditButton = new Button(By.xpath("//button[@class='btn btn-info ms-auto']"));
    public Checkbox packageActive = new Checkbox(By.xpath("//input[@formcontrolname='active']"));

    public TextBox productDisabledText = new TextBox(By.xpath("//ng-select[@formcontrolname='productId']//span[@class='ng-value-label']"));
    public TextBox ratingTypeDisabledText = new TextBox(By.xpath("//ng-select[@formcontrolname='ratingTypeId']//span[@class='ng-value-label']"));
    public TextBox productsTextBox = new TextBox(By.xpath("//ng-select[@formcontrolname='productId']//input[@type='text']"));
    public TextBox ratingTypeTextBox = new TextBox(By.xpath("//ng-select[@formcontrolname='ratingTypeId']//input[@type='text']"));
    public TextBox termDaysTextBox = new TextBox(By.xpath("//input[@formcontrolname='termDays']"));
    public TextBox maxAgeTextBox = new TextBox(By.xpath("//input[@formcontrolname='maxAge']"));
    public TextBox minAgeTextBox = new TextBox(By.xpath("//input[@formcontrolname='minAge']"));
    public Button parentProductsSaveButton = new Button(By.xpath("//div[@id='productsContainer']//button[@id ='saveButton']"));
    public Button productsEditButton = new Button(By.xpath("//button[@class= 'btn btn-info ms-auto']"));
    public TextBox productGroupTextBox = new TextBox(By.xpath("//span[text()=' Product Group ']/parent::*/ng-select//input"));
    public TextBox childProductDisabledText = new TextBox(By.xpath("//div[@id='childProductsContainer']//ng-select[@formcontrolname='productId']//span[@class='ng-value-label']"));
    public TextBox childRatingTypeDisabledText = new TextBox(By.xpath("//div[@id='childProductsContainer']//ng-select[@formcontrolname='ratingTypeId']//span[@class='ng-value-label']"));
    public Button addChildProductButton = new Button(By.xpath("//button[contains(text(),'Add Child Product')]"));
    public TextBox childProductGroupTextBox = new TextBox(By.xpath("//span[text()=' Product Group ']/parent::*/ng-select//input"));
    public TextBox childProductTextBox = new TextBox(By.xpath("//div[@id='childProductsContainer']//ng-select[@formcontrolname='productId']//input[@type='text']"));
    public TextBox childRatingTypeTextBox = new TextBox(By.xpath("//div[@id='childProductsContainer']//ng-select[@formcontrolname='ratingTypeId']//input[@type='text']"));
    public TextBox childMaxAgeTextBox = new TextBox(By.xpath("//div[@id='childProductsContainer']//input[@formcontrolname='maxAge']"));
    public TextBox childMinAgeTextBox = new TextBox(By.xpath("//div[@id='childProductsContainer']//input[@formcontrolname='minAge']"));
    public Button childProductsSaveButton = new Button(By.xpath("//div[@id='childProductsContainer']//button[@id ='saveButton']"));

    public void fillProductPackageDetails(ProductPackagesDetailEntity productPackagesDetailEntity) throws Exception {
        Logger.log(Level.INFO, this.getClass().getName() + "> fillProductPackageDetails: " + this.getClass().getSimpleName());
        this.codeTextBox.setText(productPackagesDetailEntity.ppCode);
        this.displayTextBox.setText(productPackagesDetailEntity.ppDisplay);
    }

    public void fillAddNewProductDetails(String sType, AddNewProductEntity addNewProductEntity) throws Exception {
        if (sType.equals("parent")) {
            Logger.log(Level.INFO, this.getClass().getName() + "> fillAddParentProductDetails: " + this.getClass().getSimpleName());
            Thread.sleep(2000);
            this.productsTextBox.setTextAndEnter(addNewProductEntity.products);
            this.ratingTypeTextBox.setTextAndEnter(addNewProductEntity.ratingType);
            this.termDaysTextBox.clearSetText(addNewProductEntity.termDays);
            this.maxAgeTextBox.clearSetText(addNewProductEntity.maxAge);
            this.minAgeTextBox.clearSetText(addNewProductEntity.minAge);
            Thread.sleep(2000);
            this.parentProductsSaveButton.click();
        }else{
            Logger.log(Level.INFO, this.getClass().getName() + "> fillAddChildProductDetails: " + this.getClass().getSimpleName());
            if(childProductGroupTextBox.controlIsDisplayed()) {
                this.childProductGroupTextBox.setTextAndEnter("Upgrades");
            }
            this.childProductTextBox.setTextAndEnter(addNewProductEntity.products);
            this.childRatingTypeTextBox.setTextAndEnter(addNewProductEntity.ratingType);
            this.childMaxAgeTextBox.clearSetText(addNewProductEntity.maxAge);
            this.childMinAgeTextBox.clearSetText(addNewProductEntity.minAge);
            this.childProductsSaveButton.click();
        }
        Thread.sleep(2000);

    }
}
