package pages.orca.admin.productManagement;

import control.Button;
import control.Link;
import control.Table;
import org.openqa.selenium.By;


public class ProductPackagesPage {
    public Link productPackagesLeftLink = new Link(By.xpath("//a[contains(text(),' Product Packages ')]"));
    public Button createProductPackageButton = new Button(By.xpath("//button[contains(text(),'Create a Product Package')]"));
    public Table productPackagesTable = new Table(By.xpath("//table[@class='table table-bordered']"));
}

