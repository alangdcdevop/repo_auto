package pages.orca.admin.productManagement.addNewFilingSections;

import control.Label;
import control.Select;
import control.TextBox;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class SetRatesSection {

    public Select selectRatingSpreadsheetSelect = new Select(By.xpath("//select[@formcontrolname=\"masterRateSheet\"]"));

    public TextBox ratingFormulaTextBox = new TextBox(By.xpath("//input[@formcontrolname=\"ratingFormula\"]"));
    public TextBox rateTextBox = new TextBox(By.xpath("//input[@formcontrolname=\"rateVersion\"]"));

    public Select ageSelect =  new Select(By.xpath("//label[contains(text(),'Age')]/../select"));
    public Select breedSelect =  new Select(By.xpath("//label[contains(text(),'Breed')]/../select"));
    public Select expressionSelect =  new Select(By.xpath("//label[contains(text(),'Expression')]/../select"));
    public Select baseRateSelect =  new Select(By.xpath("//label[contains(text(),'Base Rate')]/../select"));
    public Select coinsuranceSelect =  new Select(By.xpath("//label[contains(text(),'Coinsurance')]/../select"));
    public Select deductibleSelect =  new Select(By.xpath("//label[contains(text(),'Deductible')]/../select"));
    public Select discountSelect =  new Select(By.xpath("//label[contains(text(),'Discount')]/../select"));
    public Select endorsementSelect =  new Select(By.xpath("//label[contains(text(),'Endorsement')]/../select"));
    public Select maxIncreaseSelect =  new Select(By.xpath("//label[contains(text(),'Max Increase')]/../select"));
    public Select policyYearSelect =  new Select(By.xpath("//label[contains(text(),'Policy Year')]/../select"));
    public Select trendRateSelect =  new Select(By.xpath("//label[contains(text(),'Trend Rate')]/../select"));
    public Select zipSelect =  new Select(By.xpath("//label[contains(text(),'Zip')]/../select"));
    public Label setRateLabel = new Label(By.xpath("//label[text()='Set Rates']"));

    public Map<String,Select> mapSelectControl = new HashMap<>();
    public SetRatesSection(){
        mapSelectControl.put("Select Rating Spreadsheet",selectRatingSpreadsheetSelect);
        mapSelectControl.put("Age",ageSelect);
        mapSelectControl.put("Breed",breedSelect);
        mapSelectControl.put("Expression",expressionSelect);
        mapSelectControl.put("Base Rate",baseRateSelect);
        mapSelectControl.put("Coinsurance",coinsuranceSelect);
        mapSelectControl.put("Deductible",deductibleSelect);
        mapSelectControl.put("Discount",discountSelect);
        mapSelectControl.put("Endorsement",endorsementSelect);
        mapSelectControl.put("Max Increase",maxIncreaseSelect);
        mapSelectControl.put("Policy Year",policyYearSelect);
        mapSelectControl.put("Trend Rate",trendRateSelect);
        mapSelectControl.put("Zip",zipSelect);

    }

}
