package pages.orca.admin.productManagement.addNewFilingSections;

import control.DatePickerGrid;
import control.Select;
import entities.orca.admin.StateFilingInformationEntity;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class StateFilingInformationSection {

    public Select stateDropDown = new Select(By.xpath("//select[@formcontrolname='stateProvId']"));
    public Select marketChannelDropDown = new Select(By.xpath("//select[@formcontrolname='marketChannelId']"));
    public Select underwriterIdDropDown = new Select(By.xpath("//select[@formcontrolname='underwriterId']"));
    public DatePickerGrid effectiveonDatePickerGrid = new DatePickerGrid(By.xpath("//span[@class='input-group-text cursor--pointer']"));
    public Select targetVersionDropDown = new Select(By.xpath("//select[@formcontrolname='versionNo']"));

    public StateFilingInformationSection(){}

    public void fillstateFilingInformation(StateFilingInformationEntity stateFillingInformationEntity) throws Exception {
        Logger.log(Level.INFO, this.getClass().getName() + ">State Filling Information Section: " + this.getClass().getSimpleName());
        this.stateDropDown.selectValueContainsOption(stateFillingInformationEntity.state);
        this.marketChannelDropDown.selectValueContainsOption(stateFillingInformationEntity.marketChannel);
        this.underwriterIdDropDown.selectValueContainsOption(stateFillingInformationEntity.underwriter);
        this.targetVersionDropDown.selectValueContainsOption(stateFillingInformationEntity.targetversion);
        this.effectiveonDatePickerGrid.click();
    }
}
