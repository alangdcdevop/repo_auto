package pages.orca.admin.productManagement.addNewFilingSections;

import control.Checkbox;
import control.Select;
import control.TextBox;
import entities.orca.admin.StateRulesEntity;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class StateRulesSection {

    //Certificates

    public Checkbox isCertEligibleCheckBox = new Checkbox(By.xpath("//input[@formcontrolname=\"isCertEligible\"]"));
    public Checkbox cancelCertCheckBox = new Checkbox(By.xpath("//input[@formcontrolname=\"isCancelCert\"]"));
    public Checkbox cancelCertNotifyCheckBox = new Checkbox(By.xpath("//input[@formcontrolname=\"isCancelCertNotify\"]"));


    //Notification/Cancel Days

    public Select dnocTypeSelect = new Select(By.xpath("//select[@formcontrolname=\"dnocTypeId\"]"));
    public TextBox serviceFeeTextBox = new TextBox(By.xpath("//input [@formcontrolname='serviceFee']"));
    public TextBox notifyTextBox = new TextBox(By.xpath("//input[@formcontrolname=\"notificationDays\"]"));

    public TextBox cancelTextBox = new TextBox(By.xpath("//input[@formcontrolname=\"cancelDays\"]"));
    public TextBox cancelOverride = new TextBox(By.xpath("//input[@formcontrolname='cancelDaysOverride']"));
    public Checkbox leadFeeCapCheckBox = new Checkbox(By.xpath("//input [@class='form-control w-25 ng-untouched ng-pristine ng-valid']"));

    public TextBox startsOn = new TextBox(By.xpath("//input [@formcontrolname='cancelStartDate']"));
    public TextBox endsOn = new TextBox(By.xpath("//input [@formcontrolname='cancelEndDate']"));

    // last subsection
    public TextBox leedFeeCapTextBox = new TextBox(By.xpath("//input[@formcontrolname=\"leadFeeCap\"]"));
    public Select allowElectricDeliveryDropDown=new Select(By.xpath("//select[@formcontrolname=\"electronicDeliveryId\"]"));

    public Map<String, TextBox>  textBoxControlMap = new HashMap<>();
    public StateRulesSection(){
        textBoxControlMap.put("Service Fee",serviceFeeTextBox);
        textBoxControlMap.put("Notify",notifyTextBox);
        textBoxControlMap.put("Cancel",cancelTextBox);
        textBoxControlMap.put("Cancel Override",cancelOverride);
        textBoxControlMap.put("Starts On",startsOn);
        textBoxControlMap.put("Ends On",endsOn);
        textBoxControlMap.put("Lead Fee Cap",leedFeeCapTextBox);
    }
    public void fillStateFilingInformationStateRulessection(StateRulesEntity stateRulesEntity) throws Exception {
        Logger.log(Level.INFO, this.getClass().getName() + ">fillstateFilingInformationStateRulessection: " + this.getClass().getSimpleName());
        if (!stateRulesEntity.getCancelOverride().isEmpty())
            this.cancelOverride.setText(stateRulesEntity.getCancelOverride());
        if (!stateRulesEntity.getLeadFeeCap().isEmpty())
            this.serviceFeeTextBox.setText(stateRulesEntity.getLeadFeeCap());
        if (!stateRulesEntity.getAllowElectricDeliveryDropDown().isEmpty())
            this.allowElectricDeliveryDropDown.selectValueContainsOption(stateRulesEntity.getAllowElectricDeliveryDropDown());
        if (!stateRulesEntity.getServiceFee().isEmpty())
            this.serviceFeeTextBox.setText(stateRulesEntity.getServiceFee());
    }
}
