package pages.orca.affiliate;

import control.*;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;


import java.util.HashMap;
import java.util.Map;

public class AffiliatePage {
    public Map<String, Button> affiliatesMap = new HashMap<>();

    public TextBox affiliateNameTexBox = new TextBox(By.id("AffiliateName"));
    public Checkbox activeCheckBox = new Checkbox(By.id("Active"));
    public TextBox receivablesNameTextBox = new TextBox(By.xpath("//*[@id=\"ReceivablesName\"]"));
    public TextBox adress1TexeBox = new TextBox(By.id("Address1"));
    public TextBox cityTextBox = new TextBox(By.id("City"));
    public Select stateDropdown = new Select(By.id("State"));

    public TextBox postalCodeTextBox = new TextBox(By.id("PostalCode"));
    public TextBox searchAffiliateNameTextBox = new TextBox(By.id("SearchCriteria_Display"));

    public Table searchResultTable = new Table(By.xpath("//*[@id=\"groups-table\"]"));
    public  Select leadFeeTierDropdown=new Select(By.id("LeadFeeTierId"));

    public AffiliatePage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        affiliatesMap.put("addAffiliate", new Button(By.xpath("//a[text()='Add Affiliate']")));
        affiliatesMap.put("Dashboard", new Button(By.xpath("//a[text()='Dashboard']")));
        affiliatesMap.put("Lead Fee Tiers", new Button(By.xpath("//a[text()='Lead Fee Tiers']")));
        affiliatesMap.put("Save",new Button(By.xpath("//button[normalize-space()='Save']")));
        affiliatesMap.put("Cancel",new Button(By.xpath("//a[normalize-space()='Cancel']")));
        affiliatesMap.put("Run Search",new Button(By.id("btn-run-search")));
        affiliatesMap.put("Clear",new Button(By.xpath("//a[text()='Clear']")));
    }
}
