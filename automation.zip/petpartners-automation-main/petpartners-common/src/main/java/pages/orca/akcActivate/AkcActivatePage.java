package pages.orca.akcActivate;

import control.Button;
import control.RadioButton;
import control.TextBox;
import org.openqa.selenium.By;

public class AkcActivatePage {

    public Button activateCoverageButton = new Button(By.xpath("//*[@id=\"navigation-top\"]/div[1]/div/div/div/a[3]"));

    public Button activateCoverageButton2 = new Button(By.xpath("//*[@id=\"main\"]/header/div/div/div[1]/div[3]/div/a"));

    public TextBox registrationNumberTexbox = new TextBox((By.xpath("//*[@id='reg_no']")));

    public TextBox zipCodeTextbox = new TextBox((By.xpath("//*[@id='zipcode']")));

    public Button lookupPetButton = new Button(By.id("find-registration"));

    public RadioButton noHasYourPetOption = new RadioButton(By.xpath("//*[@id=\"step1\"]/div[6]/div/label[2]/span"));

    public RadioButton yesHasYourPetOption = new RadioButton(By.xpath("//*[@id=\"step1\"]/div[6]/div/label[1]/span"));

    public Button chooseCoverageButton = new Button(By.xpath("//button[@id='submit']"));

    public Button initial30DaysOfPet = new Button(By.id("activate-30-day"));

    public RadioButton applicationAcknowledmentButton = new RadioButton(By.xpath("//*[@name='e-consent']"));

    public Button enrollNowButton = new Button(By.xpath("//*[@id=\"enrollNowButton\"]"));

    public Button electronicallySignButton = new Button(By.xpath("//input[@name='fee-disclosure']"));
}
