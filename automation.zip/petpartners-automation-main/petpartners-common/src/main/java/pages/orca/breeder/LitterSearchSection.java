package pages.orca.breeder;

import control.Button;
import control.Label;
import control.Link;
import control.TextBox;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.By;

public class LitterSearchSection {
    public TextBox lsLitterRegistrationNoTextBox = new TextBox(By.xpath("//input[@id=\"LitterSearchCriteria_LitterRegNo\"]"));
    public Button litterRunSearchButton = new Button(By.xpath("//button[@class=\"btn btn-success\"]"));
    public Label litterDetailsLabel = new Label(By.xpath("//a[@id=\"litter-search-link\"]"));
    public Link litterRegNoLink = new Link(By.cssSelector("a.selector"));
    public Button litterChangeBreederButton = new Button(By.xpath("//a[@class=\"ajax-get pull-right btn btn-primary\"]"));
    public Map<String, TextBox> textBoxMap = new HashMap();
    public Button bsRunSearchButton = new Button(By.xpath("//button[@class=\"btn btn-success pull-right\"]"));
    public Button litterAddLitterButton = new Button(By.xpath("//a[@href=\"/Breeder/LitterDetail?litterId=0\"]"));


    public LitterSearchSection() {
        this.textBoxMap.put("Litter Registration No", this.lsLitterRegistrationNoTextBox);
    }
}
