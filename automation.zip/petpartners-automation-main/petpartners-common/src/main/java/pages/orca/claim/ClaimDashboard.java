package pages.orca.claim;

import control.Button;
import control.Link;
import control.Select;
import control.Table;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class ClaimDashboard {

    public Map<String, Button> buttonMap = new HashMap<>();

    public Map<String,Button> dashBoardMap = new HashMap<>();
    public Map<String, Link>  linksMap = new HashMap();
    public Select selectUserSelect = new Select(By.id("selected-sysuser-id"));
    public Table assignedTable = new Table(By.xpath("//a[contains(., 'Assigned')]/parent::*/parent::*/parent::*//table[@class='table table-striped table-bordered tablesorter']"));

    public ClaimDashboard() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        buttonMap.put("Start prepping claim", new Button(By.xpath("//a[contains(.,'Start prepping claim')]")));
        buttonMap.put("Get Investigative Claim", new Button(By.xpath("//a[contains(.,'Get Investigative Claim')]")));
        buttonMap.put("Get Quick Claim", new Button(By.xpath("//a[contains(.,'Get Quick Claim')]")));
        buttonMap.put("Retrieve for Audit", new Button(By.xpath("//a[contains(.,'Retrieve for Audit')]")));


        linksMap.put("Turn Around Time - Assistants queue", new Link(By.xpath("//a[contains(text(),'Turn Around Time - Assistants queue')]")));
        linksMap.put("Turn Around Time - Investigative queue ", new Link(By.xpath("//a[contains(text(),'Turn Around Time - Investigative queue')]")));
        linksMap.put("Turn Around Time - Quick Claims queue", new Link(By.xpath("//a[contains(text(),'Turn Around Time - Quick Claims queue')]")));
        linksMap.put("Received", new Link(By.xpath("//a[contains(text(),'Received')]")));
        linksMap.put("Processing", new Link(By.xpath("//a[contains(text(),'Processing')]")));
        // todo  add all the links here
        linksMap.put("Assigned", new Link(By.xpath("//a[contains(text(),'Assigned')]")));




        dashBoardMap.put("Adjuster profile",new Button(By.xpath("//a[text()='Adjuster Profiles']")));
        dashBoardMap.put("My Dashboard",new Button(By.xpath("//a[text()='My Dashboard']")));
        dashBoardMap.put("Claim Team Inbox",new Button(By.xpath("//a[text()='Claims Team Inbox']")));
        dashBoardMap.put("Issue Claim",new Button(By.xpath("//a[text()='Issue Claims']")));
        dashBoardMap.put("EOB Notes",new Button(By.xpath("//a[text()='EOB Notes']")));
        dashBoardMap.put("Search for Claim",new Button(By.xpath("//a[text()='Search for a Claim']")));


    }

}