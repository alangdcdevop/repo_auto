package pages.orca.common;

import control.Label;
import org.openqa.selenium.By;

public class LoadingSection {

    public Label loadingSpinnerHiddenImage = new Label(By.xpath("//div[@class=\"progress-loader\" and @hidden]"));
}
