package pages.orca.customer;

import control.Button;
import control.Link;
import control.Table;
import control.TextBox;
import org.openqa.selenium.By;

public class CustomerDetailsPage {
    public TextBox firstNameTextBox = new TextBox(By.xpath("//input[@id='Customer_FirstName']"));
    public Button saveButton = new Button(By.xpath("//button[@class='disable-after-click btn btn-success']"));
    public Link notesLink = new Link(By.xpath("//a[@title='Note(s)']"));
    public Table notesTab = new Table(By.xpath("//div[@id='notes-table']"));
}
