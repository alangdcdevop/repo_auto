package pages.orca.followUps;

import control.Button;
import control.Select;
import org.openqa.selenium.By;


public class FollowUpsPage {

    public Button addNewButtonFollowUps = new Button(By.xpath("//a[@title='Create Followup'][normalize-space()='Add New']"));
    public Select complainTypeDropDown = new Select(By.id("Followup_complaint_type_id"));
    public Select followupTypeDropDown = new Select(By.id("Followup_followup_type_id"));
    public Button saveButtonFollowUpPage = new Button(By.xpath("//button[normalize-space()='Save']"));
    public Button cancelButtonFollowUpPage = new Button(By.xpath("//a[@title='Cancel']"));

}
