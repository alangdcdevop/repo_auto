package pages.orca.login;

import control.Button;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class ForgotPasswordPage {
    public TextBox emailTextBox = new TextBox(By.id("Email"));
    public Button submitButton = new Button(By.xpath("//button[text()='Submit']"));

    public ForgotPasswordPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }
}
