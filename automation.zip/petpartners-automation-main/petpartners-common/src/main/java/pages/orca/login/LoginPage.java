package pages.orca.login;


import control.*;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;


public class LoginPage {
    public TextBox emailTextBox = new TextBox(By.id("Email"));
    public TextBox passwordTextBox = new TextBox(By.id("Password"));
    public Button loginButton = new Button(By.xpath("//button[text()='Login']"));
    public Link forgotPasswordLink = new Link(By.xpath("//a[text()='Forgot Password?']"));
    public Link registerAccountLink = new Link(By.xpath("//a[text()='Register Account']"));
    public Label messageLabel = new Label(By.xpath("//div[@class='alert alert-success']"));

    public Label messageErrorLabel = new Label(By.xpath("//div[@class=\"alert alert-error\"]"));

    public Map<String, ControlBase> controlsLoginPageMap= new HashMap<>();

    public LoginPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        controlsLoginPageMap.put("Email",emailTextBox);
        controlsLoginPageMap.put("Password",passwordTextBox);
        controlsLoginPageMap.put("Login Button",loginButton);
        controlsLoginPageMap.put("Forgot Password",forgotPasswordLink);
        controlsLoginPageMap.put("Registered Account",registerAccountLink);
    }

    public void loginSubStep(String user, String password) throws Exception {
        this.emailTextBox.setText(user);
        this.passwordTextBox.setText(password);
        this.loginButton.click();
    }
}
