package pages.orca.login;

import control.Button;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class RegisterAccountPage {
    public TextBox emailTextBox = new TextBox(By.id("Email"));
    public TextBox passwordTextBox = new TextBox(By.id("Password"));
    public TextBox confirmPasswordTextBox = new TextBox(By.id("ConfirmPassword"));
    public Button submitButton = new Button(By.xpath("//button[text()='Submit']"));

    public RegisterAccountPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void registerNewAccount(String email, String pwd, String confirmPwd) throws Exception {
        this.emailTextBox.setText(email);
        this.passwordTextBox.setText(pwd);
        this.confirmPasswordTextBox.setText(confirmPwd);
        this.submitButton.click();
    }

}
