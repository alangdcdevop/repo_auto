package pages.orca.loss;

import control.Button;
import control.Select;
import control.Table;
import control.TextBox;
import entities.orca.IncidentEntity;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class IncidentModal {

    public Button createANewIncidentButton = new Button(By.xpath("//div/a[@title='Add New Incident']"));
    public Button cancelButton = new Button(By.xpath("//button[contains(.,'Cancel')]"));
    public Button saveButton = new Button(By.xpath("//div[@id='dialog-content']//button[contains(.,'Save')]"));
    public Table incidentTable = new Table(By.xpath("//div[@id='dialog-content']//table"));

    public TextBox onsetDateTextBox = new TextBox(By.xpath("//input[@id='Incident_OnsetDate']"));
    public TextBox incidentTypeTextBox = new TextBox(By.xpath("//input[@name=\"incident_type\"]"));
    public Select incidentClassSelect = new Select(By.xpath("//select[@id='incident_class_id']"));
    public TextBox openDiagnosisTextBox = new TextBox(By.xpath("//input[@id=\"Incident_OpenDiagnosis\"]"));
    public TextBox denialCodeTextBox = new TextBox(By.xpath("//input[@name=\"DenialCodeText_autocomplete\"]"));

    //210 - Mastitis  175 - Screw Tail
    //D3 - Vet Advice


    public TextBox detailsTextBox = new TextBox(By.xpath("//textarea[@name=\"Incident.Details\"]"));

    public IncidentModal() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void addIncident(int rowNumber) throws Exception {
        this.incidentTable.clickOnCheckBoxCell(1, rowNumber);
        this.saveButton.click();
    }


    public void createIncident(IncidentEntity incidentEntity) throws Exception {
        detailsTextBox.click();
        detailsTextBox.setTextAndTab("");
        onsetDateTextBox.click();
        onsetDateTextBox.setTextAndTab(incidentEntity.getOnSetDate());
        incidentTypeTextBox.selectTextOption(incidentEntity.getIncidentTypeInitial(), incidentEntity.getIncidentType());

        if (!incidentEntity.getOpenDiagnosis().equals(""))
            openDiagnosisTextBox.setText(incidentEntity.getOpenDiagnosis());
        if (!incidentEntity.getDenialCode().equals(""))
            denialCodeTextBox.selectTextOption(incidentEntity.getDenialCode(), incidentEntity.getDenialCode());

        this.saveButton.click();
    }

}
