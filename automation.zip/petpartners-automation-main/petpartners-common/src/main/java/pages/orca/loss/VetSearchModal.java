package pages.orca.loss;

import control.Button;
import control.Select;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class VetSearchModal {
    public TextBox nameTextBox = new TextBox(By.id("SearchCriteria_Name"));
    public TextBox phoneTextBox = new TextBox(By.id("SearchCriteria_PhoneNo"));
    public TextBox cityTextBox = new TextBox(By.id("SearchCriteria_City"));
    public TextBox postalCodeTextBox = new TextBox(By.xpath("//input[@name=\"SearchCriteria.PostalCode\"]"));
    public Button runSearchButton = new Button(By.xpath("//button[contains(.,'Run Search')]"));
    public Select stateProvinceSelect = new Select(By.xpath("//select[@id=\"SearchCriteria_StateProvince\"]"));
    public Button createNewVetButton = new Button(By.xpath("//a[@title='Add New Vet']"));

    public VetSearchModal() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void clickOnSelectButton(int row, String initialSearch) throws Exception {
        this.nameTextBox.setText(initialSearch);
        this.runSearchButton.click();
        Button selectButton = new Button(By.xpath("(//table[@id='vets-table']//a[@title='Select Vet'])[" + row + "]"));
        selectButton.click();
        Thread.sleep(1000);
    }


}
