package pages.orca.marketChannel;

import control.*;
import entities.orca.marketChannel.MarketChannelOverviewEntity;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;


public class MarketChannelOverviewPage {
    public TextBox mcNameTextBox = new TextBox(By.xpath("//input[@formcontrolname='mcName']"));
    public TextBox mcCodeTextBox = new TextBox(By.xpath("//input[@formcontrolname='code']"));
    public TextBox mclDisplayTextBox = new TextBox(By.xpath("//input[@formcontrolname='display']"));
    public TextBox mcAdd1TextBox = new TextBox(By.xpath("//input[@formcontrolname='address1']"));
    public TextBox mcAdd2TextBox = new TextBox(By.xpath("//input[@formcontrolname='address2']"));
    public TextBox mcCityTextBox = new TextBox(By.xpath("//input[@formcontrolname='city']"));
    public Select mcStateSelect = new Select(By.xpath("//select[@formcontrolname='stateCode']"));
    public TextBox mcPostalTextBox = new TextBox(By.xpath("//input[@formcontrolname='postalCode']"));

    public TextBox mcPhoneTextBox = new TextBox(By.xpath("//input[@formcontrolname='phoneNo']"));
    public TextBox mcFaxTextBox = new TextBox(By.xpath("//input[@formcontrolname='faxNo']"));
    public TextBox mcEmailFromNameTextBox = new TextBox(By.xpath("//input[@formcontrolname='emailFromName']"));
    public TextBox mcEmailFromAddTextBox = new TextBox(By.xpath("//input[@formcontrolname='emailFromAddress']"));
    public TextBox mcClaimEmailFromAddTextBox = new TextBox(By.xpath("//input[@formcontrolname='claimEmailFromAddress']"));
    public TextBox mcWebsiteTextBox = new TextBox(By.xpath("//input[@formcontrolname='website']"));

    public Button mcSaveButton = new Button(By.xpath("//button[@id='saveButton']"));

    public TextBox mcIDTextBox = new TextBox(By.xpath("//input[@formcontrolname='marketChannelId']"));
    public TextBox mcCreatedOnTextBox = new TextBox(By.xpath("//input[@formcontrolname='createdOn']"));
    public Button mcEditButton = new Button(By.xpath("//button[@class='btn btn-info ms-auto']"));
    public Checkbox mcActiveCheckbox = new Checkbox(By.xpath("//input[@formcontrolname='active']"));

    public Link auditHistoryLink = new Link(By.xpath("//a[contains(text(),'Audit History')]"));
    public Table auditHistoryTable = new Table(By.xpath("//table[@class='table table-bordered']"));
    public Button assignNewProductPackage = new Button(By.xpath("//button[@class='w-100 btn btn-primary']"));
    public Select productPackageDropDown = new Select(By.xpath("//select[@formcontrolname=\"productPackageId\"]"));
    public Table productPackageTable = new Table(By.xpath("//table[@class='table table-bordered']"));
    public Button editButton1 = new Button(By.xpath("//div[@class='d-flex']//button[@type='button']//*[name()='svg']"));
    public Button editButton2 = new Button(By.xpath("[@class='d-flex mt-2']//button[@type='button']//*[name()='svg']//*[name()='path' and contains(@d,'M12.854.14')]"));


    public TextBox groupPhoneNumberTextBox =  new TextBox(By.xpath("//input[@formcontrolname=\"groupPhoneNo\"]"));
    public TextBox groupEmailFromAddressTextBox =  new TextBox(By.xpath("//input[@formcontrolname=\"groupEmailFromAddress\"]"));
    public TextBox groupClaimEmailFromAddressTextBox =  new TextBox(By.xpath("//input[@formcontrolname=\"groupClaimEmailAddress\"]"));
    public TextBox groupWebsiteTextBox =  new TextBox(By.xpath("//input[@formcontrolname=\"groupWebsite\"]"));

    public Map<String, Link> marketChannelProductsLink = new HashMap<>();


    public void fillMarketChannelOverviewDetails(MarketChannelOverviewEntity mktChnlOverviewEntity) throws Exception {
        Logger.log(Level.INFO, this.getClass().getName() + "> Fill Market Channel Overview: " + this.getClass().getSimpleName());
        this.mcNameTextBox.setText(mktChnlOverviewEntity.mcName);
        this.mcCodeTextBox.setText(mktChnlOverviewEntity.mcCode);
        this.mclDisplayTextBox.setText(mktChnlOverviewEntity.mcDisplay);
        this.mcAdd1TextBox.setText(mktChnlOverviewEntity.mcAdd1);
        this.mcAdd2TextBox.setText(mktChnlOverviewEntity.mcAdd2);
        this.mcCityTextBox.setText(mktChnlOverviewEntity.mcCity);
        this.mcStateSelect.selectValueContainsOption(mktChnlOverviewEntity.mcState);
        this.mcPostalTextBox.setText(mktChnlOverviewEntity.mcPostal);
        this.mcPhoneTextBox.setText(mktChnlOverviewEntity.mcPhone);
        this.mcFaxTextBox.setText(mktChnlOverviewEntity.mcFax);
        this.mcEmailFromNameTextBox.setText(mktChnlOverviewEntity.mcEmailFromName);
        this.mcEmailFromAddTextBox.setText(mktChnlOverviewEntity.mcEmailFromAdd);
        this.mcClaimEmailFromAddTextBox.setText(mktChnlOverviewEntity.mcClaimEmailFromAdd);
        this.mcWebsiteTextBox.setText(mktChnlOverviewEntity.mcWebsite);

        this.groupPhoneNumberTextBox.setText(mktChnlOverviewEntity.getGroupPhoneNumber());
        this.groupEmailFromAddressTextBox.setText(mktChnlOverviewEntity.getGroupEmailFromAddress());
        this.groupClaimEmailFromAddressTextBox.setText(mktChnlOverviewEntity.getGroupClaimEmailFromAddress());
        this.groupWebsiteTextBox.setText(mktChnlOverviewEntity.getGroupWebsite());

    }

    public MarketChannelOverviewPage() {

        marketChannelProductsLink.put("State Filings", new Link(By.xpath("//a[text()='State Filings']")));
        marketChannelProductsLink.put("Product Package", new Link(By.xpath("//a[text()='Product Packages']")));
        marketChannelProductsLink.put("Audit History", new Link(By.xpath("//a[text()='Audit History']")));
        marketChannelProductsLink.put("API Key Management", new Link(By.xpath("//a[text()='API Key Management']")));


    }
}
