package pages.orca.marketChannel;

import control.TextBox;
import org.openqa.selenium.By;

public class MarketChannelProductPackagePage {
    public TextBox productTextBox = new TextBox(By.xpath("//label[text()=' Product ']/../input"));
    public TextBox marketingNameTextBox = new TextBox(By.xpath("//input[@formcontrolname=\"marketingName\"]"));
}
