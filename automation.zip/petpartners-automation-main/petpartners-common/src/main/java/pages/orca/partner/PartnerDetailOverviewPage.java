package pages.orca.partner;

import control.*;
import entities.orca.partner.PartnerDetailOverviewEntity;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class PartnerDetailOverviewPage {
    public TextBox partnerNameTextBox = new TextBox(By.xpath("//input[@id = 'Partner_Display' and @type ='text']"));
    public TextBox partnerCodeTextBox = new TextBox(By.xpath("//input[@id = 'Partner_Code' and @type ='text']"));
    public Select defaultAffinityGroupSelect = new Select(By.xpath("//select[@id='Partner_AffinityGroupId']"));
    public Select partnerTypeSelect = new Select(By.xpath("//select[@id='Partner_PartnerTypeId']"));
    public TextBox npnTextBox = new TextBox(By.xpath("//input[@id = 'Partner_NPN' and @type ='text']"));
    public Button partnerDetailSaveButton = new Button(By.xpath("//button[@class='disable-after-click btn btn-success']"));
    public TextBox affiliateTextBox=new TextBox(By.xpath("//input[@data-element-to-update=\"AffiliateId\"]"));
    public Checkbox activeCheckBox = new Checkbox(By.id("Partner_Active"));

    public void fillPartnerDetailOverviewDetails(PartnerDetailOverviewEntity partDtlsOverviewEntity) throws Exception {
        Logger.log(Level.INFO, this.getClass().getName() + "> Fill Partner Detail Overview: " + this.getClass().getSimpleName());
        this.partnerNameTextBox.setText(partDtlsOverviewEntity.partnerName);
        this.activeCheckBox.check();
        this.partnerCodeTextBox.setText(partDtlsOverviewEntity.partnerCode);
        this.defaultAffinityGroupSelect.selectValue(partDtlsOverviewEntity.defaultAffinityGroup);
        this.partnerTypeSelect.selectValue(partDtlsOverviewEntity.partnerType);
        this.npnTextBox.setText(partDtlsOverviewEntity.npn);
    }
}
