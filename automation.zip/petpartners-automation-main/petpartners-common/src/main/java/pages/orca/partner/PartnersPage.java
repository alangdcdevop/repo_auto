package pages.orca.partner;

import control.Button;
import control.Link;
import control.Table;
import control.TextBox;
import org.openqa.selenium.By;

public class PartnersPage {
    public Link addPartnerLink = new Link(By.xpath("//a[contains(text(),'Add Partner')]"));
    public TextBox partnerNameTextBox = new TextBox(By.xpath("//input[@id = 'SearchCriteria_Display' and @type ='text']"));
    public Button partnersRunSearchButton = new Button(By.id("btn-run-search"));
    public Table partnerResultTable = new Table(By.xpath("//table[@id='groups-table']"));
}
