package pages.orca.pet;

import control.Label;
import control.Select;
import control.Table;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class PetDetailPage {

    public Label petDetailLabel = new Label(By.xpath("//h2[text()='Pet Detail']"));
    public Map<String, TextBox> petDetailTextBox = new HashMap<>();
    public Map<String, Select> petDetailSelect = new HashMap<>();
    public Map<String, Label> petDetailTabOption = new HashMap<>();

    // Claims tab option
    public Table claimsTable = new Table(By.xpath("//div[@id='claims']/table"));

    public PetDetailPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        petDetailTextBox.put("Pet Name", new TextBox(By.xpath("//input[@id='Pet_PetName']")));
        petDetailTextBox.put("Call Name", new TextBox(By.id("Pet_CallName")));
        petDetailTextBox.put("DOB", new TextBox(By.id("Pet_Dob")));
        petDetailTextBox.put("Registration No", new TextBox(By.id("Pet_RegistrationNumber")));

        petDetailSelect.put("Gender", new Select(By.id("Pet_GenderId")));
        petDetailSelect.put("Species", new Select(By.id("Pet_SpeciesId")));
        petDetailSelect.put("Breed", new Select(By.id("breed-select")));

        petDetailTabOption.put("Incident(s)", new Label(By.id("incidents-link")));
        petDetailTabOption.put("Attachment(s)", new Label(By.xpath("//a[@title='Attachments(s)']")));
        petDetailTabOption.put("Claim(s)", new Label(By.xpath("//a[@title='Claim(s)']")));
        petDetailTabOption.put("Benefit Schedule", new Label(By.xpath("//a[@title='Benefit Schedule']")));
    }
}
