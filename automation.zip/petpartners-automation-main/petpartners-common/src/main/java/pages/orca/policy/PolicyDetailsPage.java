package pages.orca.policy;

import control.*;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class PolicyDetailsPage {

    public Map<String, Label> labelMap = new HashMap<>();
    public Label policyNumberLabel = new Label(By.xpath("//input[@id='policy_id']/parent::*"));
    public Label marketChannelLabel = new Label(By.xpath("//input[@id='market-channel']/parent::*"));
    public Label createdOnLabel = new Label(By.xpath("//strong[text()='Created On']/../../div[@class='controls']"));
    public Select statusSelect = new Select(By.xpath("//select[@id='PolicyDetails_Policy_PolicyStatusId']"));
    public Label policyStatusLabel = new Label(By.xpath("//input[@id='PolicyDetails_Policy_PolicyStatusId']/parent::*"));
    public Select deliveryTypeSelect = new Select(By.id("delivery_type_id"));
    public Select paymentFrequencySelect = new Select(By.id("payment_frequency_id"));
    public Select holdPaymentSelect = new Select(By.xpath("//select[@id='PolicyDetails_Policy_HoldPayment']"));
    public TextBox linkedPolicyTextBox = new TextBox(By.id("PolicyDetails_Policy_LinkedPolicy"));
    public Label soldByLabel = new Label(By.xpath("//strong[text()='Sold by:']/../../div[@class='controls']"));
    public Label partnerLabel = new Label(By.xpath("//strong[text()='Partner']/../../div[@class='controls']"));
    public Label customerSourceDetailLabel = new Label(By.xpath("//strong[text()='Customer Source & Details']/../../div[@class='controls']"));
    public Label linkedTrialPolicyLabel = new Label(By.xpath("//strong[text()='Linked Trial Policy(ies)']/../../div[@class='controls']"));
    public Label deliveryTypeLabel = new Label(By.xpath("//strong[text()='Delivery Type:']/../../div[last()]"));
    public Link linkedGroupCertificateLink = new Link(By.xpath("//strong[contains(.,'Linked Group Certificate')]/../..//a"));
    public Map<String, Label> tabOptionLabelsMap = new HashMap<>();
    public Link pastCoverageLink = new Link(By.xpath("(//a[text()='Past'])[1]"));

    public Map<String, Button> buttonsMap = new HashMap<>();
    public Button saveButton = new Button(By.xpath("//button[contains(.,'Save')]"));
    public Button discardChangesButton = new Button(By.xpath("//a[contains(.,'Discard Changes')]"));
    public Button submitforApprovalButton = new Button(By.xpath("//a[contains(.,'Submit for Approval')]"));

    public Button approveChangeslButton = new Button(By.xpath("//a[contains(.,'Approve Changes')]"));

    // Coverage -> Coverage --> Active
    public Link changesUpcomingLabel= new Link(By.xpath("//a[contains(text(),'Upcoming')]/../../..//div[contains(text(),'Changes')]"));
    public Link coveragePeriodLink = new Link(By.xpath("//div[contains(@id,'active-coverages') or contains(@id,'upcoming-coverages') ]//h3[contains(text(),'Coverage Period ')]"));
    public Button plusPetDetailButton = new Button(By.xpath("(//a[text()='Active' or text()='Upcoming']/parent::*/parent::*/parent::div//div[contains(@class,'plus toggle')])[1]"));

    public Button makeChangesButton = new Button(By.xpath("//div/a[contains(text(),'Make Changes')]"));
    public Label makeChangesOption = new Label(By.xpath("//li/a[contains(text(),'Make Changes')]"));
    public Label transferSaleOption = new Label(By.xpath("//li/a[contains(text(),'Transfer Sale')]"));

    public Button policyActionButton = new Button(By.xpath("//a[contains(.,'Policy Actions')]"));

    public Button policyCancelButton = new Button(By.xpath("//a[@title='Cancel Entire Policy']"));
    public Link activeLink = new Link(By.xpath("//a[text()='Active']"));
    public Link upcomingLink = new Link(By.xpath("//a[text()='Upcoming']"));
    public Link expiredLink = new Link(By.xpath("//a[text()='Expired']"));
    public Link premiumTrackerLink = new Link(By.xpath("//a[contains(text(),'Premium Tracker')]"));
    public Table activePetDetailTable = new Table(By.xpath("//*[contains(@id,'coverage-')]//table[@class=\"table table-striped table-bordered\"]"));
    public Table activeSecondPetDetailTable = new Table(By.xpath("//tr[@class=\"warning\"]/parent::*//table[@class=\"table table-striped table-bordered\"]"));
    public Table premiumTrackerTable = new Table(By.xpath("//table[@id=\"search-results\"]"));

    public Label activatedByLabel = new Label(By.xpath("//div[@class='accordion-body in collapse']//div[contains(@class,'row-fluid')][contains(text(),'Activated By')]"));
    public Label resultLabel = new Label(By.xpath("//div[@class='accordion-body in collapse']//div[contains(@class,'row-fluid')][contains(text(),'Sold By')]"));

    //Customer(s)
    public Table customersTable = new Table(By.xpath("//div[@id='customers']/div/table[@id='customers-table']"));
    public Link viewCustomerIconInActionsLink = new Link(By.xpath("//a[@title='View Customer']"));

    //Attachment(s)
    public Map<String, Label> attachmentTabLinksMap = new HashMap<>();
    public Map<String, Label> attachmentTabDocTypeLabelsMap = new HashMap<>();
    public Map<String,Label> resultLabels = new HashMap<>();
    //Transaction(s)
    public Table transactionTypeTable = new Table(By.xpath("//div[@id='trans-table']/table[@id='transactions-table']"));
    public Link certificateInvoiceLink =  new Link(By.xpath("//a[contains(text(),'Certificate Invoice')]"));

    // Pets tab
    public Table petsTable = new Table(By.xpath("//div[@id='pets-table']/div/table[@id='search-results']"));

    // Claims tab
    public Button addNewClaimButton = new Button(By.xpath("//a[@title=\"Add Claim\"]"));
    public Button moveClaimButton = new Button(By.xpath("//a[@id=\"btn-move-claims\"]"));

    // Note(s)
    public Button addNoteButton = new Button(By.xpath("//button[contains(.,'Add Note')]"));
    public Button editPaymentButton = new Button(By.xpath("//a[@id='btn-view-pmt-options']"));

    public PolicyDetailsPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        labelMap.put("Policy No", new Label(By.xpath("//strong[text()='Policy No']")));
        labelMap.put("Market Channel", new Label(By.xpath("//strong[text()='Market Channel']")));
        labelMap.put("Created On", new Label(By.xpath("//strong[text()='Created On']")));
        labelMap.put("Status", new Label(By.xpath("//strong[text()='Status']")));
        labelMap.put("Delivery Type", new Label(By.xpath("//strong[text()='Delivery Type']")));
        labelMap.put("Payment Frequency", new Label(By.xpath("//strong[text()='Payment Frequency']")));
        labelMap.put("Hold Payment", new Label(By.xpath("//strong[text()='Hold Payment']")));
        labelMap.put("Linked Policy", new Label(By.xpath("//strong[text()='Linked Policy']")));
        labelMap.put("Sold By:", new Label(By.xpath("//strong[text()='Sold By:']")));
        labelMap.put("Partner", new Label(By.xpath("//strong[text()='Partner']")));
        labelMap.put("Customer Source & Details", new Label(By.xpath("//strong[text()='Customer Source & Details']")));
        labelMap.put("Linked Trial Policy(ies)", new Label(By.xpath("//strong[text()='Linked Trial Policy(ies)']")));
        labelMap.put("Delivery Type:", new Label(By.xpath("//strong[text()='Delivery Type:']")));
        labelMap.put("Pet Cloud Status", new Label(By.xpath("//strong[text()='Pet Cloud Status']")));


        tabOptionLabelsMap.put("Coverage(s)", new Label(By.xpath("//a[@title='Coverage(s)']")));
        tabOptionLabelsMap.put("Customer(s)", new Label(By.xpath("//a[@title='Customer(s)']")));
        tabOptionLabelsMap.put("Attachment(s)", new Label(By.xpath("//a[@title='Attachment(s)']")));
        tabOptionLabelsMap.put("Pet(s)", new Label(By.xpath("//a[@title='Pet(s)']")));
        tabOptionLabelsMap.put("Claim(s)", new Label(By.xpath("//a[@title='Claim(s)']")));
        tabOptionLabelsMap.put("Note(s)", new Label(By.xpath("//a[@title='Notes(s)']")));
        tabOptionLabelsMap.put("Transaction(s)", new Label(By.xpath("//a[@title='Transaction(s)']")));
        tabOptionLabelsMap.put("Follow-up(s)",new Label(By.xpath("//a[text()='Follow-up(s)']")));
        // todo put all tab options

        attachmentTabLinksMap.put("Term 1", new Label(By.xpath("//a[@class ='accordion-toggle ajax-get' and contains(text(),'Term')]")));
        attachmentTabLinksMap.put("Declarations", new Label(By.xpath("//a[contains(text(), 'Declarations')]")));
        attachmentTabLinksMap.put("Terms and Conditions", new Label(By.xpath("//a[contains(text(), 'Terms and Conditions')]")));
        attachmentTabLinksMap.put("Other", new Label(By.xpath("//a[contains(text(),'Other')]")));
        attachmentTabLinksMap.put("Documents and Letters", new Label(By.xpath("//a[contains(text(), 'Documents and Letters')]")));

        attachmentTabDocTypeLabelsMap.put("Declarations", new Label(By.xpath("//div[@class='span2 edit' and contains(text(),'Declarations')]")));
        attachmentTabDocTypeLabelsMap.put("Terms and Conditions", new Label(By.xpath("//div[@class='span2 edit' and contains(text(),'Terms and Conditions')]")));
        attachmentTabDocTypeLabelsMap.put("Endorsements", new Label(By.xpath("//div[@class='span2 edit' and contains(text(),'Endorsements')]")));
        attachmentTabDocTypeLabelsMap.put("Welcome Cover Page", new Label(By.xpath("//div[@class='span3 edit' and contains(text(),'Welcome Cover Page')]")));
        attachmentTabDocTypeLabelsMap.put("Welcome Letter", new Label(By.xpath("//div[@class='span3 edit' and contains(text(),'Welcome Letter')]")));

        buttonsMap.put("Save", saveButton);
        buttonsMap.put("Discard Changes", discardChangesButton);
        buttonsMap.put("Submit for Approval", submitforApprovalButton);
        buttonsMap.put("Approve Changes", approveChangeslButton);

        resultLabels.put("Activated By",new Label(By.xpath("//div[@class='accordion-body in collapse']//div[contains(@class,'row-fluid')][contains(text(),'Activated By')]")));
        resultLabels.put("Sold By",new Label(By.xpath("//div[@class='accordion-body in collapse']//div[contains(@class,'row-fluid')][contains(text(),'Sold By')]")));

    }

    public boolean emailCustomer(String email) {
        Label emailTmp = new Label(By.xpath("//a[contains(text(),'" + email + "')]"));
        return emailTmp.controlIsDisplayed();

    }

    /*
     * Policy Actions Button - DropDown format
     * options:
     *       Do Not Renew
     *       Change Effective Date
     *       Backdate Full Term Policy
     *       Cancel Entire Policy
     *       Create Followup
     *       Generate Welcome Documents
     *       Generate Policy Term Documents
     * */
    public void selectOptionPolicyActions(String option) throws Exception {
        policyActionButton.click();
        Label optionLabel = new Label(By.xpath("//a[contains(.,'" + option + "')]"));
        optionLabel.click();
    }

    public boolean isNoteDisplayed(String note) {
        Label noteLabel = new Label(By.xpath("//blockquote[contains(.,'" + note + "')]"));
        return noteLabel.controlIsDisplayed();
    }

    /*
     * site: Active or Upcoming
     * */
    public String getTheCpId(String site) throws Exception {
        Label cpId = new Label(By.xpath("//a[text()='" + site + "']/../../..//span[contains(.,'CP ID')]"));
        return cpId.getText().replace("CP ID:", "")
                .replace(" ", "")
                .replace("MakeChanges", "")
                .replace("\n", "");
    }

    public String getCancelDetailMessageInTable(String petName) throws Exception {
        Label label = new Label(By.xpath("//tr[@class='warning']//div[contains(.,'" + petName + "')]/parent::*/parent::*/td[last()]"));
        return label.getText();
    }

    public String getValueFromControl(String nameControl) throws Exception {
        if (nameControl.contains("Policy No")
                || nameControl.contains("Market Channel")
                || nameControl.contains("Created On")
                || nameControl.contains("Pet Cloud Status")
                || nameControl.contains("Linked Trial Policy(ies)")
                || nameControl.contains("Partner")
                || nameControl.contains("Sold By:")) {
            Label labelControl = new Label(By.xpath("//strong[contains(text(),'"+nameControl+"')]/../../div[@class='controls']"));
            return labelControl.getText();
        } else if (nameControl.contains("Status")
                || nameControl.contains("Delivery Type")
                || nameControl.contains("Payment Frequency")
                || nameControl.contains("Hold Payment")) {
            Select selectControl = new Select(By.xpath("//strong[contains(text(),'"+nameControl+"')]/../../div[@class='controls']/select"));
            return selectControl.getTextOptionSelected();

        } else {
            throw new Exception("ERROR the control [" + nameControl + "] does  not exist");
        }
    }
}