package pages.orca.policy;

import control.*;
import entities.orca.makeChanges.MakeChangesPetDetailsEntity;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class PolicyMakeChangesPage {
    public Button makeChangeButton = new Button(By.xpath("//a[text()=' Make Changes']"));
    public Button makechangeOption = new Button(By.id("btn-make-changes"));
    public Button addPetButton = new Button(By.xpath("//a[text()=' Add Pet ']"));

    public Button existingPetButton = new Button(By.xpath("//a[normalize-space()='Existing Pet']"));

    public Button newPetButton = new Button(By.xpath("//a[text()='New Pet']"));

    public TextBox policynumberTextBox = new TextBox(By.xpath("//input[@id='SearchString']"));

    public Button transferSaleButton = new Button(By.xpath("//a[text()='Transfer Sale']"));

    public Button selectButton = new Button(By.xpath("//a[text()=' Select']"));

    public Button makeChangeButton2 = new Button(By.xpath("(//a[@id='btn-edit-coverage'])[2]"));

    public Button upcomingButton = new Button(By.xpath("//a[text()='Upcoming']"));

    public Button activeButton = new Button(By.xpath("//a[contains(text(),'Active')]"));

    public RadioButton companionCareRadiobutton = new RadioButton(By.id("CoverageProducts_0__IsSelected"));

    public RadioButton accidentCareRadiobutton = new RadioButton(By.id("CoverageProducts_8__IsSelected"));

    public Button policyActionsButton = new Button(By.xpath("//a[text()='Policy Actions ']"));

    public Button cancelEntirePolicyButton = new Button(By.xpath("//a[@title='Cancel Entire Policy']"));

    public Button changeEffectiveDateButton = new Button(By.xpath("//a[text()='Change Effective Date']"));

    public TextBox newEffectiveDateButton = new TextBox(By.id("NewEffectiveDate"));

    public TextBox notesTextbox = new TextBox(By.id("Notes"));

    public Button saveButton = new Button(By.xpath("//div[@class=\"modal-footer btn-block\"]/button[@class='btn btn-success']"));

    public Checkbox supportPlusCheckbox = new Checkbox(By.id("CoverageProducts_9__IsSelected"));

    public Checkbox alternativePlusCheckbox = new Checkbox(By.id("CoverageProducts_10__IsSelected"));

    public Checkbox examPlusCheckbox = new Checkbox(By.id("CoverageProducts_11__IsSelected"));

    public Checkbox defenderCheckbox = new Checkbox(By.id("CoverageProducts_12__IsSelected"));

    public Checkbox defenderPlusCheckbox = new Checkbox(By.id("CoverageProducts_13__IsSelected"));

    public Button saveButtonMakeChangesPage = new Button(By.xpath("//*[@id='dialog']//button[contains(.,'Save')]"));

    public Label premium = new Label(By.xpath("//tr[contains(@id,'coverage')]/td[contains(text(),'/ mo')]"));

    //Make Changes Popup - Pet Details
    public TextBox makeChangesPetNameTextBox = new TextBox(By.xpath("//input[@name='Pet.Pet.PetName']"));
    public TextBox makeChangesDOBTextBox = new TextBox(By.xpath("//input[@id='Pet_Pet_Dob']"));
    public Select makeChangesGenderSelect = new Select(By.xpath("//select[@id='gender-select']"));
    public Select makeChangesSpeciesSelect = new Select(By.xpath("//select[@id='species-select']"));
    public Select makeChangesBreedSelect = new Select(By.xpath("//select[@id='breed-select']"));

    public Table coverageDetailsTable = new Table(By.xpath("//table[@id=\"products\"]"));
    public Map<String, Cell> coverageDetailsTableCell = new HashMap<>();

    //Make Changes Popup - Coverage Details
    //CompanionCare
    public Checkbox companionCareHereditaryPlusCheckbox = new Checkbox(By.xpath("//input[@id='CoverageProducts_1__IsSelected']"));
    public Checkbox companionCareSupportPlusCheckbox = new Checkbox(By.xpath("//input[@id='CoverageProducts_2__IsSelected']"));
    public Checkbox companionCareAlternativePlusCheckbox = new Checkbox(By.xpath("//input[@id='CoverageProducts_3__IsSelected']"));
    public Checkbox companionCareBreedingCoverageCheckbox = new Checkbox(By.xpath("//input[@id='CoverageProducts_4__IsSelected']"));
    public Checkbox companionCareExamPlusCheckbox = new Checkbox(By.xpath("//input[@id='CoverageProducts_5__IsSelected']"));
    public Checkbox companionCareDefenderPlusPlusCheckbox = new Checkbox(By.xpath("//input[@id='CoverageProducts_6__IsSelected']"));
    public Checkbox companionCareDefenderCheckbox = new Checkbox(By.xpath("//input[@id='CoverageProducts_7__IsSelected']"));


    //AccidentCare
    public Checkbox accidentCareCheckbox = new Checkbox(By.xpath("//input[@id='CoverageProducts_8__IsSelected']"));

    public Checkbox accidentCareSupportPlusCheckbox = new Checkbox(By.xpath("//input[@id='CoverageProducts_9__IsSelected']"));
    public Checkbox accidentCareAlternativePlusCheckbox = new Checkbox(By.xpath("//input[@id='CoverageProducts_10__IsSelected']"));
    public Checkbox accidentCareExamPlusCheckbox = new Checkbox(By.xpath("//input[@id='CoverageProducts_11__IsSelected']"));
    public Checkbox accidentCareDefenderCheckbox = new Checkbox(By.xpath("//input[@id='CoverageProducts_12__IsSelected']"));
    public Checkbox accidentCareDefenderPlusCheckbox = new Checkbox(By.xpath("//input[@id='CoverageProducts_13__IsSelected']"));

    public Button refreshPremiumsButton = new Button(By.id("btn-refresh-premiums"));
    public Map<String,Checkbox> companionCareCheckBoxesMap= new HashMap<>();
    public Map<String,Checkbox> accidentCareCheckBoxesMap= new HashMap<>();
    public PolicyMakeChangesPage() {
        coverageDetailsTableCell.put("Product Name", new Cell(1, "input", "Product Name"));
        coverageDetailsTableCell.put("Incident Limit", new Cell(2, "select", "Incident Limit"));
        coverageDetailsTableCell.put("Deductible", new Cell(3, "select", "Deductible"));
        coverageDetailsTableCell.put("Deductible Frequency", new Cell(4, "select", "Deductible Frequency"));
        coverageDetailsTableCell.put("Coinsurance", new Cell(5, "select", "Coinsurance"));
        coverageDetailsTableCell.put("Coverage Limit", new Cell(6, "select", "Coverage Limit"));

        companionCareCheckBoxesMap.put("HereditaryPlus",companionCareHereditaryPlusCheckbox);
        companionCareCheckBoxesMap.put("SupportPlus",companionCareSupportPlusCheckbox);
        companionCareCheckBoxesMap.put("AlternativePlus",companionCareAlternativePlusCheckbox);
        companionCareCheckBoxesMap.put("BreedingCoverage",companionCareBreedingCoverageCheckbox);
        companionCareCheckBoxesMap.put("ExamPlus",companionCareExamPlusCheckbox);
        companionCareCheckBoxesMap.put("Defender",companionCareDefenderCheckbox);
        companionCareCheckBoxesMap.put("DefenderPlus",companionCareDefenderPlusPlusCheckbox);

        accidentCareCheckBoxesMap.put("AccidentCare",accidentCareCheckbox);
        accidentCareCheckBoxesMap.put("AlternativePlus",accidentCareAlternativePlusCheckbox);
        accidentCareCheckBoxesMap.put("SupportPlus",accidentCareSupportPlusCheckbox);
        accidentCareCheckBoxesMap.put("ExamPlus",accidentCareExamPlusCheckbox);
        accidentCareCheckBoxesMap.put("Defender",accidentCareDefenderCheckbox);
        accidentCareCheckBoxesMap.put("DefenderPlus",accidentCareDefenderPlusCheckbox);
    }

    public void fillPetDetailsInMakeChangesScreen(MakeChangesPetDetailsEntity makeChangesPetEntity) throws Exception {
        this.makeChangesPetNameTextBox.clearSetText(makeChangesPetEntity.makeChangesPetName);
       // this.makeChangesDOBTextBox.clear();
        this.makeChangesPetNameTextBox.click();
        this.makeChangesDOBTextBox.click();
        this.makeChangesDOBTextBox.setText(makeChangesPetEntity.makeChangesPetDOB);
        this.makeChangesGenderSelect.selectValue(makeChangesPetEntity.makeChangesPetGender);
        this.makeChangesSpeciesSelect.selectValue(makeChangesPetEntity.makeChangesPetSpecies);
        this.makeChangesBreedSelect.selectValue(makeChangesPetEntity.makeChangesPetBreed);
    }
}

