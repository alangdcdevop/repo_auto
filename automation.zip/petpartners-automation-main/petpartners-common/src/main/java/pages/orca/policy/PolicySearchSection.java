package pages.orca.policy;

import control.*;
import org.openqa.selenium.By;

import java.util.HashMap;
import java.util.Map;

public class PolicySearchSection {

    /**
     * Policy Dashboard locators
     * Yusan
     */

    public TextBox policyNumberTextBox = new TextBox(By.id("SearchCriteria_PolicyNo"));
    public Select marketchannelSelect = new Select(By.id("selected-market-channel"));


    public Button runSearchButton = new Button(By.id("btn-run-search"));

    public Table searchResultTable = new Table(By.xpath("//table[@id='search-results']"));

    public TextBox postalCodeTextBox = new TextBox(By.id("SearchCriteria_PostalCode"));

    public Button clearButton = new Button(By.xpath("//a[@class='clear-form pull-left btn btn-default']"));

    public TextBox lastNameTextBox = new TextBox(By.id("SearchCriteria_CustomerName"));

    public TextBox emailAddressTextBox = new TextBox(By.id("SearchCriteria_EmailAddress"));

    public TextBox phoneNumberTextBox = new TextBox(By.id("SearchCriteria_PhoneNo"));

    public TextBox billingIdTextBox = new TextBox(By.id("SearchCriteria_BillingId"));

    public TextBox registrationNumberTextBox = new TextBox(By.id("SearchCriteria_RegNo"));

    public TextBox linkedPolicyTextBox = new TextBox(By.id("SearchCriteria_LinkedPolicy"));

    public TextBox setLinkedPolicyTextbox = new TextBox(By.id("PolicyDetails_Policy_LinkedPolicy"));

    public Map<String, TextBox> textBoxMap = new HashMap<>();


    public PolicySearchSection() {

        textBoxMap.put("Policy No", policyNumberTextBox);
        textBoxMap.put("Postal Code", postalCodeTextBox);
        textBoxMap.put("Last Name", lastNameTextBox);
        textBoxMap.put("Email address", emailAddressTextBox);
        textBoxMap.put("Phone No", phoneNumberTextBox);
        textBoxMap.put("Billing Id", billingIdTextBox);
        textBoxMap.put("Registration No", registrationNumberTextBox);
        textBoxMap.put("Linked Policy", linkedPolicyTextBox);
        textBoxMap.put("Set LinkedPolicy", setLinkedPolicyTextbox);

    }

}

