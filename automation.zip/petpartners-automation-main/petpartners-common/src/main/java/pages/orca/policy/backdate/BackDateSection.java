package pages.orca.policy.backdate;

import control.Button;
import control.Select;
import control.TextBox;
import org.openqa.selenium.By;

public class BackDateSection {
    public TextBox newEffectiveDateTextBox= new TextBox(By.id("newDate"));
    public Select coveragePeriodSelect = new Select(By.xpath("//select[@id='mySelect']"));
    public TextBox notesTextBox = new TextBox(By.id("Notes"));
    public Button saveButton = new Button(By.xpath("//div[@id='dialog-content']//button[contains(.,'Save')]"));
    public Button returnToPolicyButton = new Button(By.xpath("//a[contains(.,'Return to Policy')]"));
}
