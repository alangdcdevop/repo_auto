package pages.orca.quote.dialog;

import control.Button;
import control.Select;
import control.TextBox;
import org.openqa.selenium.By;

public class CancelCoverageDialog {
    public TextBox requestOnTextBox = new TextBox(By.xpath("//input[@id='CancelRequestedOn' and @type='text']"));
    public TextBox effectiveOnTextBox = new TextBox(By.xpath("//input[@id='CancelEffectiveDate' and @type='text']"));
    public Select cancelReasonSelect = new Select(By.xpath("//select[@id=\"CancelReasonId\"]"));
    public Select cancelTypeSelect = new Select(By.xpath("//select[@id=\"CancelTypeId\"]"));
    public TextBox notesTextBox = new TextBox(By.id("Notes"));
    public Button saveButton = new Button(By.xpath("//div[@id=\"dialog\"]//button[contains(text(),'Save')]"));
    public Button cancelButton = new Button(By.xpath("//div[@id=\"dialog\"]//button[contains(text(),'Cancel')]"));
    public Button closeButton = new Button(By.xpath("//div[@id=\"dialog\"]//button[@class=\"close\"]"));
}
