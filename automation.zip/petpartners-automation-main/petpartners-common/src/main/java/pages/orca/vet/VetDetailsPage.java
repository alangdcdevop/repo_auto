package pages.orca.vet;

import control.*;
import org.openqa.selenium.By;
import java.util.Map;
import java.util.HashMap;

public class VetDetailsPage {

    public TextBox vetNameTextBox = new TextBox(By.id("Vet_name"));
    public TextBox address1TextBox = new TextBox(By.id("Vet_address1"));
    public TextBox address2TextBox = new TextBox(By.id("Vet_address2"));
    public TextBox phoneTextBox = new TextBox(By.id("Vet_phone_day"));
    public TextBox cityTextBox = new TextBox(By.id("Vet_city"));
    public Select stateProvinceDropDown = new Select(By.id("Vet_state_prov_id"));
    public TextBox postalCodeTextBox = new TextBox(By.id("Vet_postal_code"));
    public TextBox faxTextBox = new TextBox(By.id("Vet_fax"));
    public TextBox emailTextBox = new TextBox(By.id("Vet_email"));
    public Select prefDeliveryMethodDropDown = new Select(By.id("delivery-method"));
    public TextBox notesTextBox = new TextBox(By.id("Vet_notes"));
    public Button cancelButton = new Button(By.xpath("//a[contains(text(),'Cancel')]"));
    public Button saveButton = new Button(By.xpath("//button[contains(text(),'Save')]"));
    public Label overviewSection = new Label(By.xpath("//*[text()='Overview']"));
    public Label successMessage = new Label(By.xpath("//div[@class='alert alert-success']"));

    public Map<String,TextBox> textBoxMap = new HashMap<>();
    public Map<String, Button> buttonMap = new HashMap<>();

    public  VetDetailsPage(){
        textBoxMap.put("Vet Name",vetNameTextBox);
        textBoxMap.put("Address 1",address1TextBox);
        textBoxMap.put("Address 2",address2TextBox);
        textBoxMap.put("City",cityTextBox);
        textBoxMap.put("Postal Code",postalCodeTextBox);
        textBoxMap.put("Phone",phoneTextBox);
        textBoxMap.put("Fax",faxTextBox);
        textBoxMap.put("Email",emailTextBox);
        textBoxMap.put("Notes",notesTextBox);
        buttonMap.put("Save",saveButton);
        buttonMap.put("Cancel", cancelButton);
    }
}
