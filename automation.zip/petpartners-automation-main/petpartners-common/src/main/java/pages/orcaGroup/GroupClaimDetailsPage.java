package pages.orcaGroup;

import control.Button;
import control.Label;
import control.Link;
import control.Select;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;
import java.util.HashMap;
import java.util.Map;

public class GroupClaimDetailsPage {
    public Map<String, Select> controlSelect = new HashMap<>();
    public Map<String, Link> controlLinks = new HashMap<>();
    public Button groupAddLossesButton = new Button(By.xpath("//a[@title='Add Loss(es)']"));
    public Button returnToClaimButton = new Button(By.xpath("//a[@title='Return to Claim']"));
    public Button finalizeAllLossesButton = new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Finalize All Loss(es)')]"));
    public Link viewClaimDetailsLink = new Link(By.xpath("//a[@title='Add Line Items']"));
    public Label claimDetailsLabel = new Label(By.id("claim-details"));
    public Map<String, Button> controlButtonClaimsDetail = new HashMap<>();

    public GroupClaimDetailsPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        controlSelect.put("Adjuster", new Select(By.xpath("//select[@id='assigned-to']")));
        controlSelect.put("Auditor", new Select(By.xpath("//select[@id='auditor-sysuser-id']")));
        controlSelect.put("Priority", new Select(By.id("claim-priority")));
        controlSelect.put("Assistant", new Select(By.xpath("//select[@id='assistant-sysuser-id']")));
        controlSelect.put("Page Size Table", new Select(By.xpath("//select[@class='pagesize']")));

        controlLinks.put("Processing", new Link(By.id("processing-link")));
        controlLinks.put("Attachment(s)", new Link(By.xpath("//a[@data-placeholder-id='claim-attachments']")));
        controlLinks.put("Finance", new Link(By.id("checks-link")));
        controlLinks.put("Note(s)", new Link(By.id("notes-link")));
        controlLinks.put("History", new Link(By.id("history-link")));
        controlLinks.put("Audit Return History", new Link(By.id("audit-return-history-link")));
        controlLinks.put("Request(s)", new Link(By.id("requests-link")));
        controlLinks.put("Claim(s)", new Link(By.xpath("//a[@title='Claim(s)']")));

        controlButtonClaimsDetail.put("Return to Policy", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Return to Policy')]")));
        controlButtonClaimsDetail.put("Submit to Processing", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Submit to Processing')]")));
        controlButtonClaimsDetail.put("Move Claims", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Move Claims')]")));
        controlButtonClaimsDetail.put("Place On Hold", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Place On Hold')]")));
        controlButtonClaimsDetail.put("Save", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Save')]")));
        controlButtonClaimsDetail.put("Finalize All Loss(es)", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Finalize All Loss(es)')]")));
        controlButtonClaimsDetail.put("Preview EOB", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Preview EOB')]")));
        controlButtonClaimsDetail.put("Complete Processing", new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),'Complete Processing')]")));
        controlButtonClaimsDetail.put("Assign to Me", new Button(By.xpath("//div[@class='row-fluid'][1]//a[contains(.,' Assign to Me')]")));
        controlButtonClaimsDetail.put("Approve", new Button(By.xpath("//div[@class='row-fluid'][1]//a[contains(.,'Approve')]")));
        controlButtonClaimsDetail.put("Return to Certificate",new Button(By.xpath("//div[@class='row-fluid'][1]//*[contains(text(),' Return to Certificate')]")));
    }
}
