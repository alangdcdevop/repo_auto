package pages.orcaGroup;

import control.Button;
import control.Label;
import control.Select;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

import java.util.HashMap;
import java.util.Map;

public class MenuSections {
    public Map<String, Button> menuOption = new HashMap<>();

    public TextBox searchCertificateTextBox = new TextBox(By.xpath("//input[@placeholder='Search ']"));
    public Button goButton = new Button(By.xpath("//button[@id='btnSearch' or @id='btnSearchGroup']"));
    public Label lookBackPeriodLabel = new Label(By.xpath("//strong[normalize-space()='Look Back Period']"));
    public Select policyAndClaimDropdown = new Select(By.id("optSearchGroup"));

    public MenuSections() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
        menuOption.put("Admin", new Button(By.xpath("//a[text()='Admin']")));
        menuOption.put("Finance", new Button(By.xpath("//a[text()='Finance']")));
        menuOption.put("Certificate", new Button(By.xpath("//a[text()='Certificate']")));
        menuOption.put("Claims", new Button(By.xpath("//a[text()='Claims']")));
        menuOption.put("Assigned",new Button(By.xpath("//a[text()='Assigned ']")));
    }
}
