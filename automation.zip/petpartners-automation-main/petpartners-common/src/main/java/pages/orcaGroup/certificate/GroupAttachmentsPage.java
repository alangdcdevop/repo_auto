package pages.orcaGroup.certificate;

import control.Button;
import org.openqa.selenium.By;

public class GroupAttachmentsPage {

    public Button addNewButton = new Button(By.xpath("//a[@title='Add Attachment']"));
    public Button returnCertificateButton = new Button(By.xpath("//a[@title='Cancel']"));
    public Button attachmentDetailsSaveButton = new Button(By.xpath("//button[normalize-space()='Save']"));

}
