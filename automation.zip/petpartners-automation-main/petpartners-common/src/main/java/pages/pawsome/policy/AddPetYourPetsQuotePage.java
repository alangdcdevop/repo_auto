package pages.pawsome.policy;

import control.*;
import entities.akc.AddPetYourPetsQuoteEntity;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class AddPetYourPetsQuotePage {
    public TextBox petNameTextBox = new TextBox(By.id("name"));
    public RadioButton dogPetTypeOption = new RadioButton(By.xpath("//input[@id=\"dog\"]"));
    public RadioButton catPetTypeOption = new RadioButton(By.xpath("//input[@id=\"cat\"]"));
    public CustomSelect petBreedSelect = new CustomSelect(By.xpath("//input[@id=\"breedSearch\"]"),"p");
    public Select petAgeSelect = new Select(By.xpath("//select[@id=\"age\"]"));
    public RadioButton yesHasYourPetOption = new RadioButton(By.xpath("//input[@id=\"yes\"]"));
    public RadioButton noHasYourPetOption = new RadioButton(By.xpath("//input[@id=\"no\"]"));
    public Button chooseCoverageButton = new Button(By.xpath("//button[@id=\"submit\"]"));

    public void fillGetQuote(AddPetYourPetsQuoteEntity addPetQuoteEntity) throws Exception {
        Logger.log(Level.INFO, this.getClass().getName() + "> Fill QUOTE: " + this.getClass().getSimpleName());
        Thread.sleep(1000);
        this.petNameTextBox.setText(addPetQuoteEntity.petName);
        Thread.sleep(2000);

        if (addPetQuoteEntity.getPetType().toLowerCase().equals("dog"))
            this.dogPetTypeOption.click();
        else if (addPetQuoteEntity.getPetType().toLowerCase().equals("cat"))
            this.catPetTypeOption.click();
        Thread.sleep(8000);

        petBreedSelect.controlIsDisplayed();
        petBreedSelect.controlIsClickable();
        petBreedSelect.setAndClickValue(addPetQuoteEntity.getPetBreed());

        Thread.sleep(1000);
        petAgeSelect.selectValue(addPetQuoteEntity.getPetAge());

        if (addPetQuoteEntity.getHasYourPetEverBeenDiagnosed().toLowerCase().equals("yes")) {
            this.yesHasYourPetOption.click();
        } else if (addPetQuoteEntity.getHasYourPetEverBeenDiagnosed().toLowerCase().equals("no")) {
            this.noHasYourPetOption.click();
        }

        this.chooseCoverageButton.click();
        Thread.sleep(3000);
    }
}