package pages.ppi;

import control.*;
import entities.ppi.CompleteEnrollmentEntity;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import session.Session;
import utils.Level;
import utils.Logger;

public class CompleteYourEnrollment {
    public TextBox firstNameTextBox = new TextBox(By.xpath("//input[@id='customer-firstName']"));
    public TextBox lastNameTextBox = new TextBox(By.xpath("//input[@id='customer-lastName']"));
    public TextBox addressTestBox = new TextBox(By.xpath("//input[@id='customer-address-address1']"));
    public TextBox aptSuiteTextBox = new TextBox(By.xpath("//input[@id='customer-address-address2']"));
    public TextBox cityTextBox = new TextBox(By.xpath("//input[@id='customer-address-city']"));
    public Select stateSelect = new Select(By.id("customer-address-stateProvId"));
    public TextBox zipCodeTextBox = new TextBox(By.xpath("//input[@id='customer-address-zipCode']"));
    public TextBox phoneNumberTextBox = new TextBox(By.xpath("//input[@id='customer-phoneNumber']"));
    public TextBox emailAddressTextBox = new TextBox(By.xpath("//input[@id='customer-emailAddress']"));
    public TextBox groupCodeTextBox = new TextBox(By.xpath("//input[@id='affinity-group-code']"));

    public Button applyButton = new Button(By.xpath("//button[contains(.,'Apply')]"));

    public TextBox nameOnCardTextBox = new TextBox(By.xpath("//input[@id='customer-paymentInfo-nameOnCard']"));
    public TextBox cardNumberTextBox = new TextBox(By.xpath("//input[@id='customer-paymentInfo-cardNumber']"));
    public TextBox expiresMMTextBox = new TextBox(By.xpath("//input[@id='customer-paymentInfo-expirationMonth']"));
    public TextBox expireYYYYTextBox = new TextBox(By.xpath("//input[@title='Enter the card expiration year']"));
    public TextBox cvcTextBox = new TextBox(By.xpath("//input[@id='customer-paymentInfo-cvc']"));

    public RadioButton byCheckingThisBoxRadioButton = new RadioButton(By.xpath("//input[@name='fee-disclosure']"));
    public RadioButton agreePaperLessRadioButton = new RadioButton(By.xpath("//input[@name='electronic-delivery']"));
    public RadioButton agreeApplicationRadioButton = new RadioButton(By.xpath("//input[@name='e-consent']"));
    public Button enrollNowButton = new Button(By.xpath("//button[@id='enroll']"));

    public Link editPlanDetailsLink = new Link(By.xpath("//button[contains(text(),'Edit plan details')]"));
    public Link removePlanLink = new Link(By.xpath("//button[contains(text(),'Remove Plan')]"));
    public Button removePlanYesButton = new Button(By.xpath("//button[contains(text(),'Yes')]"));
    public Button removePlanNoButton = new Button(By.xpath("//button[contains(text(),'No')]"));
    public Label cartIsEmptyLabel = new Label(By.xpath("//*[@class = 'heading']//*[text() ='Your cart is empty!']"));
    public Link showTermDetailsLink = new Link(By.xpath("//button[contains(text(),'Term Details')]"));
    public Button showTermDeductible = new Button(By.xpath("//li[contains(text(),'Deductible')]"));
    public Button showTermCoinsurance = new Button(By.xpath("//li[contains(text(),'Coinsurance')]"));
    public Button showTermIncident = new Button(By.xpath("//li[contains(text(),'Incident')]"));
    public Button showTermAnnual = new Button(By.xpath("//li[contains(text(),'Annual')]"));
    public Button addAnotherPetSave = new Button(By.xpath("//button[contains(text(),'Add Another Pet')]"));
    public Label premiumMonthly = new Label(By.xpath("//div[@class='pet-overview__premium-price c--secondary']/span"));
    public Label discount = new Label(By.xpath("//div[contains(@class,'pet-overview__policy-monthly-saving')]/span"));

    public CompleteYourEnrollment() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void fillCompleteYourEnrollment(CompleteEnrollmentEntity completeEnrollmentEntity) throws Exception {
        this.firstNameTextBox.setText(completeEnrollmentEntity.getFirstName());
        this.lastNameTextBox.setText(completeEnrollmentEntity.getLastName());
        this.addressTestBox.setText(completeEnrollmentEntity.getAddress());
        this.aptSuiteTextBox.setText(completeEnrollmentEntity.getAptSuite());
        this.phoneNumberTextBox.setText(completeEnrollmentEntity.getPhoneNumber());
        this.emailAddressTextBox.setText(completeEnrollmentEntity.getEmailAddress());
        this.nameOnCardTextBox.setText(completeEnrollmentEntity.getNameOnCard());
        this.cardNumberTextBox.setText(completeEnrollmentEntity.getCardNumber());
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,500)");
        this.expiresMMTextBox.setText(completeEnrollmentEntity.getExpiresMM());
        this.expireYYYYTextBox.setText(completeEnrollmentEntity.getExpireYYYY());
        this.cvcTextBox.setText(completeEnrollmentEntity.getCvc());
        js.executeScript("window.scrollBy(0,200)");

        Thread.sleep(2000);
        if (this.byCheckingThisBoxRadioButton.controlIsDisplayed(10))
            this.byCheckingThisBoxRadioButton.select();

        Thread.sleep(3000);
        this.agreePaperLessRadioButton.select();
        this.agreeApplicationRadioButton.select();


        Thread.sleep(10000);
        this.enrollNowButton.click();
    }

}
