package pages.ppi;

import control.Button;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class LoginPage {

    public TextBox emailTextBox = new TextBox(By.xpath("//input[@email='true']"));
    public TextBox passwordTextBox = new TextBox(By.xpath("//input[@type='password']"));
    public Button loginButton = new Button(By.xpath("//button[contains(.,'Login')]"));
    public Button createAccountButton = new Button(By.xpath("//button[contains(.,'Create Account')]"));

    public LoginPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void login(String email, String password) throws Exception {
        this.emailTextBox.setText(email);
        this.passwordTextBox.setText(password);
        this.loginButton.click();
        Thread.sleep(10000);
    }

}
