package pages.ppi;

import control.Button;
import control.Link;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class MainPage {
    public Button getQuoteButton = new Button(By.xpath("//*[@id='innerGetQuoteBtn']/a"));
    public Button getQuoteFooterButton = new Button(By.xpath("//a[text()='Get quote']"));
    public Link loginLink = new Link(By.xpath("//a[text()='Log In']"));
    public Link activateCertificateLink = new Link(By.xpath("//a[text()='ACTIVATE COVERAGE']"));
    public Link activateCoverageLink = new Link(By.xpath("//a[@href='/certificate' and @class='cyan']"));

    public MainPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }
}
