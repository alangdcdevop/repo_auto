package pages.ppi;

import control.Button;
import control.TextBox;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class PortalPolicyDetailsPage {

    public Button changeCoverageOptions = new Button(By.xpath("//a[contains(text(),'Change Coverage Options')]"));
    public TextBox popupEffectiveDate = new TextBox(By.xpath("//input[@id='mat-input-0']"));
    public Button popupCancelButton = new Button(By.xpath("//button[@class='button__submit close-btn']"));
    public Button popupContinueButton = new Button(By.xpath("//button[@class='button__submit']"));

    //AddPet
    public Button addPetButton = new Button(By.xpath("//a[@class='ml--1 mb--1 middle-xs button__submit']"));

    public PortalPolicyDetailsPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }
}
