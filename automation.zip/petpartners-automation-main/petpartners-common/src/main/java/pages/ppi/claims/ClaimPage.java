package pages.ppi.claims;

import control.*;
import entities.ppi.ClaimEntity;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;


public class ClaimPage {
    public Select selectPolicySelect = new Select(By.xpath("//select[@formcontrolname='policyId']"));
    public RadioButton yesAdditionalInsurance = new RadioButton(By.xpath("//label[contains(.,'Yes')]/span"));
    public RadioButton noAdditionInsurance = new RadioButton(By.xpath("//label[contains(.,'No')]/span"));
    public Checkbox injuryIllnessCheckBox = new Checkbox(By.xpath("//label[contains(.,'Injury or Illness')]/span"));
    public Checkbox wellnessCheckbox = new Checkbox(By.xpath("//label[contains(.,'Wellness')]/span"));
    public TextBox tellUsTextBox = new TextBox(By.xpath("//textarea[@formcontrolname='diagnosis']"));
    public TextBox signCalendar = new TextBox(By.xpath("//input[@ng-reflect-name='onsetDate']"));
    public TextBox treatmentCalendar = new TextBox(By.xpath("//input[@formcontrolname='treatmentStartDate']"));
    public Button uploadFileButton = new Button(By.xpath("//pp-button[@showicon='upload']/button"));
    public Checkbox agreeCheckBox = new Checkbox(By.xpath("//span[@class='checkbox__checkmark']"));
    public Button submitClaimButton = new Button(By.xpath("//button[contains(.,'Submit Claim')]"));
    public Button cancelButton = new Button(By.xpath("//a[contains(.,'Cancel')]"));

    public TextBox uploadFileTextBox = new TextBox(By.xpath("//input[@formcontrolname='fileInput']"));
    public Label uploadFileLabel = new Label(By.xpath("//div[@class='card__value']"));


    public ClaimPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public void fillClaim(ClaimEntity entity) throws Exception {
        this.selectPolicySelect.controlIsDisplayed();
        if (this.selectPolicySelect.controlIsDisplayed())
            this.selectPolicySelect.selectValue(entity.getSelectPolicy());

        if (entity.getDoesYourPetHaveAdditional().toLowerCase().contains("yes"))
            this.yesAdditionalInsurance.click();
        else
            this.noAdditionInsurance.click();

        if (entity.getInjuryOrIllness().contains("checked")) {
            this.injuryIllnessCheckBox.check();
        }
        this.tellUsTextBox.setText(entity.getTellUsMoreAboutInjury());
        this.signCalendar.setText(entity.getWhenDidYuFirstNoticeSignDate());
        this.treatmentCalendar.setText(entity.getTreatmentStartDate());

        this.uploadFileTextBox.setText(entity.getUploadFile());
        this.agreeCheckBox.check();
        this.submitClaimButton.click();
    }

    public String getClaimNumber() throws Exception {
        Label claimNumber = new Label(By.xpath("//div[@class=\"claim__number\"]"));
        return claimNumber.getText().replace(" ", "");
    }


}
