package pages.ppi.home;

import control.Label;
import control.Link;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class HomePage {

    public Link submitClaimLink = new Link(By.xpath("//a[contains(.,'Submit Claim')]"));
    public Label policyDetailLabel = new Label(By.xpath("//h2[text()='Policy Details']"));
    public Label coverageLabel = new Label(By.xpath("//h2[text()='Coverage']"));
    public Link viewPolicyDetailLink = new Link(By.xpath("//button[contains(@title,'View policy documents')]"));

    //dialog

    public Label downloadAttachmentLabel = new Label(By.xpath("//h3[text()='Download your attachments']"));

    public HomePage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public boolean isPolicyNumberdisplayed(String policyNumber) {

        Label policyUnique = new Label(By.xpath("//*[contains(text(),'" + policyNumber + "')]"));
        return policyUnique.controlIsDisplayed();
    }

    public void clickOnPolicyNumber(String policyNumber) throws Exception {

        Label policyUnique = new Label(By.xpath("//*[contains(text(),'" + policyNumber + "')]"));
        policyUnique.click();
    }
}
