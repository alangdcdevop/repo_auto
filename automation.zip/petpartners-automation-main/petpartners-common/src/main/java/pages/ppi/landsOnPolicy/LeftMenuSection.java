package pages.ppi.landsOnPolicy;

import control.Button;
import org.openqa.selenium.By;
import utils.Level;
import utils.Logger;

public class LeftMenuSection {
    public Button homeMenu = new Button(By.xpath("//main//div[text()='Home']"));
    public Button claimsMenu = new Button(By.xpath("//main//div[text()='Claims']"));

    public LeftMenuSection() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }
}
