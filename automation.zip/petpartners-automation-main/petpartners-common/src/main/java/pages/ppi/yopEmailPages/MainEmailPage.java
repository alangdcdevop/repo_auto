package pages.ppi.yopEmailPages;

import control.Button;
import control.Label;
import control.TextBox;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.List;

public class MainEmailPage {

    public TextBox emailNameTextBox = new TextBox(By.xpath("//input[@id=\"login\"]"));
    public Button goButton = new Button(By.xpath("//button[@title=\"Check Inbox @yopmail.com\"]"));
    public Button refreshButton = new Button(By.xpath("//button[@id=\"refresh\"]"));
    public Label emailSubjectLabel = new Label(By.xpath("//span[contains(text(),'PetPartners')]"));
    public Label emailSubjectAKCLabel = new Label(By.xpath("//span[text()='AKC Pet Insurance']"));
    public Label emailSubjectDetailLabel = new Label(By.xpath("//header//div[contains(@class,'ellipsis')]"));
    public Button portalLoginButton = new Button(By.xpath("//a[text()='Portal Login']"));

    public Button captchaNotRobotCheckBox= new Button(By.xpath("//div[@class=\"recaptcha-checkbox-border\"]"));

    public MainEmailPage() {
        Logger.log(Level.INFO, this.getClass().getName() + "> Page: " + this.getClass().getSimpleName());
    }

    public int getNumberEmail(String subject){
        String emailLocator = "//div[@class=\"m\"]//div[contains(.,'"+subject+"')]";
        List <WebElement> controls= Session.getInstance().getDriver().findElements(By.xpath(emailLocator));
        return controls.size();
    }

    public boolean verifyAttachmentFile(String nameExpectedFile){
        Label attachment = new Label(By.xpath("//span[contains(.,'"+nameExpectedFile+"')]"));
        return attachment.controlIsDisplayed();
    }
}
