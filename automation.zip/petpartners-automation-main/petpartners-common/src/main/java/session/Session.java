package session;

import configuration.BrowserConfiguration;
import factoryBrowser.FactoryBrowser;
import org.openqa.selenium.WebDriver;
import utils.Level;
import utils.Logger;

import java.util.ArrayList;

public class Session {
    private static Session session = null;
    private WebDriver driver;

    private Session() {
        this.driver = FactoryBrowser.make(BrowserConfiguration.browser).create();
        Logger.log(Level.INFO, this.getClass().getName() + " > Browser type to use: " + BrowserConfiguration.browser);
    }

    public static Session getInstance() {
        if (session == null)
            session = new Session();
        return session;
    }

    public void closeSession()  {
        ArrayList<String> tabs = new ArrayList<String>( this.driver.getWindowHandles());
        this.driver.switchTo().window(tabs.get(0));
        Logger.log(Level.INFO, this.getClass().getName() + ">  Quit browser");
        this.driver.quit();
        session = null;
        Logger.log(Level.INFO, this.getClass().getName() + "> Singleton Destroyed: session = null");
    }

    public WebDriver getDriver() {
        if (session != null) {
            return driver;
        }else{
            try {
                throw new Exception("ERROR !!!!!!! > Please call the Singleton Session first");
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
}