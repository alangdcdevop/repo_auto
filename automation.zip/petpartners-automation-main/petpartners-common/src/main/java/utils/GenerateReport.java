package utils;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class GenerateReport {
    public static void generateReports(String mainPath, String jsonName, String version, String browser, String environment) throws InterruptedException {
        Thread.sleep(20000);
        File folderReport = new File(mainPath + "PetPartnersReport");

        List<String> jsonsLists = new ArrayList<>();
        jsonsLists.add(mainPath + jsonName);

        Configuration configuration = new Configuration(folderReport, "PetPartners Automation Result");
        configuration.setBuildNumber(version);
        configuration.addClassifications("Owner", "PetPartners - QA team");
        configuration.addClassifications("Browser", browser);
        configuration.addClassifications("Environment", environment);

        ReportBuilder reportBuilder = new ReportBuilder(jsonsLists, configuration);
        reportBuilder.generateReports();
    }
}
