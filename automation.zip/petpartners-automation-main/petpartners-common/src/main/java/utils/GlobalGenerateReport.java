package utils;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class GlobalGenerateReport {
    /**
     * This method is to generete a global report using all the json file in a folder
     *  args :  args[0] the folder path : i.e: C:\Users\EYNAR\Desktop\REPORT_JENKINS
     * */
    public static void main(String[] args) throws InterruptedException {
        String mainPath= args[0];
        Thread.sleep(20000);
        File folderReport = new File(mainPath + "/PetPartnersReport");
        List<String> jsonsLists = new ArrayList<>();
        File folder = new File(mainPath);
        File[] listOfFiles = folder.listFiles();

        for (int i = 0; i < listOfFiles.length; i++) {
            if (listOfFiles[i].isFile() && listOfFiles[i].toString().contains(".json")) {
                System.out.println("INFO > File: " + listOfFiles[i].getName());
                jsonsLists.add(mainPath+"/"+listOfFiles[i].getName());
            }
        }

        Configuration configuration = new Configuration(folderReport, "PetPartners Automation Result");
        configuration.setBuildNumber("");
        configuration.addClassifications("Owner", "PetPartners - Automation QA team");
        configuration.addClassifications("Browser", "CHROME");
        configuration.addClassifications("Environment", "QAS");

        ReportBuilder reportBuilder = new ReportBuilder(jsonsLists, configuration);
        reportBuilder.generateReports();
        System.out.println("INFO > The Report was generated Successfully");
    }
}
