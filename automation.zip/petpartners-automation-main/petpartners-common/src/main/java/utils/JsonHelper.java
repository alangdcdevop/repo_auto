package utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;

import java.util.Iterator;
import java.util.Map;

public class JsonHelper {

    public static String compartionErrors = "";

    public static JSONObject replaceValuesJson(Map<String, String> attributes, String json) {
        JSONObject jsonObject = new JSONObject(json);
        for (String attribute : attributes.keySet()) {
            if (jsonObject.has(attribute)) {
                Logger.log(Level.WARN, JsonHelper.class.getName() + "json: " + attribute + "   value: " + attributes.get(attribute));
                jsonObject.put(attribute, attributes.get(attribute));
                jsonObject.query(attribute);
            }
            //todo improve for multi tree on json, try to implement logic like JQ
        }

        return jsonObject;
    }

    public static void assertAreEqualJson(String expectedResult, String actualResult, String errorMessage) throws JsonProcessingException {
        compartionErrors = "";
        Assertions.assertTrue(compareJson(expectedResult, actualResult), errorMessage + compartionErrors);
    }

    public static boolean compareJson(String expectedResult, String actualResult) throws JsonProcessingException {
        boolean areEqual = true;

        JsonNode jsonNode = new ObjectMapper().readTree(expectedResult);
        if (jsonNode.isArray()) {

            JSONArray expectedJSON = new JSONArray(expectedResult);
            JSONArray actualJSON = new JSONArray(actualResult);

            for (int i = 0; i < expectedJSON.length(); i++) {
                compartionErrors = compartionErrors + "$position" + i;
                boolean isEqualSubLevel = compareJson(expectedJSON.get(i).toString(), actualJSON.get(i).toString());
                compartionErrors = isEqualSubLevel ? compartionErrors.replace("$position" + i, "") : compartionErrors.replace("$position" + i, "position [" + i + "]");

                areEqual = areEqual && isEqualSubLevel;
            }

        } else {

            JSONObject expectedJSON = new JSONObject(expectedResult);
            JSONObject actualJSON = new JSONObject(actualResult);
            Iterator<?> keyList = expectedJSON.keys();
            while (keyList.hasNext()) {
                String key = (String) keyList.next();
                String expectedValue = String.valueOf(expectedJSON.get(key));
                String actualValue = String.valueOf(actualJSON.get(key));

                if (expectedJSON.get(key) instanceof JSONArray) {
                    compartionErrors = compartionErrors + "$level" + key;
                    boolean isEqualSubLevel = compareJson(expectedValue, actualValue);
                    compartionErrors = isEqualSubLevel ? compartionErrors.replace("$level" + key, "") : compartionErrors.replace("$level" + key, key + ">");
                    areEqual = areEqual && isEqualSubLevel;
                } else if (expectedJSON.get(key) instanceof JSONObject) {
                    compartionErrors = compartionErrors + "$level" + key;
                    boolean isEqualSubLevel = compareJson(expectedValue, actualValue);
                    compartionErrors = isEqualSubLevel ? compartionErrors.replace("$level" + key, "") : compartionErrors.replace("$level" + key, key + ">");
                    areEqual = areEqual && isEqualSubLevel;
                } else {

                    if (expectedJSON.has(key) && actualJSON.has(key)) {
                        if (expectedValue.equals("IGNORE") || actualValue.equals("IGNORE")) {
                            Logger.log(Level.WARN, JsonHelper.class.getName() + " > the value was ignored [" + key + "]");
                        } else if (!expectedValue.equals(actualValue)) {
                            areEqual = false;
                            compartionErrors = compartionErrors + "\nERROR> the attribute [" + key + "] --> expected: [" + expectedValue + "] VS actual: [" + actualValue + "]";

                        }
                    } else {
                        areEqual = false;
                        compartionErrors = compartionErrors + "\nERROR> the attribute [" + key + "] does not exist";
                    }
                }
            }
        }
        return areEqual;
    }

}
