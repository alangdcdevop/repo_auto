package utils;

public enum Level {
    INFO,
    WARN,
    ERROR
}
