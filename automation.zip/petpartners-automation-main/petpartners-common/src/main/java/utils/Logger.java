package utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Logger {

    public static void log(Level level, String value) {
        String time = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss").format(new Date());
        System.out.println(time + "-" + level.name() + " > " + value);
    }
}
