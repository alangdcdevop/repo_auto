package unitTest.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import utils.JsonHelper;

public class JsonHelperTest {

    String jsonOneLevel = "{\n" +
            "  \"Id\": 3985250,\n" +
            "  \"Content\": \"eynarJmeter\",\n" +
            "  \"Count\": 0\n" +
            "}";

    String jsonThreeLevel = "{\n" +
            "  \"Id\": {\n" +
            "        \"IdLevel2\": 3985250,\n" +
            "        \"ContentLevel2\": \"eynarJmeter\",\n" +
            "        \"CountLevel2\": {\"level3\":2}\n" +
            "      },\n" +
            "  \"Content\": \"eynarJmeter\",\n" +
            "  \"Count\": 0\n" +
            "}";

    String jsonArrayObject = "[\n" +
            "{\n" +
            "  \"Id\": 3985250,\n" +
            "  \"Content\": \"eynarJmeter\",\n" +
            "  \"ItemsCount\": 0\n" +
            "}\n" +
            "]";

    @Test
    public void verifyJsonAssertOneLevel() throws JsonProcessingException {
        JsonHelper.assertAreEqualJson(jsonOneLevel, jsonOneLevel, "ERROR comparing one level");
    }

    @Test
    public void verifyJsonAssertOneLevelAreNotEqual() throws JsonProcessingException {
        String jsonOneLevelActual = "{\n" +
                "  \"Id\": 0,\n" +
                "  \"Content\": \"eynarJmeter\",\n" +
                "  \"Count\": 0\n" +
                "}";
        Assertions.assertFalse(JsonHelper.compareJson(jsonOneLevel, jsonOneLevelActual), JsonHelper.compartionErrors);
    }

    @Test
    public void verifyJsonAssertTreeLevel() throws JsonProcessingException {
        JsonHelper.assertAreEqualJson(jsonThreeLevel, jsonThreeLevel, "ERROR comparing one level");
    }

    @Test
    public void verifyJsonAssertTreeLevelAreNotEqual() throws JsonProcessingException {
        String jsonThreeLevelActual = "{\n" +
                "  \"Id\": {\n" +
                "        \"IdLevel2\": 3985250,\n" +
                "        \"ContentLevel2\": \"eynarJmeter\",\n" +
                "        \"CountLevel2\": {\"level3\":3}\n" +
                "      },\n" +
                "  \"Content\": \"eynarJmeter\",\n" +
                "  \"Count\": 0\n" +
                "}";
        Assertions.assertFalse(JsonHelper.compareJson(jsonThreeLevel, jsonThreeLevelActual), JsonHelper.compartionErrors);
    }

    @Test
    public void verifyJsonAssertArrayLevel() throws JsonProcessingException {
        JsonHelper.assertAreEqualJson(jsonArrayObject, jsonArrayObject, "ERROR comparing one level");
    }

    @Test
    public void verifyJsonAssertArrayLevelAreNotEqual() throws JsonProcessingException {
        String jsonArrayObjectActual = "[\n" +
                "{\n" +
                "  \"Id\": 10,\n" +
                "  \"Content\": \"eynarJmeter\",\n" +
                "  \"ItemsCount\": 0\n" +
                "}\n" +
                "]";
        Assertions.assertFalse(JsonHelper.compareJson(jsonArrayObject, jsonArrayObjectActual), JsonHelper.compartionErrors);
    }

    @Test
    public void verifyJsonAssertArrayComplexNotEquals() throws JsonProcessingException {
        String expected = "[\n" +
                "{\n" +
                "  \"Id\": 3985250,\n" +
                "  \"Content\": \"eynarJmeter\",\n" +
                "  \"ItemsCount\": [\n" +
                "                  {\n" +
                "                    \"id\":\"test\",\n" +
                "                    \"name\":\"eynar\"\n" +
                "                  },\n" +
                "                   {\n" +
                "                    \"id\":\"test2\",\n" +
                "                    \"name\":\"eynar2\"\n" +
                "                  }\n" +
                "                ]\n" +
                "}\n" +
                "]";

        String actual = "[\n" +
                "{\n" +
                "  \"Id\": 3985250,\n" +
                "  \"Content\": \"eynarJmeter\",\n" +
                "  \"ItemsCount\": [\n" +
                "                  {\n" +
                "                    \"id\":\"test\",\n" +
                "                    \"name\":\"eynar\"\n" +
                "                  },\n" +
                "                   {\n" +
                "                    \"id\":\"test2\",\n" +
                "                    \"name\":\"DIFFERENT\"\n" +
                "                  }\n" +
                "                ]\n" +
                "}\n" +
                "]";
        Assertions.assertFalse(JsonHelper.compareJson(expected, actual), JsonHelper.compartionErrors);
    }

    @Test
    public void verifyJsonAssertArrayInAttributeNotEqual() throws JsonProcessingException {
        String expected = "{\n" +
                "  \"Id\": 3985250,\n" +
                "  \"Content\": \"eynarJmeter\",\n" +
                "  \"ItemsCount\": [\n" +
                "                  {\n" +
                "                    \"id\":\"test\",\n" +
                "                    \"name\":\"eynar\"\n" +
                "                  },\n" +
                "                   {\n" +
                "                    \"id\":\"test2\",\n" +
                "                    \"name\":\"DIFFERENT\"\n" +
                "                  }\n" +
                "                ]\n" +
                "}";

        String actual = "{\n" +
                "  \"Id\": 3985250,\n" +
                "  \"Content\": \"eynarJmeter\",\n" +
                "  \"ItemsCount\": [\n" +
                "                  {\n" +
                "                    \"id\":\"test\",\n" +
                "                    \"name\":\"eynar\"\n" +
                "                  },\n" +
                "                   {\n" +
                "                    \"id\":\"test2\",\n" +
                "                    \"name\":\"eynar3\"\n" +
                "                  }\n" +
                "                ]\n" +
                "}";
        Assertions.assertFalse(JsonHelper.compareJson(expected, actual), JsonHelper.compartionErrors);
    }

}
