package runner;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.akc.CreateAccountPage;

import java.util.Map;


public class CreateAccountStep extends BaseSteps{
     CreateAccountPage createAccountPage = new CreateAccountPage();
    @Then("the create account page should be displayed")
    public void theCreateAccountPageShouldBeDisplayed() {
        Assertions.assertTrue(createAccountPage.createAccountButton.controlIsDisplayed(),"ERROR> the create account page is not displayed");
    }

    @And("create an account using the default email")
    public void createAnAccountUsing(Map<String,String> credentials) throws Exception {
       createAccountPage.passwordTextBox.clearSetText(this.replaceConfigurationValues(credentials.get("password")));
       createAccountPage.confirmPasswordTextBox.clearSetText(  this.replaceConfigurationValues(credentials.get("confirm password")));
       createAccountPage.createAccountButton.click();
    }

    @And("create an account using")
    public void createAnAccountUsingValues(Map<String,String> credentials) throws Exception {
        createAccountPage.createNewAccount(this.replaceConfigurationValues(credentials.get("email")),
                this.replaceConfigurationValues(credentials.get("password")),
                this.replaceConfigurationValues(credentials.get("confirm password")));
    }
}
