package runner;


import entities.akc.GetQuoteEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.akc.CoveragePage;
import pages.akc.GetQuotePage;

import java.util.Map;

public class GetQuoteStep extends BaseSteps {
    GetQuotePage getQuotePage= new GetQuotePage();
    CoveragePage coveragePage = new CoveragePage();
    @Then("the Your pet's quote is displayed in Quote Page")
    public void theYourPetSQuoteIsDisplayedInQuotePage() {
        Assertions.assertTrue(getQuotePage.yourPetQuoteLabel.controlIsDisplayed(),"ERROR > the Your pet's quote is not displayed!");
    }

    @And("^(fill|updating) the Get Quote Page$")
    public void fillTheGetQuotePage(String action,GetQuoteEntity quoteEntityEntry) throws Exception {
        if (action.equals("fill")){
           this.getQuotePage.fillGetQuote(quoteEntityEntry);
        }else {
           this.getQuotePage.updateGetQuote(quoteEntityEntry);
        }
    }
    @DataTableType
    public GetQuoteEntity quoteEntityEntry(Map<String,String> entry){
        GetQuoteEntity entity= new GetQuoteEntity();
        entity.setPetName(replaceConfigurationValues(entry.get("PET NAME"))).
               setPetType(this.replaceConfigurationValues(entry.get("PET TYPE"))).
               setPetBreed(this.replaceConfigurationValues(entry.get("PET BREED"))).
               setPetAge(this.replaceConfigurationValues(entry.get("PET AGE"))).
               setHasYourPetEverBeenDiagnosed(this.replaceConfigurationValues(entry.get("HAS YOUR PET EVER BEEN DIAGNOSED"))).
               setEmailAddress(this.replaceConfigurationValues(entry.get("EMAIL ADDRESS")));

        if (entry.containsKey("ZIP CODE")) {
            entity.setZipCode(this.replaceConfigurationValues(entry.get("ZIP CODE")));
        }
        return entity;
    }

    @And("click ADD TO CART button in Coverage Page")
    public void clickADDTOCARTButtonInCoveragePage() throws Exception {
        coveragePage.addToCartButton.click();
    }

    @When("filling the lookup - Your pet's quote section")
    public void fillingTheLookupYourPetSQuoteSection(Map<String,String> certificateValues) throws Exception {
        Thread.sleep(10000);
        getQuotePage.registrationNumberTextBox.click();
        getQuotePage.registrationNumberTextBox.setText(this.replaceConfigurationValues(certificateValues.get("REGISTRATION NUMBER")));
        getQuotePage.zipCodeRegistrationTextBox.setText(this.replaceConfigurationValues(certificateValues.get("ZIP CODE")));
    }

    @And("click on the Look Up Pet button")
    public void clickOnTheLookUpPetButton() throws Exception {
        getQuotePage.lookUpPetButton.click();
        Thread.sleep(10000);
    }

    @And("click on {} option in HAS YOUR PET EVER BEEN DIAGNOSED WITH OR SHOWN SYMPTOMS OF DIABETES?")
    public void clickOnNOOptionInHASYOURPETEVERBEENDIAGNOSEDWITHORSHOWNSYMPTOMSOFDIABETES(String option) throws Exception {
        if (option.contains("NO")) {
            getQuotePage.noHasYourPetOption.click();
        }else {
           getQuotePage.yesHasYourPetOption.click();
        }
    }

    @And("click on the CHOOSE COVERAGE button")
    public void clickOnTheCHOOSECOVERAGEButton() throws Exception {
        getQuotePage.chooseCoverageButton.click();
    }


    @And("i select the {string} in PET BREED combobox in GetQuote Page")
    public void iSelectTheInPETBREEDComboboxInGetQuotePage(String value) throws Exception {
        Thread.sleep(1000);
        getQuotePage.petBreedSelect.clear();
        getQuotePage.petBreedSelect.setAndClickValue(this.replaceConfigurationValues(value));
    }

    @And("i select the {string} in PET AGE combobox in GetQuote Page")
    public void iSelectTheInPETAGEComboboxInGetQuotePage(String value) throws Exception {
        getQuotePage.petAgeSelect.selectValue(this.replaceConfigurationValues(value));
    }

    @And("i click on CHOOSE COVERAGE button")
    public void iClickOnCHOOSECOVERAGEButton() throws Exception {
        getQuotePage.chooseCoverageButton.click();
        Thread.sleep(5000);
    }

    @And("I select customer source value as {string}")
    public void iSelectCustomerSourceValue(String value) throws Exception{
        getQuotePage.customerSource.selectValue(this.replaceConfigurationValues(value));
    }

}
