package runner;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.akc.CertificateOfferPage;
import pages.akc.MainPage;

public class MainPageSteps extends BaseSteps {
    MainPage mainPage = new MainPage();
    CertificateOfferPage certificateOfferPage= new CertificateOfferPage();
    @When("I check the GET QUOTE button in header is available")
    public void iCheckTheGETQUOTEButtonInHeaderIsAvailable() {
        Assertions.assertTrue(mainPage.getQuoteButton.controlIsDisplayed(),"ERROR> The GET QUOTE button is not displayed");
    }

    @And("click on GET QUOTE button")
    public void clickOnGETQUOTEButton() throws Exception {
        mainPage.getQuoteButton.click();
    }

    @And("click login link in akc main page")
    public void clickLoginLinkInAkcMainPage() throws Exception {
        mainPage.loginLink.click();
    }

    @Then("verify the Activate Coverage is displayed")
    public void verifyTheActivateCoverageIsDisplayed() {
        Assertions.assertTrue(mainPage.activateCoverage.controlIsDisplayed(),"ERROR> the Activate Coverage for Certification is not displayed");
    }

    @Then("click Activate Coverage button")
    public void clickActivateCoverageButton() throws Exception {
        mainPage.activateCoverage.click();
    }

    @And("click on activate coverage button on certificate page")
    public void clickOnActivateCoverageButtonOnCertificatePage() throws Exception {
        certificateOfferPage.activateCoverageButton.click();
    }

    @And("close signup popup window in main page")
    public void closeSignupPopupWindowInMainPage() throws Exception {
        if (mainPage.signUpPopUpClose.controlIsDisplayed(10))
            mainPage.signUpPopUpClose.click();
    }
}
