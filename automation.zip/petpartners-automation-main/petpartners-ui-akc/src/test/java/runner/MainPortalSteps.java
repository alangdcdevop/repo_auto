package runner;

import io.cucumber.java.en.And;
import org.junit.jupiter.api.Assertions;
import pages.akc.MainPortalPage;

public class MainPortalSteps extends BaseSteps {
    MainPortalPage mainPortalPage= new MainPortalPage();
    @And("verify the Welcome to your Customer Portal! is displayed in Portal")
    public void verifyTheWelcomeToYourCustomerPortalIsDisplayedInPortal() {
        Assertions.assertTrue(mainPortalPage.welcomeLabel.controlIsDisplayed(),"ERROR! the main page for Portal is not displayed");
    }
}
