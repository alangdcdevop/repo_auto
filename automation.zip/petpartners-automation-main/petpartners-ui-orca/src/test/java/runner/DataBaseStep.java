package runner;

import configuration.CommonValues;
import helpers.GetProperties;
import io.cucumber.java.en.And;
import org.junit.jupiter.api.Assertions;
import runner.stepsOrca.BaseSteps;
import utils.Level;
import utils.Logger;
import utils.SqlDBClient;

import java.sql.SQLException;
import java.util.Random;

public class DataBaseStep extends BaseSteps {

    SqlDBClient sqlDBClient = new SqlDBClient();

    @And("I connect to the database {string} to get the column {string} running the next query")
    public void iConnectToTheDatabaseToRunTheNextQuery(String databaseName,String columnName, String query) throws SQLException, ClassNotFoundException {

        switch (databaseName.toLowerCase()){
            case "mclead":
                sqlDBClient.setDataBase("mclead");
                break;
            case "group":
                sqlDBClient.setDataBase("group");
                break;
            default:
                sqlDBClient.setDataBase("orca");
                break;

        }
        sqlDBClient.setUser(GetProperties.getInstance().getSqlUser())
                .setPwd(GetProperties.getInstance().getSqlPassword())
                .setServer(GetProperties.getInstance().getSqlServer());

        queryResult=sqlDBClient.executeQuery(sqlDBClient.getConnection(), this.replaceConfigurationValues(query),columnName);
    }

    @And("^I get the (first|last|random) value of query result and save on (.*)$")
    public void iGetTheFirstValueOfQueryResultAndSaveOnValue(String criteria, String nameVariable) {

       int position= criteria.contains("first")?
                     0:criteria.contains("last")?queryResult.size()-1:
                       new Random().nextInt(queryResult.size()-1) +1;

        CommonValues.variables.put(nameVariable, queryResult.get(position));
        Logger.log(Level.INFO,this.getClass().getName()+" variable: ["+nameVariable+"] value: ["+CommonValues.variables.get(nameVariable)+"]");
    }

    @And("^I get ALL value of query result and save on (.*)$")
    public void iGetAllValueOfQueryResultAndSaveOnValue( String nameVariable) {
        CommonValues.variables.put(nameVariable, queryResult.toString());
        Logger.log(Level.INFO,this.getClass().getName()+" variable: ["+nameVariable+"] value: ["+CommonValues.variables.get(nameVariable)+"]");
    }
    @And("verify the query result have at least {int} result")
    public void verifyTheQueryResultHaveAtLeastResult(int amountResult) {
        Logger.log(Level.INFO,this.getClass().getName()+" query result size: "+queryResult.size()+" >= amount expected: "+amountResult);
        Assertions.assertTrue(queryResult.size() >= amountResult,"ERROR the size of result is < "+amountResult);
    }

    @And("verify the {} is equal to {}")
    public void verifyTheValueIsEqualToVariable(String  variable, String expectedResult) {
        Logger.log(Level.INFO,this.getClass().getName()+"expected result query: [" +this.replaceConfigurationValues(expectedResult)+ "] vs actual result: ["+this.replaceConfigurationValues(variable)+"]");
        Assertions.assertEquals(this.replaceConfigurationValues(expectedResult),this.replaceConfigurationValues(variable),"ERROR the values are not the same");
    }

    @And("verify the {} contains to {}")
    public void verifyTheValueContainsToVariable(String  variable, String expectedResult) {
        Logger.log(Level.INFO,this.getClass().getName()+"expected result query: [" +this.replaceConfigurationValues(expectedResult)+ "] vs actual result: ["+this.replaceConfigurationValues(variable)+"]");
        Assertions.assertTrue(this.replaceConfigurationValues(variable).contains(this.replaceConfigurationValues(expectedResult)),
                "ERROR! the actual result: ["+this.replaceConfigurationValues(variable)+"] does not contains ["+this.replaceConfigurationValues(expectedResult)+"]");
    }
}
