package runner.stepsOrca.admin;


import entities.orca.CreateNewUserEntity;
import entities.orca.policy.UserManagementEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.JavascriptExecutor;
import pages.orca.admin.adminDashboard.AccountDetailPage;
import pages.orca.admin.adminDashboard.UserManagementPage;
import runner.stepsOrca.BaseSteps;
import session.Session;
import java.util.List;
import java.util.Map;

public class AdminSteps extends BaseSteps {
    AccountDetailPage accountDetailPage = new AccountDetailPage();
    UserManagementPage userManagementPage = new UserManagementPage();


    @And("^I check the user is a (Claims Specialist|Administrator|Claims Admin|.*)$")
    public void iCheckTheUserIsAClaimSpecialist(String roles, Map<String, String> userFilter) throws Exception {
        menuSection.optionMenu.get("Admin").click();
        subMenuSection.optionSubMenu.get("User Management").click();
        for (String filter : userFilter.keySet()) {
            userManagementPage.textBoxMap.get(filter).clearSetText(this.replaceConfigurationValues(userFilter.get(filter)));
        }
        userManagementPage.runSearchButton.click();
        Thread.sleep(5000);
        userManagementPage.searchResultTable.clickLink(1, 1);
        if (roles.contains("Claims Admin"))
            accountDetailPage.rolesCheckBoxMap.get("Claims Admin").check();
        else
            accountDetailPage.rolesCheckBoxMap.get("Claims Admin").uncheck();

        if (roles.contains("Administrator"))
            accountDetailPage.rolesCheckBoxMap.get("Administrator").check();
        else
            accountDetailPage.rolesCheckBoxMap.get("Administrator").uncheck();

        if (roles.contains("Claims Specialist"))
            accountDetailPage.rolesCheckBoxMap.get("Claims Specialist").check();
        else
            accountDetailPage.rolesCheckBoxMap.get("Claims Specialist").uncheck();

        this.scrollDown();
        accountDetailPage.saveButton.click();
    }

    @And("I fill out the applications on account details page")
    public void iFillOutTheApplicationsOnAccountDetailsPage(CreateNewUserEntity createNewUserEntity) throws Exception {

        if (!createNewUserEntity.getFirstName().isEmpty())
            accountDetailPage.firstNameTextBox.setText(this.replaceConfigurationValues(createNewUserEntity.getFirstName()));
        if (!createNewUserEntity.getLastName().isEmpty())
            accountDetailPage.lastNameTextBox.setText(this.replaceConfigurationValues(createNewUserEntity.getLastName()));
        if (!createNewUserEntity.getDomain().isEmpty())
            accountDetailPage.domainTextBox.setText(this.replaceConfigurationValues(createNewUserEntity.getDomain()));
        if (!createNewUserEntity.getUserName().isEmpty())
            accountDetailPage.userNameTextBox.setText(this.replaceConfigurationValues(createNewUserEntity.getUserName()));
        if (!createNewUserEntity.getEmailAddress().isEmpty())
            accountDetailPage.emailAddressTextBox.setText(this.replaceConfigurationValues(createNewUserEntity.getEmailAddress()));

    }

    @DataTableType
    public CreateNewUserEntity getEntity(Map<String, String> entity) {
        CreateNewUserEntity tmp = new CreateNewUserEntity();
        if (entity.containsKey("First Name"))
            tmp.setFirstName(entity.get("First Name"));
        if (entity.containsKey("Last Name"))
            tmp.setLastName(entity.get("Last Name"));
        if (entity.containsKey("Domain"))
            tmp.setDomain(entity.get("Domain"));
        if (entity.containsKey("Username"))
            tmp.setUserName(entity.get("Username"));
        if (entity.containsKey("E-mail Address"))
            tmp.setEmailAddress(entity.get("E-mail Address"));

        return tmp;
    }

    @And("I click [{string}] button on Account Details Page")
    public void iClickButtonOnAccountDetailsPage(String value) throws Exception {
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,900)");
        if (value.contains("Save")) {
            accountDetailPage.saveButton.click();
        } else if (value.contains("Cancel"))
            accountDetailPage.cancelButton.click();
    }

    @Then("I verify Audit trial Sub tab on Account Details Page")
    public void iVerifyAuditTrialSubTabOnAccountDetailsPage(List<String> expectedResult) throws Exception {
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,900)");
        Thread.sleep(2500);
        Assertions.assertTrue(accountDetailPage.auditTrialTable.verifyAllHeaderLabel(expectedResult),
                "Some labels in the table is missing, actual [" + accountDetailPage.auditTrialTable.getAllHeaderLabel().toString() + " vs expected [" + expectedResult.toString() + "]");
    }

    @And("I click {string} Button on Create user page")
    public void iClickButtonOnCreateUserPage(String value) throws Exception {
        if (value.contains("Add New"))
            userManagementPage.addNewButton.click();
    }

    @And("I Click Roles CheckBox on account Details Page {string}")
    public void iClickRolesCheckBoxOnAccountDetailsPage(String value) throws Exception {
        accountDetailPage.rolesCheckBoxMap.get(value).check();

    }

    @And("I check Active Check box on account details page")
    public void iCheckActiveCheckBoxOnAccountDetailsPage() throws Exception {
        accountDetailPage.activeCheckBox.check();
    }

    @And("I Enter the {string} to Email Address TextBox On User Management page")
    public void iEnterTheToEmailAddressTextBoxOnUserManagementPage(String value) throws Exception {
        userManagementPage.textBoxMap.get("Email Address").setText(value);
    }

    @And("I click on {string} Button On User Management page")
    public void iClickOnButtonOnUserManagementPage(String value) throws Exception {
        if (value.contains("Clear")) {
            userManagementPage.clearButton.click();
            userManagementPage.clearButton.controlIsClickable();
        } else if (value.contains("Run Search")) {
            userManagementPage.runSearchButton.click();
            userManagementPage.runSearchButton.controlIsClickable();
        }
    }

    @DataTableType
    public UserManagementEntity getentity(Map<String, String> entity) {
        UserManagementEntity tmm = new UserManagementEntity();
        if (entity.containsKey("First Name"))
            tmm.setFirstName(entity.get("First Name"));
        if (entity.containsKey("Last Name"))
            tmm.setLastName(entity.get("Last Name"));
        if (entity.containsKey("BrokerId"))
            tmm.setBrokerId(entity.get("BrokerId"));
        if (entity.containsKey("Username"))
            tmm.setUserName(entity.get("Username"));
        if (entity.containsKey("E-mail Address"))
            tmm.setEmailAddress(entity.get("E-mail Address"));
        return tmm;
    }

    @When("I Search the User with next value on UserManagement Page")
    public void iSearchTheUserWithNextValueOnUserManagementPage(UserManagementEntity userManagementEntity) throws Exception {
        userManagementPage.clearButton.click();
        if (!userManagementEntity.getFirstName().isEmpty())
            userManagementPage.firstNameTextBox.setText(this.replaceConfigurationValues(userManagementEntity.getFirstName()));
        if (!userManagementEntity.getLastName().isEmpty())
            userManagementPage.lastNameTextBox.setText(this.replaceConfigurationValues(userManagementEntity.getLastName()));
        if (!userManagementEntity.getFirstName().isEmpty())
            userManagementPage.userNameTextBox.setText(this.replaceConfigurationValues(userManagementEntity.getUserName()));
        if (!userManagementEntity.getEmailAddress().isEmpty())
            userManagementPage.emailAddress.setText(this.replaceConfigurationValues(userManagementEntity.getEmailAddress()));
        userManagementPage.runSearchButton.click();
    }

    @And("I click On {string} Button on User management Page result search Table")
    public void iClickOnButtonOnUserManagementPageResultSearchTable(String value) throws Exception {
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,900)");
        if (value.contains("Register")) {
            userManagementPage.registerButton.click();
        } else if (value.contains("View")) {
            js.executeScript("window.scrollBy(0,900)");
            userManagementPage.viewButton.controlIsClickable();
            userManagementPage.viewButton.click();
        }
    }

    @And("I modify the Users Information On Account Details Page")
    public void iModifyTheUsersInformationOnAccountDetailsPage(CreateNewUserEntity createNewUserEntity) throws Exception {
        if (!createNewUserEntity.getFirstName().isEmpty())
            accountDetailPage.firstNameTextBox.clearSetText(this.replaceConfigurationValues(createNewUserEntity.getFirstName()));
        if (!createNewUserEntity.getLastName().isEmpty())
            accountDetailPage.lastNameTextBox.clearSetText(this.replaceConfigurationValues(createNewUserEntity.getLastName()));
    }

    @Then("I verify Email  TexBox is empty On User Management Page")
    public void iVerifyEmailTexBoxIsEmptyOnUserManagementPage() throws Exception {
        Assertions.assertTrue(userManagementPage.emailAddress.getTextAttribute("Value").isEmpty());
    }

    @And("I Click {string} on SearchResult table")
    public void iClickOnSearchResultTable(String value) throws Exception {
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,900)");
        if (value.contains("SyuserId")) {
            userManagementPage.syuserIdSortButton.click();
        } else if (value.contains("User")) {
            userManagementPage.userSortButton.click();
        } else if (value.contains("Actions")) {
            userManagementPage.actionButton.click();
        } else if (value.contains("Broker")) {
            userManagementPage.brokerButton.click();
        }
    }
    @When("I select {string} in pagination property on User Management page")
    public void iSelectInPaginationPropertyOnUserManagementPage(String value) throws Exception {
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,900)");
        userManagementPage.paginationPropertyDropdown.selectValue(value);
    }
    @Then("I verify Selected records {string} display on user Management search result table")
    public void iVerifySelectedRecordsDisplayOnUserManagementSearchResultTable(String value) throws Exception {
        Assertions.assertTrue(userManagementPage.paginationPropertyDropdown.getTextOptionSelected().contains(value));
    }

    @Then("I Verify SearchResult table display on User Management page")
    public void iVerifySearchResultTableDisplayOnUserManagementPage(List<String> element) throws Exception {
        Assertions.assertTrue(userManagementPage.searchResultTable.verifyAllHeaderLabel(element));
    }
}