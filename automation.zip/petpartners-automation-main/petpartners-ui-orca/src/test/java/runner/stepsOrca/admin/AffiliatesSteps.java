package runner.stepsOrca.admin;

import entities.orca.affiliate.CreateAnewAffiliateEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.affiliate.AffiliatePage;
import runner.stepsOrca.BaseSteps;

import java.util.Map;

public class AffiliatesSteps extends BaseSteps {

    AffiliatePage affiliatePage = new AffiliatePage();

    @And("I click on {string} Button in the affiliate page")
    public void iClickOnButtonInTheAffiliatePage(String value) throws Exception {
        affiliatePage.affiliatesMap.get(value).click();

    }

    @DataTableType
    public CreateAnewAffiliateEntity getEntity(Map<String, String> entity) {
        CreateAnewAffiliateEntity tmp = new CreateAnewAffiliateEntity();

        if (entity.containsKey("Affiliate Name"))
            tmp.setAffiliateName(entity.get("Affiliate Name"));
        if (entity.containsKey("Receivables Name"))
            tmp.setReceivablesName(entity.get("Receivables Name"));
        if (entity.containsKey("Address1"))
            tmp.setAdress1(entity.get("Address1"));
        if (entity.containsKey("City"))
            tmp.setCity(entity.get("City"));
        if (entity.containsKey("State"))
            tmp.setState(entity.get("State"));
        if (entity.containsKey("Postal Code"))
            tmp.setPostalCode(entity.get("Postal Code"));
        if(entity.containsKey("Lead Fee Tier"))
            tmp.setLeadFeeTier(entity.get("Lead Fee Tier"));
        return tmp;
    }

    @When("I fill out the applications on the affiliate page")
    public void iFillOutTheApplicationsOnTheAffiliatePage(CreateAnewAffiliateEntity createAnewAffiliateEntity) throws Exception {

        if (!createAnewAffiliateEntity.getAffiliateName().isEmpty())
            affiliatePage.affiliateNameTexBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(createAnewAffiliateEntity.getAffiliateName())));
        affiliatePage.activeCheckBox.check();
        if (!createAnewAffiliateEntity.getReceivablesName().isEmpty())
            affiliatePage.receivablesNameTextBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(createAnewAffiliateEntity.getReceivablesName())));
        if (!createAnewAffiliateEntity.getAdress1().isEmpty())
            affiliatePage.adress1TexeBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(createAnewAffiliateEntity.getAdress1())));
        if (!createAnewAffiliateEntity.getCity().isEmpty())
            affiliatePage.cityTextBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(createAnewAffiliateEntity.getCity())));
        if (!createAnewAffiliateEntity.getState().isEmpty())
            affiliatePage.stateDropdown.selectValue(this.replaceConfigurationValues(this.replaceConfigurationValues(createAnewAffiliateEntity.getState())));
        if (!createAnewAffiliateEntity.getPostalCode().isEmpty())
            affiliatePage.postalCodeTextBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(createAnewAffiliateEntity.getPostalCode())));
        if(!createAnewAffiliateEntity.getLeadFeeTier().isEmpty())
            affiliatePage.leadFeeTierDropdown.selectValue((this.replaceConfigurationValues(this.replaceConfigurationValues(createAnewAffiliateEntity.getLeadFeeTier()))));
    }
    @And("I enter the {string} to search affiliate name TextBox on affiliate page")
    public void iEnterTheToSearchAffiliateNameTextBoxOnAffiliatePage(String value) throws Exception {
        affiliatePage.searchAffiliateNameTextBox.setText(this.replaceConfigurationValues(value));
    }

    @Then("I verify {string} Display on affiliate page search result table")
    public void iVerifyDisplayOnAffiliatePageSearchResultTable(String expectedResult) throws Exception {
        Assertions.assertTrue(affiliatePage.searchResultTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(expectedResult)),
                "ERROR! the value : [" + this.replaceConfigurationValues(expectedResult) + "] is not displayed in the policy search result section");
    }
}
