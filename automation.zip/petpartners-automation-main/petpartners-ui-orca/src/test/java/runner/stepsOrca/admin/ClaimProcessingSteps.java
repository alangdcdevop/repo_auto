package runner.stepsOrca.admin;

import io.cucumber.java.en.And;
import org.junit.jupiter.api.Assertions;
import pages.orca.admin.claims.ProcedureCodePage;
import runner.stepsOrca.BaseSteps;

public class ClaimProcessingSteps extends BaseSteps {
    ProcedureCodePage procedureCodePage = new ProcedureCodePage();

    @And("click on Create New Procedure Code button available on Claims Processing page")
    public void clickonCreateNewProcedureCodebuttonavailableonClaimsProcessingpage() throws Exception {
        procedureCodePage.createNewProcedureCodeButton.click();
    }

    @And("click the row [{int}] Edit button in procedureCodeTable")
    public void clickTheRowButtonInEditColumnProcedureCodeTableEditSection(int positionRow) throws Exception {
        int positionColumn = procedureCodePage.procedureCodeTable.getPositionColumn("Actions");
        procedureCodePage.procedureCodeTable.clickButton(positionColumn, positionRow);
    }

    @And("I verify that the tab name is Version History on Procedure Detail Page")
    public void iVerifyThatTheTabNameIsVersionHistoryOnProcedureDetailPage(String expectedtabname) throws Exception {
        String actualtabname = procedureCodePage.statusHistoryLink.getText();
        expectedtabname = this.replaceConfigurationValues(expectedtabname);
        Assertions.assertTrue(actualtabname.contains(expectedtabname),
                "Wrong denial reason, actual: [" + actualtabname + "] vs expected: [" + expectedtabname + "]");
    }

}
