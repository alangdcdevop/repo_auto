package runner.stepsOrca.admin;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.orca.admin.documentManagement.DocumentLibraryAddFilePage;
import runner.stepsOrca.BaseSteps;

import java.util.Map;

public class DocumentLibraryCreateSteps extends BaseSteps {

    DocumentLibraryAddFilePage documentLibraryAddFilePage = new DocumentLibraryAddFilePage();

    @And("fill Document Information in Add File - Document Library page")
    public void fillDocumentInformationInAddFileDocumentLibraryPage(Map<String,String> data) throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(30);
    for (String control: data.keySet()) {
            documentLibraryAddFilePage.documentInformationSection.controlSelect.get(control).
                    selectValueContainsOption(this.replaceConfigurationValues(data.get(control)));
        }
    }
    @And("^click \\[Next\\] button in (Document Information|Upload File|Sample Data|Preview Document) - Document Library page$")
    public void clickNextButtonInDocumentInformationDocumentLibraryPage(String site) throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        documentLibraryAddFilePage.nextButton.click();
    }

    @And("^click \\[Submit\\] button in (Document Information|Upload File|Sample Data|Preview Document) - Document Library page$")
    public void clickSubmitButtonInPreviewDocumentDocumentLibraryPage(String site) throws Exception {
        loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
        documentLibraryAddFilePage.previewDocumentSection.submitButton.click();
    }

    @And("upload a document - Document Library page")
    public void uploadADocumentDocumentLibraryPage(String documentName) throws Exception {
        loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
        documentLibraryAddFilePage.uploadFileSection.dragFileHereOrBrowseTextArea.setText(this.replaceConfigurationValues(documentName));
    }

    @And("fill Sample Data in Add File - Document Library page")
    public void fillSampleDataInAddFileDocumentLibraryPage(Map<String,String>data) throws Exception {
        // need add logic to fill other section in Sample Data
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
        documentLibraryAddFilePage.sampleDataSection.marketChannelSelect.selectValueContainsOption(this.replaceConfigurationValues(data.get("Market Channel")));

    }

    @Then("verify the Upload Successful message is displayed - Document Library page")
    public void verifyTheUploadSuccessfulMessageIsDisplayedDocumentLibraryPage(String expectedResult) {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        boolean isDisplayed=documentLibraryAddFilePage.uploadSuccessfulDialog.checkAlertMessage(expectedResult);
        Assertions.assertTrue(isDisplayed,"ERROR> the message: "+expectedResult+" is not displayed, please review the data saved");
    }

    @And("click on [Return to Document Library] button in Successful message - Document Library page")
    public void clickOnReturnToDocumentLibraryButtonInSuccessfulMessageDocumentLibraryPage() throws Exception {
        documentLibraryAddFilePage.uploadSuccessfulDialog.returnToDocumentLibraryButton.click();
    }
}
