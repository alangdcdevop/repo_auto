package runner.stepsOrca.admin;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.admin.documentManagement.DocumentLibrarySearchPage;
import runner.stepsOrca.BaseSteps;

import java.util.Map;

public class DocumentLibrarySearchSteps extends BaseSteps {
    DocumentLibrarySearchPage documentLibrarySearchPage = new DocumentLibrarySearchPage();
    @Then("I search [{}] and verify search Results table on Document Library page")
    public void iSearchAndVerifySearchResultsTable(String sType, Map<String, String> entry) throws Exception {
        if (sType.equals("All")){
            documentLibrarySearchPage.searchOptions.get("Market Channel").selectValueContainsOption(replaceConfigurationValues(entry.get("Market Channel")));
            documentLibrarySearchPage.searchOptions.get("Document Version").selectValueContainsOption(replaceConfigurationValues(entry.get("Document Version")));
            documentLibrarySearchPage.searchOptions.get("Select State").selectValueContainsOption(replaceConfigurationValues(entry.get("Select State")));
            documentLibrarySearchPage.searchOptions.get("Document Type").selectValueContainsOption(replaceConfigurationValues(entry.get("Document Type")));
            documentLibrarySearchPage.searchOptions.get("Product").selectValueContainsOption(replaceConfigurationValues(entry.get("Product")));

            documentLibrarySearchPage.searchButton.click();
            Thread.sleep(2000);

            Assertions.assertTrue(documentLibrarySearchPage.searchResultsTable.checkIfValueIsDisplayedInTable(replaceConfigurationValues(entry.get("Market Channel"))),
                    "ERROR: " + replaceConfigurationValues(entry.get("Market Channel")) + " is not displayed");
            Assertions.assertTrue(documentLibrarySearchPage.searchResultsTable.checkIfValueIsDisplayedInTable(replaceConfigurationValues(entry.get("Document Version"))),
                    "ERROR: " + replaceConfigurationValues(entry.get("Document Version")) + " is not displayed");
            Assertions.assertTrue(documentLibrarySearchPage.searchResultsTable.checkIfValueIsDisplayedInTable(replaceConfigurationValues(entry.get("Select State"))),
                    "ERROR: " + replaceConfigurationValues(entry.get("Select State")) + " is not displayed");
            Assertions.assertTrue(documentLibrarySearchPage.searchResultsTable.checkIfValueIsDisplayedInTable(replaceConfigurationValues(entry.get("Document Type"))),
                    "ERROR: " + replaceConfigurationValues(entry.get("Document Type")) + " is not displayed");
            if (!replaceConfigurationValues(entry.get("Product")).contains("Any Product") )
                 Assertions.assertTrue(documentLibrarySearchPage.searchResultsTable.checkIfValueIsDisplayedInTable(replaceConfigurationValues(entry.get("Product"))),
                    "ERROR: " + replaceConfigurationValues(entry.get("Product")) + " is not displayed");
        }
        else{
            if (!documentLibrarySearchPage.searchOptions.containsKey(sType))
                throw new Exception("Error!! the option ["+sType+"] does not exist in the menu");
            documentLibrarySearchPage.searchOptions.get(sType).selectValueContainsOption(replaceConfigurationValues(entry.get("Value")));
            documentLibrarySearchPage.searchButton.click();
            Thread.sleep(2000);
            Assertions.assertTrue(documentLibrarySearchPage.searchResultsTable.checkIfValueIsDisplayedInTable(replaceConfigurationValues(entry.get("Value"))),
                    "ERROR: " + replaceConfigurationValues(entry.get("Value")) + " is not displayed");
        }
        documentLibrarySearchPage.clearButton.click();
    }

    @And("I click on [Upload Document] button on the Document Library page")
    public void iClickOnUploadDocumentButtonOnTheDocumentLibraryPage() throws Exception {
        loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        scrollUp();
        documentLibrarySearchPage.uploadDocumentButton.click();
    }

    @When("I Select [{}] on the Document information Table")
    public void iSelectOnTheDocumentInformationTable(String value,Map<String, String> entry) throws Exception {
        loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(50);
        if (documentLibrarySearchPage.documentInformation.containsKey(value)) {
            loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(3);
            documentLibrarySearchPage.documentInformation.get(value).controlIsClickable();
            documentLibrarySearchPage.documentInformation.get(value).selectValueContainsOption(this.replaceConfigurationValues(entry.get("Option")));
        }
        }
    @And("I click on [Next] button on the Document information table")
    public void iClickOnNextButtonOnTheDocumentInformationTable() throws Exception {
        documentLibrarySearchPage.nextButton.click();
    }
    @Then("I verify {string} is Displayed on the Document information table")
    public void iVerifyIsDisplayedOnTheDocumentInformationTable(String value) throws Exception {
        Assertions.assertTrue(documentLibrarySearchPage.summaryTable.getText().contains(value)
                ,"ERROR: " + value + " is not displayed");
    }

    @And("I Click On {string} on the document library page")
    public void iClickOnOnTheDocumentLibraryPage(String value) throws Exception {
        documentLibrarySearchPage.commonButton.get(this.replaceConfigurationValues(value)).click();
    }

    @Then("I verify {string} is empty on the document library page")
    public void iVerifyIsEmptyOnTheDocumentLibraryPage(String value) throws Exception {
        Assertions.assertTrue(documentLibrarySearchPage.documentInformation.get(value).controlIsSelectDropdownEmpty("id",value));
    }

    @Then("I enter Term Days as {string} Days on the Document information Table")
    public void iEnterTermDaysOnDocumentInfoTable(String value) throws Exception {
        documentLibrarySearchPage.termDays.setText(value.trim());
    }
}
