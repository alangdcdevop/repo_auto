package runner.stepsOrca.admin;

import configuration.CommonValues;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.admin.documentManagement.DocumentVersionDetailPage;
import pages.orca.admin.documentManagement.DocumentVersionView;
import runner.stepsOrca.BaseSteps;
import utils.Level;
import utils.Logger;
import java.util.Map;

public class DocumentVersionStep extends BaseSteps {

    DocumentVersionView documentVersionView = new DocumentVersionView();
    DocumentVersionDetailPage documentVersionDetailPage = new DocumentVersionDetailPage();

    @And("I create a new document version with display: {string}")
    public void iCreateANewDocumentVersionWithDisplay(String displayValue) throws Exception {
        loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        documentVersionView.createDocumentVersionButton.controlIsDisplayed();
        documentVersionView.createDocumentVersionButton.controlIsClickable();
        documentVersionView.createDocumentVersionButton.click();
        loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        documentVersionDetailPage.displayTextBox.controlIsDisplayed();
        documentVersionDetailPage.displayTextBox.setText(this.replaceConfigurationValues(displayValue));
        documentVersionDetailPage.activeCheckBox.check();
        documentVersionDetailPage.saveButton.click();
    }

    @And("^I get the (Document Version Id|Display|Created On|Modified On) value in '(.*)'$")
    public void iGetTheDocumentVersionIdValueIn(String controlName, String variableName) throws Exception {
        documentVersionDetailPage = new DocumentVersionDetailPage();
        String value = documentVersionDetailPage.textBoxMap.get(this.replaceConfigurationValues(controlName)).getTextAttribute("value");
        CommonValues.variables.put(variableName, value);
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variableName) + "] in [" + variableName + "]");
    }

    @And("I add a associations in the document version detail")
    public void iAddAAssociationsInTheDocumentVersionDetail(Map<String, String> controlValue) throws Exception {
        loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        documentVersionDetailPage.addAssociationsButton.controlIsDisplayed();
        documentVersionDetailPage.addAssociationsButton.controlIsClickable();
        documentVersionDetailPage.addAssociationsButton.click();
        loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        Thread.sleep(2000);
        documentVersionDetailPage.documentTypeTextBox.setTextAndEnter(this.replaceConfigurationValues(controlValue.get("Document Type")));
        documentVersionDetailPage.documentAreaTextBox.setTextAndEnter(this.replaceConfigurationValues(controlValue.get("Document Area")));
        documentVersionDetailPage.productTextBox.setTextAndEnter(this.replaceConfigurationValues(controlValue.get("Product")));
        documentVersionDetailPage.saveButton.click();
        documentVersionDetailPage.saveButton.controlIsNotDisplayed(5);
    }

    @Then("I verify the {string} is displayed in Document Version Table")
    public void iVerifyTheIsDisplayedInDocumentVersionTable(String expectedValue) throws Exception {
        Assertions.assertTrue(documentVersionView.documentVersionTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(expectedValue)),
                "ERROR! The value:[ " + expectedValue + "] is not displayed in the document version table");
    }

    @And("I click on edit icon in document version details page")
    public void iClickOnEditIconInDocumentVersionDetailsPage() throws Exception {
        documentVersionDetailPage.documentEditButton.click();
    }

    @And("I unselect active checkbox in document version details page")
    public void iUnselectActiveCheckboxInDocumentVersionDetailsPage() throws Exception {
        documentVersionDetailPage.activeCheckBox.uncheck();
    }

    @And("I click on  save button on document version detail Page")
    public void iClickOnSaveButtonOnDocumentVersionDetailPage() throws Exception {
        documentVersionDetailPage.saveButton.click();
    }

    @And("I select document version with display: {string}")
    public void iSelectDocumentVersionWithDisplay(String expectedValue) throws Exception {
        Assertions.assertTrue(documentVersionView.documentVersionTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(expectedValue)),
                "ERROR! The value:[ " + expectedValue + "] is not displayed in the document version table");

    }

    @And("I select on active checkbox in document version details page")
    public void iClickOnActiveCheckboxInDocumentVersionDetailsPage() throws Exception {
        documentVersionDetailPage.activeCheckBox.check();
    }

    @When("I click on edit icon in associations")
    public void iClickOnEditIconInAssociations() throws Exception {
        documentVersionDetailPage.associationsEditButton.click();
    }

    @And("I removed document area in associations")
    public void iRemovedDocumentAreaInAssociations() throws Exception {
        documentVersionDetailPage.documentAreaTextBox.click();
        loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        documentVersionDetailPage.removeDocAreaButton.controlIsDisplayed(10);
        documentVersionDetailPage.removeDocAreaButton.click();
    }

    @Then("I click save button in association")
    public void iClickSaveButtonInAssociation() throws Exception {
        documentVersionDetailPage.associationsSaveButton.click();
    }

    @Then("I verify the warning message {string}")
    public void iVerifyTheWarningMessage(String expectedValue) throws Exception {
        String actualwarning = documentVersionDetailPage.warningMessage.getText();
        expectedValue = this.replaceConfigurationValues(expectedValue);
        Assertions.assertTrue(actualwarning.contains(expectedValue), "Nowarning, actual: [" + actualwarning + "] vs expected: [" + expectedValue + "]");
    }
}