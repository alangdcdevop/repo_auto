package runner.stepsOrca.admin;

import io.cucumber.java.en.And;
import runner.stepsOrca.BaseSteps;
import pages.orca.admin.productManagement.FilingPage;

public class FilingsSteps extends BaseSteps {
    FilingPage filingPage = new FilingPage();
    @And("click Add New button on Filings page")
    public void clickAddNewButtonOnFilingsPage() throws Exception {
        filingPage.addNewButton.click();
    }

    @And("I click on :{int} column and {int} row in filling search table")
    public void iClickOnIntColumnAndIntRowInFillingSearchTable(int column,int row) throws Exception {
        this.filingPage.searchTable.clickLink(column,row);
    }
}