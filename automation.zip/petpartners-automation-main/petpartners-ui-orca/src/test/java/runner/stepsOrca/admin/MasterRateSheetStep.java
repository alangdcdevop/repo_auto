package runner.stepsOrca.admin;

import configuration.CommonValues;

import control.TextBox;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.json.JSONObject;
import org.junit.jupiter.api.Assertions;

import org.openqa.selenium.By;
import pages.orca.admin.masterRate.MasterRateSheetDetailPage;
import pages.orca.admin.masterRate.MasterRateSheetListView;
import pages.orca.admin.masterRate.RateSheetUploadPage;
import runner.stepsOrca.BaseSteps;

import utils.FileUtils;
import utils.Level;
import utils.Logger;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MasterRateSheetStep extends BaseSteps {


    MasterRateSheetListView masterRateSheetListView = new MasterRateSheetListView();
    MasterRateSheetDetailPage masterRateSheetDetailPage = new MasterRateSheetDetailPage();
    RateSheetUploadPage rateSheetUploadPage = new RateSheetUploadPage();

    @And("create Master Rate Sheet : {string} if it does not exist")
    public void createMasterRateSheetIfItDoesNotExist(String nameFile) throws Exception {
        String json = FileUtils.readFile(new File("").getAbsolutePath() + "/src/test/resources/" + nameFile);

        menuSection.optionMenu.get("Admin").click();
        subMenuSection.optionSubMenu.get("Master Rate Sheets").click();
        JSONObject masterRateGlobalJson = new JSONObject(json);

        if (!masterRateSheetListView.masterRateSheetTable.checkIfValueIsDisplayedInTable(masterRateGlobalJson.get("MasterRateSheetName").toString())) {

            masterRateSheetListView.addMasterRateSheetButton.click();
            masterRateSheetDetailPage.rateSheetTypeSelect.selectValue(masterRateGlobalJson.get("RateSheetType").toString());
            masterRateSheetDetailPage.masterRateSheetNameTxtBox.setText(masterRateGlobalJson.get("MasterRateSheetName").toString());
            masterRateSheetDetailPage.ratingFormulaSelect.selectValue(masterRateGlobalJson.get("RatingFormula").toString());
            masterRateSheetDetailPage.rateVersionTxtBox.setText(masterRateGlobalJson.get("RateVersion").toString());
            masterRateSheetDetailPage.activeCheckBox.check();

            JSONObject jsonCheckBoxes = new JSONObject(masterRateGlobalJson.get("FactorSelected").toString());

            for (String checkboxName : jsonCheckBoxes.keySet()) {
                masterRateSheetDetailPage.factorSelectedCheckboxes.get(checkboxName).actionCheckBox(jsonCheckBoxes.get(checkboxName).toString());
            }
            Thread.sleep(2000);
            masterRateSheetDetailPage.saveButton.click();

            // upload files
            JSONObject fileNameFactor = new JSONObject(masterRateGlobalJson.get("FileNameFactor").toString());
            String projectPath = new File("").getAbsolutePath() + "/src/test/resources/requirement/masterRate/";
            for (String fileName : fileNameFactor.keySet()) {
                if (!fileNameFactor.get(fileName).toString().isEmpty()) {
                    masterRateSheetDetailPage.uploadRateSheetsButton.controlIsDisplayed(5);
                    masterRateSheetDetailPage.uploadRateSheetsButton.click();
                    Logger.log(Level.INFO, this.getClass().getName() + "> file to upload: [" + projectPath + fileNameFactor.get(fileName).toString() + "]");
                    rateSheetUploadPage.uploadDeductibleLimitRateFactor("Upload " + fileName, projectPath + fileNameFactor.get(fileName).toString());
                }
            }
            Thread.sleep(2000);
            subMenuSection.optionSubMenu.get("Master Rate Sheets").click();
        }

        Assertions.assertTrue(masterRateSheetListView.masterRateSheetTable.checkIfValueIsDisplayedInTable(masterRateGlobalJson.get("MasterRateSheetName").toString()),
                "ERROR > The Global Master Rate Sheet with name: [" + masterRateGlobalJson.get("MasterRateSheetName").toString() + "] is not created, please review the Master Rate Sheet Table");
    }

    @And("save the attribute value : {string} in {string} from file {string}")
    public void saveTheAttributeValueInFromFile(String attribute, String variableName, String fileName) {
        String json = FileUtils.readFile(new File("").getAbsolutePath() + "/src/test/resources/" + fileName);
        JSONObject masterRateGlobalJson = new JSONObject(json);
        CommonValues.variables.put(variableName, masterRateGlobalJson.get(attribute).toString());
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variableName) + "] in [" + variableName + "]");
    }

    @And("click on {string} in Master Rate Sheet Table")
    public void clickOnMasterRateSheetNameInMasterRateSheetTable(String masterRateSheetName) throws Exception {
        masterRateSheetName = this.replaceConfigurationValues(masterRateSheetName);
        masterRateSheetListView.masterRateSheetTable.clickOnLinkCellContains(masterRateSheetName);
    }

    @And("click [Edit] button on Master Rate Sheet Detail Page")
    public void clickEditButtonOnMasterRateSheetDetailPage() throws Exception {
        masterRateSheetDetailPage.editButton.controlIsDisplayed();
        masterRateSheetDetailPage.editButton.click();
    }

    @And("update the next checkboxes on Factor Selected Section - Master Rate Sheet")
    public void updateTheNextCheckboxesOnFactorSelectedSectionMasterRateSheet(Map<String, String> controlCheckBoxStatus) throws Exception {
        for (String controlName : controlCheckBoxStatus.keySet()) {
            masterRateSheetDetailPage.factorSelectedCheckboxes.get(controlName).actionCheckBox(controlCheckBoxStatus.get(controlName));
        }
    }

    @And("click [Save] button on Master Rate Sheet Detail Page")
    public void clickSaveButtonOnMasterRateSheetDetailPage() throws Exception {
        masterRateSheetDetailPage.saveButton.controlIsDisplayed();
        masterRateSheetDetailPage.saveButton.click();
    }

    @And("^the next sections (should not be|should be) displayed in Factor Selected Table$")
    public void theNextSectionsShouldNotBeDisplayedInFactorSelectedTable(String condition, List<String> controlNameTab) {
        List<String> controlsFailed = new ArrayList<>();
        for (String control : controlNameTab) {
            if (condition.contains("not")) {
                // if section is displayed when it should not be displayed, it is added in the List
                if (masterRateSheetDetailPage.uploadRateSheetsSectionTable.checkIfTabSectionIsDisplayedInFactorSelectedTable(control))
                    controlsFailed.add(control);
            } else {
                // if section is not displayed when it should be displayed, it is added in the List
                if (!masterRateSheetDetailPage.uploadRateSheetsSectionTable.checkIfTabSectionIsDisplayedInFactorSelectedTable(control))
                    controlsFailed.add(control);
            }
        }
        Assertions.assertTrue(controlsFailed.isEmpty(), "ERROR> the next section in Factor Selected Table " + condition + " : [ " + controlsFailed + " ]");
    }

    /*
    * tabName sections: Age, Breed, Zip Code, Per Incident Limit, others
    * */
    @When("I click on [{}] tab in Upload Rate Sheets - Section")
    public void iClickOnAgeTabInUploadRateSheetsSection(String tabName) throws Exception {
        Thread.sleep(2000);
        masterRateSheetDetailPage.uploadRateSheetsSectionTable.clickTabSectionFactorSelectedTable(this.replaceConfigurationValues(tabName));
        Thread.sleep(2000);
    }

    @Then("I click on [Edit] icon button in Upload Rate Sheets - Table")
    public void iClickOnEditIconButtonInUploadRateSheetsTable() throws Exception {
        masterRateSheetDetailPage.uploadRateSheetsSectionTable.editButton.controlIsDisplayed(5);
        masterRateSheetDetailPage.uploadRateSheetsSectionTable.editButton.click();
        masterRateSheetDetailPage.uploadRateSheetsSectionTable.editButton.controlIsNotDisplayed(5);
    }

    @And("verify if the next columns are editable - Upload Rate Sheets Table - [{}] Section")
    public void verifyIfTheNextColumnsAreEditableUploadRateSheetsTableAgeSection(String section,Map<String,String>columnNameStatus) throws Exception {
        for (String columnName:columnNameStatus.keySet()) {
            int position = masterRateSheetDetailPage.uploadRateSheetsSectionTable.detailTable.getPositionColumn(columnName);
            // if cell is editable, it does not contain the "@disabled" --> not (@disabled)
            String condition = columnNameStatus.get(columnName).contains("not editable")?"@disabled":"not (@disabled)";
            String locatorCell = masterRateSheetDetailPage.uploadRateSheetsSectionTable.detailTable.getLocatorXpathString()+"/tbody/tr/td["+position+"]/input["+condition+"]";
            TextBox cell = new TextBox(By.xpath(locatorCell));
            Assertions.assertTrue(cell.controlIsDisplayed(),"ERROR> the column: ["+columnName+"] should be: ["+ columnNameStatus.get(columnName)+"]");
        }
    }

    @And("^(check|uncheck) the row \\[(\\d+)\\] checkbox in Active column - Upload Rate Sheets Table - \\[(.*)\\] Section$")
    public void checkTheRowCheckboxInActiveColumnUploadRateSheetsTableAgeSection(String action,int positionRow,String section) throws Exception {
        int positionColumn = masterRateSheetDetailPage.uploadRateSheetsSectionTable.detailTable.getPositionColumn("Active");
        masterRateSheetDetailPage.uploadRateSheetsSectionTable.detailTable.actionCheckBoxCell(positionColumn,positionRow,action);
    }

    @And("click [Save] button in Upload Rate Sheets - Table")
    public void clickSaveButtonInUploadRateSheetsTable() throws Exception {
        masterRateSheetDetailPage.uploadRateSheetsSectionTable.saveButton.click();
        masterRateSheetDetailPage.uploadRateSheetsSectionTable.saveButton.controlIsNotDisplayed(3);
        loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
    }

    @And("verify the row [{int}] checkbox in Active column should be displayed {string} value")
    public void verifyTheFirstCheckboxInActiveColumnShouldBeDisplayedValue(int positionRow,String expectedValue) throws Exception {
        int positionColumn = masterRateSheetDetailPage.uploadRateSheetsSectionTable.detailTable.getPositionColumn("Active");
        String actualResult = masterRateSheetDetailPage.uploadRateSheetsSectionTable.detailTable.getValueCell(positionColumn,positionRow);
        Assertions.assertEquals(this.replaceConfigurationValues(expectedValue),actualResult,"ERROR > the expected: ["+this.replaceConfigurationValues(expectedValue)+"] vs actual value: ["+actualResult+"]");
    }
}
