package runner.stepsOrca.admin;

import entities.orca.admin.ProductManagementEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.admin.productManagement.ProductManagementPage;
import pages.orca.admin.productManagement.ProductPackageDetailPage;
import pages.orca.admin.productManagement.ProductPackagesPage;
import runner.stepsOrca.BaseSteps;


import java.util.List;
import java.util.Map;

public class ProductPackagesSteps extends BaseSteps {
    ProductPackagesPage productPackagesPage = new ProductPackagesPage();
    ProductPackageDetailPage productPackageDetailPage = new ProductPackageDetailPage();
    ProductManagementPage productManagementPage = new ProductManagementPage();

    @And("I click {string} Button on product packages page")
    public void iClickButtonOnProductPackagesPage(String value) throws Exception {
        if (value.contains("Create a Product Package")) {
            productPackagesPage.createProductPackageButton.controlIsDisplayed(5);
            productPackagesPage.createProductPackageButton.click();
        }
    }

    @Then("I verify created product package name in table")
    public void iVerifyCreatedProductPackageNameinTable(List<String> expectedProductDetails) throws Exception {
        for (String sElement : expectedProductDetails) {
            Assertions.assertTrue(productPackagesPage.productPackagesTable.checkIfValueIsDisplayedInTable(sElement),
                    "ERROR: " + sElement + " is not displayed");
        }
    }

    @When("I click on the product packages link in left menu")
    public void iClickOnTheLinkOnProductPackagesPage() throws Exception {
        productPackagesPage.productPackagesLeftLink.click();
    }

    @Then("I click on product package name link and verify display in product package details page")
    public void iClickOnProductPackageNameLinkAndVerifyDisplayInProductPackageDetailsPage(Map<String, String> controlsValue) throws Exception {
        Assertions.assertTrue(productPackagesPage.productPackagesTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(controlsValue.get("DisplayValue"))),
                "ERROR: " + this.replaceConfigurationValues(controlsValue.get("DisplayValue")) + " link is not displayed");

        this.scrollDown();
        productPackagesPage.productPackagesTable.clickOnLinkCellContains(this.replaceConfigurationValues(controlsValue.get("DisplayValue")));

        Assertions.assertEquals(productPackageDetailPage.displayTextBox.getTextAttribute("value"), this.replaceConfigurationValues(controlsValue.get("DisplayValue")), "ERROR: MarketChannelOverviewPage Display text box value matched");
    }

    @And("click on the {string} on Product Management page")
    public void clickOnTheOnProductManagementPage(String value) throws Exception {
        productManagementPage.productManagement.get(value).click();
    }

    @And("I fill out the application on the Product Management page")
    public void iFillOutTheApplicationOnTheProductManagementPage(ProductManagementEntity productManagementEntity) throws Exception {
        if (!productManagementEntity.getProductTypeDropDown().isEmpty())
            productManagementPage.productTypeDropDown.selectValueContainsOption(this.replaceConfigurationValues(productManagementEntity.getProductTypeDropDown()));
        if (!productManagementEntity.getCodeTextBox().isEmpty())
            productManagementPage.codeTextBox.clearSetText(this.replaceConfigurationValues(productManagementEntity.getCodeTextBox()));
        if (!productManagementEntity.getDisplayTextBox().isEmpty())
            productManagementPage.displayTextBox.clearSetText(this.replaceConfigurationValues(productManagementEntity.getDisplayTextBox()));
    }

    @DataTableType
    public ProductManagementEntity getEntity(Map<String, String> entity) {

        ProductManagementEntity tt = new ProductManagementEntity();
        if (entity.containsKey("Product Type"))
            tt.setProductTypeDropDown(entity.get("Product Type"));
        if (entity.containsKey("Code"))
            tt.setCodeTextBox(entity.get("Code"));
        if (entity.containsKey("Display"))
            tt.setDisplayTextBox(entity.get("Display"));
        return tt;
    }

    @Then("I verify {string} Display  on product List")
    public void iVerifyDisplayOnProductList(String value) throws Exception {
        Assertions.assertTrue(productManagementPage.productListTable.getText().contains(this.replaceConfigurationValues(value)));
    }

    @And("I click on link cell row: {int} column {int} in product List Table")
    public void iClickOnLinkCellRowColumnInProductListTable(int row, int column) throws Exception {
        productManagementPage.productListTable.clickLink(row, column);
    }

    @Then("I enter Allowance {string} in available input filed Quantity")
    public void iEnterAllowanceInAvailableInputFiledQuantity(String quantity) throws Exception {
        productManagementPage.quantityTextBox.click();
        productManagementPage.quantityTextBox.setText(this.replaceConfigurationValues(quantity));
    }

    @And("I select CompanionPlus Display available on product List")
    public void iSelectCompanionPlusDisplayAvailableOnProductList() throws Exception {
        productManagementPage.productLink.click();
    }

    @And("I click on edit icon in product details page")
    public void iClickOnEditIconInProductDetailsPage() throws Exception {
        productManagementPage.packagedetailEditButton.click();
    }

}







