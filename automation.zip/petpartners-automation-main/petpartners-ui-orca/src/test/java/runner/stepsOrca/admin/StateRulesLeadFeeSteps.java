package runner.stepsOrca.admin;

import control.Checkbox;
import entities.orca.admin.StateFilingInformationEntity;
import entities.orca.admin.StateRulesEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import pages.orca.admin.productManagement.AddNewFilingPage;
import pages.orca.admin.productManagement.FilingPage;
import runner.stepsOrca.BaseSteps;
import java.util.List;
import java.util.Map;

public class StateRulesLeadFeeSteps extends BaseSteps {
    FilingPage filingPage = new FilingPage();
    AddNewFilingPage addNewFilingPage = new AddNewFilingPage();

    @Then("I click on {string} Button on Filings page")
    public void iClickOnButtonOnFillingsPage(String arg0) throws Exception {
        loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        filingPage.addNewButton.click();
    }


    @And("I fill out the State Filing Information")
    public void iFillOutTheStateFilingInformation(StateFilingInformationEntity stateFilingInformationEntity) throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
        addNewFilingPage.stateFilingInformationSection.fillstateFilingInformation(stateFilingInformationEntity);
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
    }

    @DataTableType
    public StateFilingInformationEntity stateFillingInformationEntity(Map<String, String> entity) {
        StateFilingInformationEntity stateFillingInformationEntity = new StateFilingInformationEntity();
        stateFillingInformationEntity.setSate(this.replaceConfigurationValues(entity.get("State")))
                .setMarketChannel(this.replaceConfigurationValues(entity.get("MarketChannel")))
                .setUnderwriter(this.replaceConfigurationValues(entity.get("Underwriter")))
                .setTargetversion(this.replaceConfigurationValues(entity.get("Targetversion")));
        return stateFillingInformationEntity;
    }

    @And("I click on {string} on effectiveOnDate in State Filling Wizard")
    public void iClickOnDate(String dayvalue) throws Exception {
        addNewFilingPage.stateFilingInformationSection.effectiveonDatePickerGrid.clickDayButton(dayvalue);
    }

    @Then("I click on Next Button On State Filling Wizard to go to next step")
    public void iClickOnNext() throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
        addNewFilingPage.nextButton.click();
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
    }

    @And("I click on Lead Fee Cap checkbox under Sate Rules")
    public void iClickOnLeadFeeCapCheckboxUnderSateRules() throws Exception {
        addNewFilingPage.stateRulesSection.leadFeeCapCheckBox.check();
    }

    @Then("I capture the warning message- This field is required, to verify the Functionality")
    public void iCaptureTheWarningMessageThisFieldIsRequiredToVerifyTheFunctionality(String expectedwarning) throws Exception {
        String actualwarning = filingPage.fieldrequiredLabel.getText();
        expectedwarning = this.replaceConfigurationValues(expectedwarning);
        Assertions.assertTrue(actualwarning.contains(expectedwarning), "Nowarning, actual: [" + actualwarning + "] vs expected: [" + expectedwarning + "]");
    }

    @Then("I fill required Lead Fee")
    public void iFillRequiredLeadFee(List<String> leadFee) throws Exception {
        for (String value : leadFee) {
            addNewFilingPage.stateRulesSection.leadFeeCapCheckBox.check();
            addNewFilingPage.stateRulesSection.leedFeeCapTextBox.setText(this.replaceConfigurationValues(value));
        }
    }

    @Then("below fields should be empty under State Rules")
    public void belowFieldsShouldBeEmptyUnderStateRules(List<String> fieldName) throws Exception {
        for (String sFieldName : fieldName) {
            Assertions.assertTrue(addNewFilingPage.stateRulesSection.textBoxControlMap.get(sFieldName).getText().isEmpty(), "Error: " + sFieldName + " is not empty");
        }
    }

    @Then("{string} label should be displayed")
    public void labelShouldDisplayed(String label) throws Exception {
        addNewFilingPage.chooseProductSection.chooseProductLabel.waitUntilControlIsDisplayed();
        Assertions.assertTrue(addNewFilingPage.chooseProductSection.chooseProductLabel.controlIsDisplayed(), "Error: " + addNewFilingPage.chooseProductSection.chooseProductLabel.getText() + " is not displayed");
    }

    @And("I click on Enable Application Requirements checkbox under Sate Rules")
    public void iClickOnEnableApplicationRequirementsCheckboxUnderSateRules() throws Exception {
        addNewFilingPage.chooseProductSection.enableApplicationRequirements.check();

    }

    @And("I fill out the State Filing Information on the State Rules section")
    public void iFillOutTheStateFilingInformationOnTheStateRulesSection(StateRulesEntity stateRulesEntity) throws Exception {
        addNewFilingPage.stateRulesSection.fillStateFilingInformationStateRulessection(stateRulesEntity);
    }

    @DataTableType
    public StateRulesEntity stateRulesEntity(Map<String, String> entity) {
        StateRulesEntity stateFillingInformationSateRulesEntity = new StateRulesEntity();
        if (entity.containsKey("Cancel Override"))
            stateFillingInformationSateRulesEntity.setCancelOverride(this.replaceConfigurationValues(entity.get("Cancel Override")));
        if (entity.containsKey("Lead Fee Cap"))
            stateFillingInformationSateRulesEntity.setLeadFeeCap(this.replaceConfigurationValues(entity.get("Lead Fee Cap")));
        if (entity.containsKey("Service Fee"))
            stateFillingInformationSateRulesEntity.setServiceFee(this.replaceConfigurationValues(entity.get("Service Fee")));
        if (entity.containsKey("Allow Electronic Delivery"))
            stateFillingInformationSateRulesEntity.setAllowElectricDeliveryDropDown(this.replaceConfigurationValues(entity.get("Allow Electronic Delivery")));
        return stateFillingInformationSateRulesEntity;
    }

    @And("select the {string} option on Select Product Package on Policy Choose Product section")
    public void selectTheOptionOnSelectProductPackageOnPolicyChooseProductSection(String pack) throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(10);
        addNewFilingPage.chooseProductSection.selectProductPackageSelect.selectValueWithJavaScriptOptionSpan(this.replaceConfigurationValues(pack));
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(10);
    }

    @And("^I update the \\[(CompanionCare|NewProPackNGJY )\\] checkboxes in Choose Section Modal$")
    public void iupdateTheCheckboxesInChooseProductSection(String checkboxesType, Map<String, String> checkBoxesNames) throws Exception {
        Map<String, Checkbox> checkboxMap = checkboxesType.contains("CompanionCare") ?
                addNewFilingPage.chooseProductSection.companionCareCheckBoxesMap :
                addNewFilingPage.chooseProductSection.newProPackNGJYCheckBoxesMap;
        for (String checkBoxName : checkBoxesNames.keySet()) {
            if (!checkboxMap.containsKey(checkBoxName))
                throw new Exception("ERROR: the checkbox: [" + checkBoxName + "] does not exist in Choose product section, please review it");
            checkboxMap.get(checkBoxName).actionCheckBox(checkBoxesNames.get(checkBoxName));
            scrollDown();
        }
    }

    @Then("verify check boxes is checked by default")
    public void checkBoxesIsCheckedByDefault(List<String> cboxlist) throws Throwable {
        for (String sFieldName : cboxlist) {
            Assertions.assertTrue(addNewFilingPage.chooseProductSection.verifyIsCheckboxChecked(sFieldName), "Error: " + sFieldName + " is not checked");
        }
    }

    @And("I click on the search button")
    public void andIClickOnThefilingsSearchButton() throws Exception {
        loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        this.filingPage.searchButton.click();
    }

    @Then("I validate filings table is displayed")
    public void thenIvalidateFilingsTableIsDisplayed() throws Exception {
        Assertions.assertTrue(filingPage.rowsInFilingTable.controlIsDisplayed(5));
    }

    @And("I unselect ExamPlus active checkbox in Add New Filling Page")
    public void iUnselectExamPlusActiveCheckboxInAddNewFillingPage() throws Exception {

    }

    @Then("verify {string} displayed")
    public void applicationAcknowledgement30Day(String message) throws Exception {
        String applicationacknowledgement30day = this.filingPage.applicationAcknowledgement30Day.getText();
        Assert.assertEquals(applicationacknowledgement30day, " " + message + " ");
    }

    @When("I click on benefit schedules page action button")
    public void clickActionsButton()throws Exception {
        filingPage.actionButton.click();
    }

    @Then("Verify {string} displayed under Benefit Groups")
    public void verifyProceduredisplayedunderBenefitGroups(String message) throws Exception {
      String procedureText =  this.filingPage.procedureTextBox.getText();
      System.out.println(procedureText);
    Assert.assertEquals(procedureText, ""+message+"");
    }
}


