package runner.stepsOrca.breeder;

import configuration.CommonValues;
import entities.orca.breeder.BreederDetailsOverviewEntity;
import entities.orca.breeder.BreederSearchEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.breeder.BreederDetails;
import pages.orca.breeder.BreederSearchSection;
import pages.orca.breeder.YourBreederPortal;
import runner.stepsOrca.BaseSteps;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class BreederSteps extends BaseSteps {
    BreederSearchSection breederSearch = new BreederSearchSection();
    BreederDetails breederDetails = new BreederDetails();
    YourBreederPortal yourBreederPortal = new YourBreederPortal();

    public BreederSteps() {
    }

    @And("I search Breeder with the next value")
    public void iSearchBreederWithTheNextValue(BreederSearchEntity breederSearchEntity) throws Exception {
        if (breederSearchEntity.getEmailAddress() == null) {
            if (!breederSearchEntity.getLastName().isEmpty()) {
                this.breederSearch.bsLastNameTextBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(breederSearchEntity.getLastName())));
            }
        } else if (!breederSearchEntity.getEmailAddress().isEmpty()) {
            this.breederSearch.bsEmailAddressTextBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(breederSearchEntity.getEmailAddress())));
        }
    }

    @DataTableType
    public BreederSearchEntity breederSearchEntity(Map<String, String> entity) {
        BreederSearchEntity breederSearchEnt = new BreederSearchEntity();
        if (entity.containsKey("Last Name")) {
            breederSearchEnt.setLastName(entity.get("Last Name"));
        }
        if (entity.containsKey("Email")) {
            breederSearchEnt.setEmailAddress(entity.get("Email"));
        }
        return breederSearchEnt;
    }

    @When("I get {} from common variables and search breeder")
    public void getCommonVariableValueAndSearchBreeder(String keyName) throws Exception {
        if (CommonValues.variables.containsKey(keyName)) {
            this.breederSearch.bsLastNameTextBox.setText(CommonValues.variables.get(keyName));
        }
    }

    @When("I get {} from common variables and search email")
    public void getCommonVariableValueAndSearchEmail(String keyName) throws Exception {
        if (CommonValues.variables.containsKey(keyName)) {
            this.breederSearch.bsEmailAddressTextBox.setText(CommonValues.variables.get(keyName));
        }
    }

    @Then("the Breeder Details form with labels should be displayed")
    public void theBreederDetailsFormWithLabelsShouldBeDisplayed(List<String> labels) throws Exception {
        List<String> isNotDisplayedList = new ArrayList();
        Iterator lebalsValue = labels.iterator();
        while (lebalsValue.hasNext()) {
            String label = (String) lebalsValue.next();
            if (!this.breederDetails.labelMap.containsKey(label)) {
                throw new Exception("ERROR> Please add the label [" + label + "] in the mapping page");
            }
            if (this.breederDetails.labelMap.containsKey(label) && !this.breederDetails.labelMap.get(label).controlIsDisplayed()) {
                isNotDisplayedList.add(label);
            }
        }
        Assertions.assertEquals(0, isNotDisplayedList.size(), "ERROR> Some labels are not displayed on breeder Details: \n " + isNotDisplayedList);
    }

    @And("I click [Run Search] button on Breeder Search")
    public void iClickRunSearchButtonOnBreederSearch() throws Exception {
        this.breederSearch.breederRunSearchButton.click();
    }

    @Then("verify the Last value {string} is displayed in the result search")
    public void verifyTheValueLastNameIsDisplayedInTheResultSearch(String expectedResult) throws Exception {
        boolean breeder = this.breederSearch.searchResultsTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(expectedResult));
        String breederLastName = this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(breeder, "ERROR! the value : [" + breederLastName + "] is not displayed in the search result section");
    }

    @And("I click on link cell column:{int} row:{int}  in result table")
    public void iClickOnLinkCellRowColumnInResultTable(int column, int row) throws Exception {
        this.breederSearch.searchResultsTable.clickLink(column, row);
    }

    @And("I click [Impersonate] button on Breeder Search")
    public void iClickImpersonateButtonOnBreederSearch() throws Exception {
        this.breederDetails.impersonateButton.click();
    }

    @And("I click on Get Forms column:{int} row:{int}  in desired litter table")
    public void iClickOnGetFormsColumnRowInResultTable(int column, int row) throws Exception {
        this.yourBreederPortal.coverageGetFormsTable.clickLink(column, row);
    }

    @Then("I click on Download link")
    public void iClickOnDownloadLink() throws Exception {
        this.yourBreederPortal.downloadLink.click();
    }

    @And("I click on [Print Form] button")
    public void iClickOnPrintFormButton() throws Exception {
        this.yourBreederPortal.printFormButton.click();
    }

    @And("filling details in the breeder details overview page")
    public void fillingDetailsInTheBrrederDetailsOverviewPage(BreederDetailsOverviewEntity breederDetailsOverviewEntity) throws Exception {
        this.breederDetails.fillBreederDetailsOverviewPage(breederDetailsOverviewEntity);
    }

    @DataTableType
    public BreederDetailsOverviewEntity breederDetailsOverviewEntity(Map<String, String> entity) {
        BreederDetailsOverviewEntity breederOverview = new BreederDetailsOverviewEntity();
        breederOverview.setBdFirstName(this.replaceConfigurationValues(entity.get("First Name"))).setBdLastName(this.replaceConfigurationValues(entity.get("Last Name"))).setBdEmail(this.replaceConfigurationValues(entity.get("Email"))).setBdPhoneNo(this.replaceConfigurationValues(entity.get("Phone No"))).setBdAddress1(this.replaceConfigurationValues(entity.get("Address 1"))).setBdAddress2(this.replaceConfigurationValues(entity.get("Address 2"))).setBdCity(this.replaceConfigurationValues(entity.get("City"))).setBdState(this.replaceConfigurationValues(entity.get("State/Province"))).setBdPostalCode(this.replaceConfigurationValues(entity.get("Postal Code")));
        return breederOverview;
    }

    @And("I click [Save] button on breeder details page")
    public void iClickSaveButtonOnBreederDetailsPage() throws Exception {
        this.breederDetails.bdSaveButton.click();
    }

    @And("I verify the email on breeder details page")
    public void iVerifyTheEmailOnBreederDetailsPage(Map<String, String> expectedResult) {
        boolean email = this.breederDetails.getEmailTextBox(this.replaceConfigurationValues(expectedResult.get("Email"))).controlIsDisplayed();
        String emailValue = this.replaceConfigurationValues(expectedResult.get("Email"));
        Assertions.assertTrue(email, "ERROR the Email value is wrong, it is not displaying:" + emailValue);
    }
}
