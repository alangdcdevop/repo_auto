package runner.stepsOrca.breeder;
import entities.orca.breeder.LitterDetailsOverviewEntity;
import entities.orca.breeder.LitterSearchEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.orca.breeder.LitterDetailsSection;
import pages.orca.breeder.LitterSearchSection;
import runner.stepsOrca.BaseSteps;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class LitterSteps extends BaseSteps {
    LitterSearchSection litterSearchSection = new LitterSearchSection();
    LitterDetailsSection litterDetailsSection = new LitterDetailsSection();

    public LitterSteps() {
    }

    @And("I search Litter Details with the next value")
    public void iSearchLitterDetailsWithTheNextValue(LitterSearchEntity litterSearchEntity) throws Exception {
        if (!litterSearchEntity.getLitterRegistrationNo().isEmpty()) {
            this.litterSearchSection.lsLitterRegistrationNoTextBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(litterSearchEntity.getLitterRegistrationNo())));
        }
    }

    @DataTableType
    public LitterSearchEntity litterSearchEntity(Map<String, String> entity) {
        LitterSearchEntity litterSearchEnt = new LitterSearchEntity();
        if (entity.containsKey("Litter Registration No")) {
            litterSearchEnt.setLitterRegistrationNo(entity.get("Litter Registration No"));
        }
        return litterSearchEnt;
    }

    @And("I click on the [Litter Details] tab")
    public void iClickOnTheLitterDetailsTab() throws Exception {
        this.litterSearchSection.litterDetailsLabel.click();
    }

    @And("I click [Run Search] button for Litter")
    public void iClickRunSearchButtonForLitter() throws Exception {
        this.litterSearchSection.litterRunSearchButton.click();
    }

    @And("I click [Link Reg No] link Button")
    public void iClickLinkRegNoLinkButton() throws Exception {
        this.litterSearchSection.litterRegNoLink.click();
    }

    @Then("the Litter Details form with labels should be displayed")
    public void theLitterDetailsFormWithLabelsShouldBeDisplayed(List<String> labels) throws Exception {
        List<String> isNotDisplayedList = new ArrayList();
        Iterator lebelsIterator = labels.iterator();

        while (lebelsIterator.hasNext()) {
            String label = (String) lebelsIterator.next();
            if (!this.litterDetailsSection.labelMap.containsKey(label)) {
                throw new Exception("ERROR> Please add the label [" + label + "] in the mapping page");
            }
            if (this.litterDetailsSection.labelMap.containsKey(label) && !this.litterDetailsSection.labelMap.get(label).controlIsDisplayed()) {
                isNotDisplayedList.add(label);
            }
        }
        Assertions.assertEquals(0, isNotDisplayedList.size(), "ERROR> Some labels are not displayed on Policy Details: \n " + isNotDisplayedList);
    }

    @And("I click on [Change Breeder] button")
    public void iClickOnChangeBreederButton() throws Exception {
        this.litterSearchSection.litterChangeBreederButton.click();
    }

    @And("I click [Run Search] button on Search details")
    public void iClickRunSearchButtonOnSearchDetails() throws Exception {
        this.litterSearchSection.bsRunSearchButton.click();
    }

    @And("I click on the [Add Litter] button")
    public void iClickOnTheAddLitterButton() throws Exception {
        this.litterSearchSection.litterAddLitterButton.click();
    }

    @And("filling details in the litter details overview page")
    public void fillingDetailsInTheLitterDetailsOverviewPage(LitterDetailsOverviewEntity litterDetailsOverviewEntity) throws Exception {
        this.litterDetailsSection.fillLitterDetailsOverviewPage(litterDetailsOverviewEntity);
    }

    @DataTableType
    public LitterDetailsOverviewEntity litterDetailsOverviewEntity(Map<String, String> entity) throws InterruptedException {
        LitterDetailsOverviewEntity litterValue = new LitterDetailsOverviewEntity();
        litterValue.setLdMarketChannel(this.replaceConfigurationValues(entity.get("Market Channel"))).setLdRegistrationNumber(this.replaceConfigurationValues(entity.get("Registration Number"))).setLdRegistrationDate(this.replaceConfigurationValues(entity.get("Registration Date"))).setLdDateOfBirth(this.replaceConfigurationValues(entity.get("Date of Birth"))).setLdBreed(this.replaceConfigurationValues(entity.get("Breed"))).setLdMaleCount(this.replaceConfigurationValues(entity.get("Male Count"))).setLdFemaleCount(this.replaceConfigurationValues(entity.get("Female Count")));
        return litterValue;
    }

    @And("I click [Save] button on Litter details page")
    public void iClickSaveButtonOnLitterDetailsPage() throws Exception {
        this.litterDetailsSection.ldSaveButton.click();
    }

    @Then("verify the successfully alert is displayed on Litter")
    public void verifyTheSuccessfullyAlertIsDisplayedOnLitter(String expectedResult) throws Exception {
        String actualResult = this.alertSection.successfullyAlertLabel.getText();
        expectedResult = this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult), "ERROR the message is not successfully, actual: [" + actualResult + "] vs expected: [" + expectedResult + "]");
    }

    @Then("I verify {string} tab display on the litter details page")
    public void iVerifyTabDisplayOnTheLitterDetailsPage(String expectedResults) throws Exception {
        Assertions.assertTrue(litterDetailsSection.coOwnerLabel.getText().contains(expectedResults),
                "ERROR the message is not successfully, actual: [" + litterDetailsSection.coOwnerLabel.getText() + "] vs expected: [" + expectedResults + "]");

    }
}

