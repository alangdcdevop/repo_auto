package runner.stepsOrca.claim;

import configuration.CommonValues;
import entities.orca.MedicalRecordEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.JavascriptExecutor;
import pages.orca.claim.*;
import pages.orca.common.MenuSection;
import pages.orca.loss.LossDetails;
import runner.stepsOrca.BaseSteps;
import session.Session;
import utils.Level;
import utils.Logger;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ClaimSteps extends BaseSteps {
    ClaimDashboard claimDashboard = new ClaimDashboard();
    ClaimDetails claimDetails = new ClaimDetails();
    ClaimSearch claimSearch = new ClaimSearch();
    MenuSection menuSection = new MenuSection();
    LossDetails lossDetails = new LossDetails();
    ClaimAdjusterProfile claimAdjusterProfile = new ClaimAdjusterProfile();
    RequestMedicalRecord requestMedicalRecord = new RequestMedicalRecord();


    @And("I click [{}] button")
    public void iClickStartPreppingClaimButton(String buttonName) throws Exception {
        if (!claimDashboard.buttonMap.containsKey(buttonName))
            throw new Exception("Error!! the button [" + buttonName + "] does not exist");
        claimDashboard.buttonMap.get(buttonName).click();
    }

    @And("I click on [{}] Link on Claim Dashboard")
    public void iClickOnAssignedLinkOnClaimDashboard(String linkControl) throws Exception {
        int count = 0;
        while (!claimDashboard.linksMap.get(linkControl).controlIsDisplayed(10) && count <= 3) {
            count++;
            this.scrollDown();
            Thread.sleep(1000);
        }
        claimDashboard.linksMap.get((linkControl)).click();
    }

    @And("The Assigned table should be displayed with the columns")
    public void theAssignedTableShouldBeDisplayedWithTheColumns(List<String> expectedLabelsTable) throws Exception {
        Assertions.assertTrue(claimDashboard.assignedTable.verifyAllHeaderLabel(expectedLabelsTable),
                "Some labels in the table is missing, actual [" + claimDashboard.assignedTable.getAllHeaderLabel().toString() + " vs expected [" + expectedLabelsTable.toString() + "]");
    }

    @And("click on ClaimNumber : {int}")
    public void clickOnClaimNumber(int row) {
        // todo method to click on specific value in table
    }

    @Then("the Claim Detail page should be displayed")
    public void theClaimDetailPageShouldBeDisplayed() {
        Assertions.assertTrue(Session.getInstance().getDriver().getCurrentUrl().contains("ClaimDetail"),
                "The current page is not claim detail, actual: " + Session.getInstance().getDriver().getCurrentUrl());
    }

    @And("click on [{}] tab in the bottom menu")
    public void clickOnAttachmentSTabInTheBottomMenu(String menuTabOption) throws Exception {
        Thread.sleep(2000);
        claimDetails.controlLinks.get(menuTabOption).click();
    }

    @And("click on the [Claims] link")
    public void clickOnTheClaimsLink() throws Exception {
        claimDetails.claimsResultLink.click();
    }

    @Then("verify the invoice.pdf link is not empty")
    public void verifyTheInvoicePdfLinkIsNotEmpty() throws Exception {
        Assertions.assertFalse(claimDetails.getLinkForClaimPDF().isEmpty(), "ERROR, the link for the PDF is empty");
    }

    @And("click on [{}] button on the claim detail page")
    public void clickOnSubmitToProcessingButtonOnTheClaimDetailPage(String buttonName) throws Exception {
        claimDetails.controlButtonClaimsDetail.get(buttonName).click();
    }

    @Then("verify the successfully alert is displayed")
    public void verifyTheSuccessfullyAlertIsDisplayed(String expectedResult) throws Exception {
        String actualResult = alertSection.successfullyAlertLabel.getText();
        expectedResult = this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),
                "ERROR the message is not successfully, actual: [" + actualResult + "] vs expected: [" + expectedResult + "]");
    }

    @And("click on [Add Loss\\(es)] button in processing tab")
    public void clickOnAddLossEsButtonInProcessingTab() throws Exception {
        claimDetails.addLossesButton.click();
    }


    @And("i add {int} days from today in the variable {} with format {}")
    public void iCreateANewDate(int days, String variable, String format) {
        Date dt = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(dt);
        c.add(Calendar.DATE, days);
        CommonValues.variables.put(variable, new SimpleDateFormat(format).format(c.getTime()));
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variable) + "] in [" + variable + "]");
    }

    @And("click on [Send to Investigator] button in claims details")
    public void clickOnSendToInvestigatorButton() throws Exception {
        claimDetails.sendToInvestigatorButton.click();
    }

    @And("click in the first claim number in the assigned table")
    public void clickInTheFirstClaimNumberInTheAssignedTable() throws Exception {
        claimDashboard.assignedTable.clickLinkXpath(1, 1);
    }

    @And("I get the claim number displayed in the alert in {}")
    public void iGetTheClaimNumberDisplayedInTheAlertInClaimNumber(String variableName) throws Exception {
        String actualResult = alertSection.successfullyAlertLabel.getText();
        Pattern pattern = Pattern.compile("Successfully assigned claim (.*) to (.*)");
        Matcher matcher = pattern.matcher(actualResult);
        if (matcher.find()) {
            CommonValues.variables.put(variableName, matcher.group(1));
            Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variableName) + "] in [" + variableName + "]");
        } else {
            throw new Exception("The claim number is not displayed, actual: " + actualResult);
        }
    }

    @And("verify the {} is displayed in Assigned table")
    public void verifyTheClaimNumberIsDisplayedInAssignedTable(String nameVariable) throws Exception {
        //auto scroll
        boolean isDisplayed = claimDashboard.assignedTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(nameVariable));
        Assertions.assertTrue(isDisplayed, "ERROR! The value [" + this.replaceConfigurationValues(nameVariable) + "] is not displayed in the Assigned table");
    }

    @And("I select {string} in the Page Size Table")
    public void iSelectAllRowsInThePageSizeTable(String value) throws Exception {
        if (claimDetails.controlSelect.get("Page Size Table").controlIsDisplayed())
            claimDetails.controlSelect.get("Page Size Table").selectValue(value);
        claimDetails = new ClaimDetails();
    }

    @And("click in the {} in the assigned table")
    public void clickInTheClaimNumberInTheAssignedTable(String nameVariable) throws Exception {
        claimDashboard.assignedTable.clickOnLinkCell(this.replaceConfigurationValues(nameVariable));
    }


    @And("click on Policy Number in claims details")
    public void clickOnPolicyNumberInClaimsDetails() throws Exception {
        claimDetails.policyNumber.click();
    }

    @And("I get the Policy Number displayed in claims details in {}")
    public void iGetThePolicyNumberDisplayedInClaimsDetailsInPolicyNumber(String variable) throws Exception {
        CommonValues.variables.put(variable, claimDetails.policyNumber.getText());
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variable) + "] in [" + variable + "]");
    }

    @And("click on view button for petname: {string} in the losses table")
    public void clickOnViewButtonForPetnameInTheLossesTable(String petnameValue) throws Exception {
        claimDetails.clickOnViewDeleteCellForPet(this.replaceConfigurationValues(petnameValue), false);
    }

    @And("fill the adjuster note using the value {string}")
    public void fillTheAdjusterNoteUsingTheValue(String value) throws Exception {
        Session.getInstance().getDriver().switchTo().frame("adjuster-note_ifr");
        claimDetails.adjusterNoteTextBoxFrame.setText(this.replaceConfigurationValues(value));
        Thread.sleep(10000);
        Session.getInstance().getDriver().switchTo().defaultContent();
    }

    @Then("the href attribute for [{}] should be")
    public void theHrefAttributeForPreviewEOBShouldBe(String buttonName, String expectedResult) throws Exception {
        String actualResult = claimDetails.controlButtonClaimsDetail.get(buttonName).getTextAttribute("href");
        Assertions.assertTrue(this.replaceConfigurationValues(actualResult).contains(this.replaceConfigurationValues(expectedResult)), "ERROR comparing the links: actualResult: " + this.replaceConfigurationValues(actualResult) + " VS expectedResult: " + this.replaceConfigurationValues(expectedResult));
    }

    @And("create a claim with random values on Claim Detail page")
    public void createAClaimWithRandomValuesOnClaimDetailPage() throws Exception {
        claimDetails.controlSelect.get("Assistant").firstValue();
        claimDetails.controlSelect.get("Adjuster").firstValue();
        claimDetails.controlSelect.get("Priority").firstValue();
        claimDetails.controlSelect.get("Auditor").firstValue();
        claimDetails.controlButtonClaimsDetail.get("Save").click();
        Thread.sleep(3000);
        claimDetails.controlButtonClaimsDetail.get("Return to Policy").click();
    }

    @And("create a claim with with today date, submit processing")
    public void createAClaimWithWithTodayDateSubmitProcessing() throws Exception {
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();

        claimDetails.controlSelect.get("Assistant").firstValue();
        claimDetails.controlSelect.get("Adjuster").firstValue();
        claimDetails.controlSelect.get("Priority").firstValue();
        claimDetails.controlSelect.get("Auditor").firstValue();
        claimDetails.receivedOnTextBox.click();
        claimDetails.receivedOnTextBox.setText(new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
        js.executeScript("window.scrollBy(0,500)");
        claimDetails.controlButtonClaimsDetail.get("Save").click();
        js.executeScript("window.scrollBy(0,300)");
        claimDetails.controlButtonClaimsDetail.get("Submit to Processing").click();
        Thread.sleep(3000);
    }

    @And("verify the {} ComboBox is {} in claim detail")
    public void verifyTheAssistantComboBoxIsNotEmpty(String nameControl, String expected) throws Exception {
        String currentValue = claimDetails.controlSelect.get(nameControl).getTextOptionSelected();
        expected = this.replaceConfigurationValues(expected);
        Assertions.assertTrue(currentValue.contains(expected), "the value is not correct in user assigned\n current: " + currentValue + " vs expected:" + expected);
    }

    @And("verify the Status value is {} in claim detail")
    public void verifyTheStatusValueIsAssigned(String expectedReuslt) throws Exception {
        String actualValue = claimDetails.statusLabel.getText();
        expectedReuslt = this.replaceConfigurationValues(expectedReuslt);
        Assertions.assertTrue(actualValue.contains(expectedReuslt), "ERROR the status is not correct, actual: " + actualValue + "vs expected:" + expectedReuslt);
    }

    @And("verify the Underwriter has the value")
    public void verifyTheUnderwriterHasTheValue(String expectedValue) throws Exception {
        String actualValue = claimDetails.underwriterLabel.getText();
        expectedValue = this.replaceConfigurationValues(expectedValue);
        Assertions.assertTrue(actualValue.contains(expectedValue), "ERROR the Underwriter is not correct, actual: " + actualValue + "vs expected: " + expectedValue);
    }

    @And("get the {} ComboBox value on {} in claim detail")
    public void getTheAssistantComboBoxValueOnUserInClaimDetail(String nameControl, String variable) throws Exception {
        String value = claimDetails.controlSelect.get(nameControl).getTextOptionSelected();
        CommonValues.variables.put(variable, value);
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variable) + "] in [" + variable + "]");
    }

    @And("I select the {} in the {} ComboBox on Claim Detail")
    public void iSelectTheLoggerUserInTheAuditorComboBoxOnClaimDetail(String option, String control) throws Exception {
        claimDetails.controlSelect.get(control).selectContainsValueUsingXpath(this.replaceConfigurationValues(option));
    }

    @When("I search the claim: {}")
    public void iSearchTheClaimClaimNumber(String claimNumber) throws Exception {
        menuSection.optionMenu.get("Claims").click();
        subMenuSection.optionSubMenu.get("Search for a Claim").click();
        claimSearch.claimNoTxtBox.clearSetText(this.replaceConfigurationValues(claimNumber));
        claimSearch.runSearchButton.click();

    }

    @And("I click on Claim No: {} link")
    public void iClickOnClaimNoClaimNumberLink(String claimNumber) throws Exception {
        claimSearch.clickClaimResult(this.replaceConfigurationValues(claimNumber));
    }


    @And("click on [Return to Claim]")
    public void clickOnReturnToClaim() throws Exception {

        claimDetails.returnToClaimButton.click();
    }

    @And("I click on a link view claim details")
    public void iClickOnALinkViewClaimDetails() throws Exception {
        claimDetails.viewClaimDetailsLink.click();
        Thread.sleep(1000);
    }

    @And("click on Finalize All Loss\\(es) button")
    public void clickOnFinalizeAllLossEsButton() throws Exception {
        Thread.sleep(1000);

        claimDetails.finalizeAllLossesButton.click();
    }

    @And("I click on {string} tab under attachment")
    public void iClickOnTabUnderAttachment(String value) throws Exception {
        claimDetails.otherLink.click();
    }

    @Then("I verify Finance and Cancellation document is not empty")
    public void iVerifyFinanceAndCancellationDocumentIsNotEmpty() throws Exception {
        Assertions.assertFalse(claimDetails.getLinkForCancellationPDF().isEmpty(), "ERROR, the link for the PDF is empty");
    }

    @And("I click on [CheckMark] on the approve Section")
    public void iClickOnCheckMarkOnTheApproveSection() throws Exception {
        this.scrollDown();
        lossDetails.checkMarkButton.click();
    }

    @When("I click on [{}] button on the Deny section")
    public void iClickOnButtonOnTheDenySection(String buttonName) throws Exception {
        lossDetails.denySection.get(buttonName).click();
    }

    @And("I enter {string} to denial code text box and select {string}")
    public void iEnterToDenialCodeTextBoxAndSelect(String code, String option) throws Exception {
        lossDetails.denialCodeTextBox.selectTextOption(code, option);
    }

    @And("I click on [{}] button under the claim dashboard")
    public void iClickOnButtonUnderTheClaimDashboard(String button) throws Exception {
        claimDashboard.dashBoardMap.get(button).click();
    }

    @And("I click on link cell column:{int} row:{int}  in Adjuster Table")
    public void iClickOnLinkCellColumnIntRowIntInAdjusterTable(int row, int column) throws Exception {
        claimAdjusterProfile.adjusterTable.clickLink(row, column);
    }

    @When("I select [{}] amount claim Total Submitted level dropdown")
    public void iSelectAmountClaimTotalSubmittedLevelDropdown(String value) throws Exception {
        claimAdjusterProfile.totalSubmittedLevel.selectValueContainsOption(value);
    }
    @And("I click on [{}] Button on the Adjuster Profile Page")
    public void iClickOnButtonOnTheAdjusterProfilePage(String button) throws Exception {
        if (button.contains("Save")){
            claimAdjusterProfile.saveButton.controlIsDisplayed(5);
            claimAdjusterProfile.saveButton.click();
        } else if (button.contains("Cancel")) {
            claimAdjusterProfile.cancelButton.controlIsDisplayed(5);
            claimAdjusterProfile.cancelButton.click();

        }
    }

    @And("I click {string} button on medical Record Page")
    public void iClickButtonOnMedicalRecordPage(String value) throws Exception {
        requestMedicalRecord.medicalRecordPageButton.get(value).controlIsClickable();
        requestMedicalRecord.medicalRecordPageButton.get(value).controlIsDisplayed(5);
        requestMedicalRecord.medicalRecordPageButton.get(value).click();
    }
    @DataTableType
    public MedicalRecordEntity getEntity(Map<String, String> entity) {
        MedicalRecordEntity tmpp = new MedicalRecordEntity();
        if (entity.containsKey("Request Type"))
            tmpp.setRequestTypeDropdown(entity.get("Request Type"));
        if (entity.containsKey("Pet"))
            tmpp.setPet(entity.get("Pet"));
        if (entity.containsKey("Vet"))
            tmpp.setVet(entity.get("Vet"));
        if (entity.containsKey("Request Search"))
            tmpp.setRequestSearch(entity.get("Request Search"));
        return tmpp;
    }
    @When("I fill out the application medical Record Page")
    public void iFillOutTheApplicationMedicalRecordPage(MedicalRecordEntity medicalRecordEntity) throws Exception {

        if (!medicalRecordEntity.getRequestTypeDropdown().isEmpty())
            requestMedicalRecord.requestTypeDropdown.selectValueContainsOption(this.replaceConfigurationValues(medicalRecordEntity.getRequestTypeDropdown()));
        if (!medicalRecordEntity.getPet().isEmpty())
            requestMedicalRecord.petDropdown.firstValue();
        if (!medicalRecordEntity.getVet().isEmpty())
            requestMedicalRecord.vetDropdown.firstValue();
        if (!medicalRecordEntity.getRequestSearch().isEmpty())
            requestMedicalRecord.requestSearch.setText(this.replaceConfigurationValues(medicalRecordEntity.getRequestSearch()));
        requestMedicalRecord.allMrsButton.click();
    }

    @When("I click on [Reset] icon on the medical records page")
    public void iClickOnResetIconOnTheMedicalRecordsPage() throws Exception {
        requestMedicalRecord.resetButton.controlIsDisplayed(5);
        requestMedicalRecord.resetButton.click();
    }

    @And("I click on [Regenerate docs] button on claim detail page")
    public void iClickOnRegenerateDocsButtonOnClaimDetailPage() throws Exception {
        claimDetails.regenerateDocs.click();
    }

    @And("Choose {string} on Regenerate Documents By Claim Id section")
    public void chooseOnRegenerateDocumentsByClaimIdSection(String option) throws Exception {
        option =  this.replaceConfigurationValues(option);
        claimDetails.regenerateComboBox.controlIsDisplayed(15);
        claimDetails.regenerateComboBox.selectValueContainsOption(option);
        claimDetails.regenerateButton.click();
    }

    @And("verify {string} document are displayed {int} times")
    public void verifyDocumentAreDisplayedTimes(String value, int repeatExpected) {
     int actualResult = claimDetails.getNumberOfElementsOnAttachmentTable(this.replaceConfigurationValues(value));
     Assertions.assertEquals(repeatExpected,actualResult,"ERROR!! the value: "+this.replaceConfigurationValues(value)+" is displayed ["+actualResult+"] instead of ["+repeatExpected+"]");
    }
}