package runner.stepsOrca.common;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.orca.common.FooterSection;
import runner.stepsOrca.BaseSteps;
import utils.Level;
import utils.Logger;

import java.util.Map;

public class FooterStep extends BaseSteps {
    FooterSection footerSection = new FooterSection();
    @Then("I verify the labels are displayed in Footer Section")
    public void iVerifyTheLabelsAreDisplayedInFooterSection(Map<String,String> dataExpected) throws Exception {
        for (String control: dataExpected.keySet()) {
            if (footerSection.labelMap.containsKey(control)) {
                String actualResult=footerSection.labelMap.get(control).getText();
                String expectedResult=this.replaceConfigurationValues(dataExpected.get(control));
                Logger.log(Level.INFO,this.getClass().getName()+"actual: ["+actualResult+"] vs expected: ["+expectedResult+"]");
                if (control.contains("Logged")){
                    Assertions.assertEquals(expectedResult,actualResult, "ERROR! the actual: [" + actualResult + "] are no equal expected: [" + expectedResult + "]");
                }else {
                    Assertions.assertTrue(actualResult.contains(expectedResult), "ERROR! the actual: [" + actualResult + "] does not contains expected: [" + expectedResult + "]");
                }
            }else {
                throw new Exception("ERROR! the control: [" + control + "] does not exist");
            }
        }
    }

    @And("verify the Log Out button is displayed in Footer Section")
    public void verifyTheLogOutButtonIsDisplayedInFooterSection() {
        Assertions.assertTrue(footerSection.logoutButton.controlIsDisplayed(),"ERROR! the LogOut button is not displayed on Footer Section");
    }

    @And("click {string} button in Footer Section")
    public void clickButtonInFooterSection(String logout) throws Exception {
        footerSection.logoutButton.click();
    }

    @And("^verify the color for \"(qa|staging|dev|.*)\" in (.*) - Footer Section$")
    public void verifyTheColorForInFooterSection(String environment,String section) throws Exception {
        Thread.sleep(2000);
        environment= this.replaceConfigurationValues(environment);
        String actualColor=footerSection.getFooterColorFont(section);
        String expectedColor="";
        switch (environment.toLowerCase()){
            case "qa":
                expectedColor="#556b2f";
                break;
            case "staging":
                expectedColor="#f9b559";
                break;
            case "dev":
                expectedColor="#515352";
                break;
            default:
                throw new Exception("ERROR> the environment does not exist!, please review it: "+environment);
        }
        Assertions.assertEquals(expectedColor,actualColor,"ERROR> the backgroud in "+environment+" expected is not the correct: expected: "+expectedColor+" vs actual: "+actualColor);
    }
}
