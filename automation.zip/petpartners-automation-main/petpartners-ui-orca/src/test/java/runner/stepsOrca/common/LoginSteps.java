package runner.stepsOrca.common;

import configuration.CommonValues;
import configuration.Configuration;
import helper.LoginHelper;
import helpers.GetProperties;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import pages.orca.login.ForgotPasswordPage;
import pages.orca.login.LoginPage;
import pages.orca.login.RegisterAccountPage;
import runner.stepsOrca.BaseSteps;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.Date;
import java.util.Map;

public class LoginSteps extends BaseSteps {
    LoginPage loginPage = new LoginPage();
    RegisterAccountPage registerAccountPage = new RegisterAccountPage();
    ForgotPasswordPage forgotPasswordPage = new ForgotPasswordPage();

    @When("I set the credentials")
    public void iSetTheCredentials(Map<String,String> controls) throws Exception {
        loginPage.loginSubStep(replaceConfigurationValues(controls.get("email")),
                               replaceConfigurationValues(controls.get("password")));
    }

    @Given("I go to Orca PetPartners")
    public void iGoToOrcaPetPartners() {
       Session.getInstance().getDriver().get(Configuration.WEB_URL);
    }

    @Then("^I should (be|not be) logged$")
    public void iShouldBeLogged(String condition) throws Exception {
        if (condition.contains("not be"))
            Assertions.assertTrue(loginPage.loginButton.controlIsDisplayed(),"ERROR! the user can do login with invalid credentials");
        else
            Assertions.assertTrue(footerSection.loggedInAsLabel.controlIsDisplayed(),"ERROR! the user can not loggin correctly");
    }

    @Given("I am logged in Orca PetPartners")
    public void iAmLoggedInOrcaPetPartners() throws Exception {
        if (GetProperties.getInstance().isEnabledOrcaMfa()){
            // adding cookie to skip MFA
            String cookie = new LoginHelper().buildCookieInfoUser(GetProperties.getInstance().getApiHost(), GetProperties.getInstance().getUser(),GetProperties.getInstance().getPassword());
            Session.getInstance().getDriver().manage().addCookie(new Cookie("userInfo",cookie));
            Session.getInstance().getDriver().navigate().refresh();
            Thread.sleep(2000);
        }else{
            // classic login
            loginPage.loginSubStep(Configuration.USER,Configuration.PASSWORD);
        }
    }

    @And("^I am logged in Orca PetPartners as (ADMIN|CLAIM SPECIALIST|CLAIM AUDIT)$")
    public void iAmLoggedInOrcaPetPartnersAsGivenRole(String sRole) throws Exception {
        String user;
        String pwd;
        switch (sRole){
            case "CLAIM SPECIALIST":
                user= GetProperties.getInstance().getClaimUser();
                pwd= GetProperties.getInstance().getClaimPassword();
                break;
            case "CLAIM AUDIT":
                user= GetProperties.getInstance().getClaimAuditUser();
                pwd= GetProperties.getInstance().getClaimAuditPassword();
                break;
            default:
                // admin is default
                user= GetProperties.getInstance().getUser();
                pwd= GetProperties.getInstance().getPassword();
                break;
        }
        //loginPage.loginSubStep(user,pwd);

        if (GetProperties.getInstance().isEnabledOrcaMfa()){
            // adding cookie to skip MFA
            String cookie = new LoginHelper().buildCookieInfoUser(GetProperties.getInstance().getApiHost(),user,pwd);
            Session.getInstance().getDriver().manage().addCookie(new Cookie("userInfo",cookie));
            Session.getInstance().getDriver().navigate().refresh();
            Thread.sleep(3000);
        }else{
            // classic login
            loginPage.loginSubStep(Configuration.USER,Configuration.PASSWORD);
        }
    }


    @And("I scroll down")
    public void iScrollDown() throws Exception{
        JavascriptExecutor js = (JavascriptExecutor)Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,500)");

        }

    @And("click on [{}] link in the login page")
    public void clickOnRegisterAccountLinkInTheLoginPage(String linkName) throws Exception {
        loginPage.registerAccountLink.click();
    }

    @And("i get a random value in {}")
    public void iGetARandomValueInEmailRandom(String variableName) {
        CommonValues.variables.put(variableName,String.valueOf(new Date().getTime()));
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variableName)+"] in ["+variableName+"]");
    }

    @When("i create a new account in the register page")
    public void iCreateANewAccountInTheRegisterPage(Map<String,String> values) throws Exception {
        registerAccountPage.registerNewAccount(this.replaceConfigurationValues(values.get("Email")),
                this.replaceConfigurationValues(values.get("Password")),
                this.replaceConfigurationValues(values.get("Confirm Password")));
    }

    @Then("the alert displayed should be")
    public void theAlertDisplayedShouldBe(String expectedResult) throws Exception{
        String actualResult= loginPage.messageLabel.getText();
        Assertions.assertTrue(actualResult.contains(this.replaceConfigurationValues(expectedResult)),"ERROR! the account was not registered");
    }

    @And("the message error alert should be displayed")
    public void theMessageErrorAlertShouldBeDisplayed(String expectedResult) throws Exception {
        String actualResult=loginPage.messageErrorLabel.getText();
        Assertions.assertTrue(actualResult.contains(this.replaceConfigurationValues(expectedResult)),"ERROR the values are diffentes actual: ["+actualResult+ "] VS expected: ["+expectedResult+"]");
    }

    @When("I click on {string} link")
    public void iClickOnLink(String forgotPassword) throws Exception {
        loginPage.forgotPasswordLink.click();
    }

    @And("I type the {string} in the [Email] textbox in ForgotPassword page")
    public void iTypeTheInTheEmailTextboxInForgotPasswordPage(String emailValue) throws Exception {
        forgotPasswordPage.emailTextBox.setText(this.replaceConfigurationValues(emailValue));
    }

    @And("I click on Submit button in ForgotPassword page")
    public void iClickOnSubmitButtonInForgotPasswordPage() throws Exception {
        forgotPasswordPage.submitButton.controlIsDisplayed(10);
        forgotPasswordPage.submitButton.click();
    }

    @Given("open the OrcaGroup web page")
    public void openTheOrcaGroupWebPage() {
        Session.getInstance().getDriver().get(Configuration.WEB_UI_ORCA_GROUP);
    }


    @And("verify the controls are displayed in Login Page")
    public void verifyTheControlsAreDisplayedInLoginPage(Map<String,String> dataExpected) throws Exception {
        for (String control:dataExpected.keySet()) {
            if ( loginPage.controlsLoginPageMap.containsKey(control)){
                Assertions.assertTrue(loginPage.controlsLoginPageMap.get(control).controlIsDisplayed(),"ERROR! the control ["+control+"] is not displayed in Login Page");
            }else{
                throw new Exception("ERROR the control: ["+control+"] does not exist in login page, please review the control name");
            }

        }

    }

    @Then("verify {string} button is not displayed")
    public void verifyButtonIsNotDisplayed(String logout) {
        Assertions.assertFalse(footerSection.logoutButton.controlIsDisplayed(5));
    }
}