package runner.stepsOrca.customer;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.customer.CustomerDetailsPage;
import runner.stepsOrca.BaseSteps;

public class CustomerDetailsSteps extends BaseSteps {
    CustomerDetailsPage customerDetailsPage = new CustomerDetailsPage();

    @And("modify customer firstname on customer details page")
    public void modifyCustomerFirstnameOnCustomerDetailsPage() throws Exception {
        customerDetailsPage.firstNameTextBox.setText("Test");
    }

    @And("click on [save] button on customer details Page")
    public void clickOnSaveButtonOnCustomerDetailsPage() throws Exception {
        customerDetailsPage.saveButton.click();
    }

    @When("click on [Note\\(s)] tab on customer detail page")
    public void clickOnNoteSTabOnCustomerDetailPage() throws Exception {
        customerDetailsPage.notesLink.click();
    }

    @Then("verify modified Customer Name {string} in customer detail page")
    public void verifyModifiedCustomerNameInCustomerDetailPage(String expectedResult) throws Exception {
        String sText =  "FirstName: changed from " + this.replaceConfigurationValues(expectedResult) + " to " +
                this.replaceConfigurationValues(expectedResult) + "Test";
        Assertions.assertTrue(customerDetailsPage.notesTab.getText().contains(sText),"ERROR!  the value: ["+this.replaceConfigurationValues(sText)+"] is not displayed in Notes tab");
    }
}
