package runner.stepsOrca.finance;

import io.cucumber.java.en.And;
import pages.orca.finance.FinanceDashboardPage;
import runner.stepsOrca.BaseSteps;


public class FinanceStep extends BaseSteps {
    FinanceDashboardPage financeDashboardPage = new FinanceDashboardPage();
    @And("I click on [{}] submenu in Finance Dashboard")
    public void iClickOnPoliciesPendingActionSubmenuInFinanceDashboard(String submenuOption) throws Exception {
        if (!financeDashboardPage.linkMap.containsKey(submenuOption))
            throw new Exception("ERROR> the submenu: ["+submenuOption+"] does not exist, please review it");
        financeDashboardPage.linkMap.get(this.replaceConfigurationValues(submenuOption)).click();
    }

    @And("I select the {string} in the result table in Finance Dashboard")
    public void iSelectTheInTheResultTableInFinanceDashboard(String valueInTable) throws Exception {
        financeDashboardPage.resultFinanceTable.clickOnLinkCellContains(this.replaceConfigurationValues(valueInTable));
    }
}
