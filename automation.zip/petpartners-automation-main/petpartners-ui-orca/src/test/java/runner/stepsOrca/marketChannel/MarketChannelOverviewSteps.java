package runner.stepsOrca.marketChannel;

import control.Button;
import entities.orca.marketChannel.MarketChannelOverviewEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import pages.orca.marketChannel.MarketChannelOverviewPage;
import pages.orca.marketChannel.MarketChannelPage;
import pages.orca.marketChannel.MarketChannelProductPackagePage;
import runner.stepsOrca.BaseSteps;

import java.util.Map;

public class MarketChannelOverviewSteps extends BaseSteps {
    MarketChannelOverviewPage marketChannelOverviewPage = new MarketChannelOverviewPage();
    MarketChannelPage marketChannelPage = new MarketChannelPage();

    MarketChannelProductPackagePage marketChannelProductPackagePage = new MarketChannelProductPackagePage();

    @And("filling details in the market channel overview page")
    public void fillingDetailsInTheMarketChannelOverviewPage(MarketChannelOverviewEntity mktChnlOverviewEntity) throws Exception {
        this.marketChannelOverviewPage.fillMarketChannelOverviewDetails(mktChnlOverviewEntity);
    }

    @DataTableType
    public MarketChannelOverviewEntity mktChnlOverviewEntity(Map<String, String> entry) {
        MarketChannelOverviewEntity entity = new MarketChannelOverviewEntity();
        entity.setMktChnlName(replaceConfigurationValues(entry.get("MarketChannelName")))
                .setMktChnlCode(this.replaceConfigurationValues(entry.get("Code")))
                .setMktChnlDisplay(this.replaceConfigurationValues(entry.get("Display")))
                .setMktChnlAdd1(this.replaceConfigurationValues(entry.get("Address1")))
                .setMktChnlAdd2(this.replaceConfigurationValues(entry.get("Address2")))
                .setMktChnlCity(this.replaceConfigurationValues(entry.get("City")))
                .setMktChnlState(this.replaceConfigurationValues(entry.get("State")))
                .setMktChnlPostal(this.replaceConfigurationValues(entry.get("PostalCode")))
                .setMktChnlPhone(this.replaceConfigurationValues(entry.get("PhoneNumber")))
                .setMktChnlFax(this.replaceConfigurationValues(entry.get("FaxNumber")))
                .setMktChnlEmailFromName(this.replaceConfigurationValues(entry.get("EmailFromName")))
                .setMktChnlEmailFromAdd(this.replaceConfigurationValues(entry.get("EmailFromAddress")))
                .setMktChnlClaimEmailFromAdd(this.replaceConfigurationValues(entry.get("ClaimEmailFromAddress")))
                .setMktChnlWebsite(this.replaceConfigurationValues(entry.get("Website")));

        if (entry.containsKey("Group Phone Number"))
            entity.setGroupPhoneNumber(this.replaceConfigurationValues(entry.get("Group Phone Number")));

        if (entry.containsKey("Group Email From Address"))
            entity.setGroupEmailFromAddress(this.replaceConfigurationValues(entry.get("Group Email From Address")));

        if (entry.containsKey("Group Claim Email From Address"))
            entity.setGroupClaimEmailFromAddress(this.replaceConfigurationValues(entry.get("Group Claim Email From Address")));

        if (entry.containsKey("Group Website"))
            entity.setGroupWebsite(this.replaceConfigurationValues(entry.get("Group Website")));

        return entity;
    }

    @And("I click on save button in market channel overview page")
    public void iClickOnSaveButtonInMarketChannelOverviewPage() throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
        this.marketChannelOverviewPage.mcSaveButton.click();
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
    }

    @Then("verify the details in market channel detail page")
    public void verifyTheDetailsInMarketChannelDetailPage() throws Exception {
        Assertions.assertTrue(marketChannelOverviewPage.mcIDTextBox.getTextAttribute("value").length() > 0,
                "ERROR: MarketChannel ID text box is blank");

        Assertions.assertTrue(marketChannelOverviewPage.mcCreatedOnTextBox.getTextAttribute("value").length() > 0,
                "ERROR: MarketChannel CreatedOn text box is blank");
    }

    @And("I click on edit icon in market channel overview page")
    public void iClickOnEditIconInMarketChannelOverviewPage() throws Exception {
        marketChannelOverviewPage.mcEditButton.click();
    }

    @And("I modify market channel details")
    public void iModifyMarketChannelDetails(Map<String, String> controlsValue) throws Exception {
        marketChannelOverviewPage.mcNameTextBox.clearSetText(this.replaceConfigurationValues(controlsValue.get("MarketChannelName")));
        marketChannelOverviewPage.mclDisplayTextBox.clearSetText(this.replaceConfigurationValues(controlsValue.get("Display")));
    }

    @And("I click on active checkbox")
    public void iClickOnActiveCheckbox() throws Exception {
        marketChannelOverviewPage.mcActiveCheckbox.uncheck();
    }

    @When("I click on Audit History tab in the bottom pane")
    public void iClickOnAuditHistoryTabInTheBottomPane() throws Exception {
        marketChannelOverviewPage.auditHistoryLink.click();
    }

    @Then("I verify {} market channel details in audit history tab")
    public void iVerifyCreateMarketChannelDetailsInAuditHistoryTab(String sType, Map<String, String> controlsValue) throws Exception {
        Assertions.assertTrue(marketChannelOverviewPage.auditHistoryTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(controlsValue.get("MarketChannelName"))),
                "ERROR: " + this.replaceConfigurationValues(controlsValue.get("MarketChannelName")) + " is not displayed");
        if (sType.equals("EDIT"))
            Assertions.assertTrue(marketChannelOverviewPage.auditHistoryTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(controlsValue.get("Display"))),
                    "ERROR: " + this.replaceConfigurationValues(controlsValue.get("Display")) + " is not displayed");
    }

    @And("I click {string} Market Channel in Market Channel Page")
    public void iClickMarketChannelInMarketChannelPage(String value) throws Exception {
        marketChannelPage.marketChannelNameLinkMap.get(value).click();
        Button loaderButton = new Button(By.xpath("//img[@src=\"/app/assets/loader.svg\"]"));
        loaderButton.controlIsNotDisplayed(10);
    }

    @When("I Click {string} link on the Market Channel Overview Page")
    public void iClickLinkOnTheMarketChannelOverviewPage(String value) throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(60);
        this.scrollDown();
        marketChannelOverviewPage.marketChannelProductsLink.get(value).controlIsDisplayed(10);
        marketChannelOverviewPage.marketChannelProductsLink.get(value).click();
        Thread.sleep(4000);
    }

    @And("I click Assign New Product Package Under The Product Package")
    public void iClickAssignNewProductPackageUnderTheProductPackage() throws Exception {
        marketChannelOverviewPage.assignNewProductPackage.click();
    }

    @And("I select {string} Option On Product Package Dropdown")
    public void iSelectOptionOnProductPackageDropdown(String option) throws Exception {
        marketChannelOverviewPage.productPackageDropDown.selectValueContainsOption(option);
    }

    @Then("I verify {} Option Display On Product Package tab")
    public void iVerifyOptionDisplayOnProductPackageTab(String option) throws Exception {
        marketChannelOverviewPage.productPackageTable.controlIsDisplayed(10);
        marketChannelOverviewPage.assignNewProductPackage.controlIsDisplayed(10);
        Assertions.assertTrue(marketChannelOverviewPage.productPackageTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(option)));
    }

    @And("I click on link cell row: {int} column {int} in Product Package Table")
    public void iClickOnLinkCellRowColumnInProductPackageTable(int row, int column) throws Exception {
        marketChannelOverviewPage.productPackageTable.clickLink(row, column);
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(30);
    }

    @And("I Click {} button on Market Channel Product Package Page")
    public void iClickButtonOnMarketChannelProductPackagePage(String option) throws Exception {
        if (this.replaceConfigurationValues(option).contains("Edit1")) {
            Thread.sleep(2000);
            marketChannelOverviewPage.editButton1.click();
            if (this.replaceConfigurationValues(option).contains("Edit2")) {
                marketChannelOverviewPage.editButton2.click();
            }
        }
    }



    @And("the [Marketing Name] textbox value is {string} in Market Channel Product Package")
    public void theTextboxValueIsInMarketChannelProductPackageShouldBe(String expectedResult) throws Exception {
        String actualResult = marketChannelProductPackagePage.marketingNameTextBox.getTextAttribute("value");
        expectedResult=expectedResult.toLowerCase().contains("empty")?"":this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),"ERROR the value of market channel is not the expected: "+expectedResult+" vs  actual: "+actualResult);

    }
}