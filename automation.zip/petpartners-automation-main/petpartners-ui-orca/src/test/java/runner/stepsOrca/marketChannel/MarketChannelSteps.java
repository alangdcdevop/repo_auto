package runner.stepsOrca.marketChannel;

import configuration.CommonValues;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.marketChannel.MarketChannelOverviewPage;
import pages.orca.marketChannel.MarketChannelPage;
import runner.stepsOrca.BaseSteps;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.List;
import java.util.Map;

public class MarketChannelSteps extends BaseSteps {
    MarketChannelPage marketChannelPage = new MarketChannelPage();
    MarketChannelOverviewPage marketChannelOverviewPage = new MarketChannelOverviewPage();

    @Then("I verify controls in market channel management page")
    public void iVerifyControlsInMarketChannelManagementPage() throws Exception {
        Assertions.assertTrue(marketChannelPage.marketChannelActiveCheckBox.controlIsDisplayed(),
                "ERROR: MarketChannelActive check box is not displayed");
        Assertions.assertTrue(marketChannelPage.marketChannelSearchButton.controlIsDisplayed(),
                "ERROR: MarketChannelSearch button is not displayed");
        Assertions.assertTrue(marketChannelPage.marketChannelClearButton.controlIsDisplayed(),
                "ERROR: MarketChannelClear button is not displayed");
        Assertions.assertTrue(marketChannelPage.marketChannelDashboardLink.controlIsDisplayed(),
                "ERROR: MarketChannelDashboard Link is not displayed");
        Assertions.assertTrue(marketChannelPage.newMarketChannelLink.controlIsDisplayed(),
                "ERROR: MarketChannelNew link is not displayed");
    }

    @When("I click market channel name link and verify page load")
    public void iClickMarketChannelNameLinkAndVerifyPageLoad(List<String> marketChannelList) throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(30);
        for (String sLink : marketChannelList) {
            if (!marketChannelPage.marketChannelNameLinkMap.containsKey(sLink))
                throw new Exception("Error!! the link ["+sLink+"] does not exist in the page");
            this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(30);
            marketChannelPage.marketChannelNameLinkMap.get(sLink).click();
            this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(30);
            Assertions.assertTrue(marketChannelOverviewPage.mcNameTextBox.controlIsDisplayed(),
                    "ERROR: MarketChannelOverviewPage Name text box is not displayed");
            this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(30);
            marketChannelPage.marketChannelTab.click();
        }

    }

    @And("I click New Market Channel link in Market Channel Management page")
    public void iClickNewMarketChannelLinkInMarketChannelManagementPage() throws Exception {
        marketChannelPage.newMarketChannelLink.click();
    }

    @When("I click on market channel tab in the menu")
    public void iClickOnMarketChannelTabInTheMenu() throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        marketChannelPage.marketChannelTab.click();
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
    }

    @Then("I verify market channel management page table links")
    public void iVerifyMarketChannelManagementPageTableLinks(List<String> controlsValue) throws Exception {
        for ( String tableValue:controlsValue) {
            Assertions.assertTrue(marketChannelPage.marketChannelNamesTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(tableValue)),
                    "ERROR: " + this.replaceConfigurationValues(tableValue) + " is not displayed");
        }
    }

    @Then("I verify market channel name link and click")
    public void iVerifyNewMarketChannelNameLinkAndClick(Map<String, String> controlsValue) throws Exception {
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        int times = 0;
        while (!marketChannelPage.marketChannelNamesTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(controlsValue.get("DisplayValue"))) && times<=10 ){
            this.scrollDown();
            this.scrollDown();
            Thread.sleep(1500);
            times++;
        }
        Assertions.assertTrue(marketChannelPage.marketChannelNamesTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(controlsValue.get("DisplayValue"))),
                "ERROR: " + this.replaceConfigurationValues(controlsValue.get("DisplayValue")) + " link is not displayed");

        marketChannelPage.marketChannelNamesTable.clickOnLinkCellWithoutAnchor(this.replaceConfigurationValues(controlsValue.get("DisplayValue")));
        Thread.sleep(2000);
        Assertions.assertEquals(marketChannelOverviewPage.mclDisplayTextBox.getTextAttribute("value"), this.replaceConfigurationValues(controlsValue.get("DisplayValue")), "ERROR: MarketChannelOverviewPage Display text box value matched");
    }

    @Then("I verify deleted market channel name link")
    public void iVerifyDeletedMarketChannelNameLink(Map<String, String> controlsValue) throws Exception {
        Assertions.assertFalse(marketChannelPage.marketChannelNamesTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(controlsValue.get("DisplayValue"))),
                "ERROR: " + this.replaceConfigurationValues(controlsValue.get("DisplayValue")) + " link is displayed");
    }

    @When("I click on market channel dashboard link in the left menu")
    public void iClickOnMarketChannelDashboardLinkInTheLeftMenu() throws Exception {
        marketChannelPage.marketChannelDashboard.click();
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
    }

    @And("i get the marketChannel Id in {}")
    public void iGetTheMarketChannelId(String nameVariable) throws Exception {
        Thread.sleep(2000);
        Session.getInstance().getDriver().navigate().back();
        Thread.sleep(2000);
        Session.getInstance().getDriver().navigate().forward();
        Thread.sleep(2000);
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(20);
        String id=marketChannelOverviewPage.mcIDTextBox.getTextAttribute("value");
        CommonValues.variables.put(nameVariable,id);
        Logger.log(Level.INFO,this.getClass().getName()+"> variable: "+nameVariable+" value: ["+id+"]" );
        Thread.sleep(2000);
    }

    @And("Search market channel in market channel management")
    public void searchMarketChannelInMarketChannelManagement(Map<String,String>data) throws Exception {
        if (data.containsKey("Market Channel name"))
          marketChannelPage.marketChannelNameTextBox.setText(this.replaceConfigurationValues(data.get("Market Channel name")));
        if (data.containsKey("Market Channel ID"))
         marketChannelPage.marketChannelIdTextBox.setText(this.replaceConfigurationValues(data.get("Market Channel ID")));
        marketChannelPage.marketChannelSearchButton.click();
        this.loadingSection.loadingSpinnerHiddenImage.controlIsDisplayed(15);
    }
}
