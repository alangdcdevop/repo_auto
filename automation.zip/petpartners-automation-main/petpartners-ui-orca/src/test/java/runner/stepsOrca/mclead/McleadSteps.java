package runner.stepsOrca.mclead;

import entities.orca.MCleadCustomerDetail;
import entities.orca.MCleadPetDetail;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import pages.orca.mclead.RegistrationMcleadPage;
import runner.stepsOrca.BaseSteps;

import java.util.Map;


public class McleadSteps extends BaseSteps {

    RegistrationMcleadPage registrationMcleadPage = new RegistrationMcleadPage();


    @When("adding a registration to Mclead")
    public void addingARegistrationToMclead() throws Exception {
        menuSection.optionMenu.get("Mclead").click();
        subMenuSection.optionSubMenu.get("Add Registration").click();
    }

    @And("filling the Mclead - PetDetails Sections")
    public void fillingTheMcleadPetDetailsSections(MCleadPetDetail mCleadPetDetail) throws Exception {
        registrationMcleadPage.fillPetDetailSection(mCleadPetDetail);
    }

    @And("filling the Mclead - Customer Details")
    public void fillingTheMcleadCustomerDetails(MCleadCustomerDetail mCleadCustomerDetail) throws Exception {
        registrationMcleadPage.fillCustomerDetailSection(mCleadCustomerDetail);
    }

    @And("click on Add Registration button in Mclead Page")
    public void clickOnAddRegistrationButtonInMcleadPage() throws Exception {
        this.scrollDown();
        registrationMcleadPage.addRegistrationButton.click();
    }

    @DataTableType
    public MCleadPetDetail mCleadPetDetailEntry(Map<String, String> entry) {
        MCleadPetDetail entity = new MCleadPetDetail();
        entity.setRegistrationNo(this.replaceConfigurationValues(entry.get("Registration No")))
                .setRegistrationDate(this.replaceConfigurationValues(entry.get("Registration Date")))
                .setDateOfBirth(this.replaceConfigurationValues(entry.get("Date of Birth")))
                .setColor(this.replaceConfigurationValues(entry.get("Color")))
                .setMarketChannel(this.replaceConfigurationValues(entry.get("Market Channel")))
                .setPartner(this.replaceConfigurationValues(entry.get("Partner")))
                .setPetName(this.replaceConfigurationValues(entry.get("Pet Name")))
                .setSpecies(this.replaceConfigurationValues(entry.get("Species")))
                .setBreed(this.replaceConfigurationValues(entry.get("Breed")))
                .setGender(this.replaceConfigurationValues(entry.get("Gender")));
        return entity;
    }

    @DataTableType
    public MCleadCustomerDetail mCleadCustomerDetailEntry(Map<String, String> entry) {
        MCleadCustomerDetail entity = new MCleadCustomerDetail();
        entity.setFirstName(this.replaceConfigurationValues(entry.get("First Name")))
                .setMiddleName(this.replaceConfigurationValues(entry.get("Middle Name")))
                .setLastName(this.replaceConfigurationValues(entry.get("Last Name")))
                .setAddress1(this.replaceConfigurationValues(entry.get("Address 1")))
                .setAddress2(this.replaceConfigurationValues(entry.get("Address 2")))
                .setCity(this.replaceConfigurationValues(entry.get("City")))
                .setStateProvince(this.replaceConfigurationValues(entry.get("State/Province")))
                .setPostalCode(this.replaceConfigurationValues(entry.get("Postal Code")))
                .setEmail(this.replaceConfigurationValues(entry.get("Email")))
                .setPhone(this.replaceConfigurationValues(entry.get("Phone")))
                .setSendEmail(this.replaceConfigurationValues(entry.get("Send Email")));
        return entity;
    }
}

