package runner.stepsOrca.partner;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import pages.orca.partner.PartnersPage;
import runner.stepsOrca.BaseSteps;

import java.util.Map;

public class PartnersSteps extends BaseSteps {
    PartnersPage partnersPage = new PartnersPage();
    @And("I click Add Partner link in the left menu")
    public void iClickAddPartnerLinkInTheLeftMenu() throws Exception {
        partnersPage.addPartnerLink.click();
    }

    @When("I Enter the Partner Name to textBox")
    public void iEnterThePartnerNameToTextBox(Map<String, String> controlsValue) throws Exception {
        partnersPage.partnerNameTextBox.setText(this.replaceConfigurationValues(controlsValue.get("DisplayValue")));
    }

    @And("I Click [{string}] button in Partners page")
    public void iClickButtonInPartnersPage(String value) throws Exception {
        partnersPage.partnersRunSearchButton.click();
    }

    @And("I click the link on partners search results Table")
    public void iClickTheLinkOnPartnersSearchResultsTable(Map<String, String> controlsValue) throws Exception {
        partnersPage.partnerResultTable.clickOnLinkCell(this.replaceConfigurationValues(controlsValue.get("DisplayValue")));
    }
}
