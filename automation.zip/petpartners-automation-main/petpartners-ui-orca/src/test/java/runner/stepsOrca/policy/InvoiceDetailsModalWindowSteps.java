package runner.stepsOrca.policy;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.orca.finance.InvoiceDetailsModalWindowPage;

import java.util.List;

public class InvoiceDetailsModalWindowSteps {
    InvoiceDetailsModalWindowPage invoiceDetailsModalWindowPage = new InvoiceDetailsModalWindowPage();



    @And("click on close button in Invoice Details modal window")
    public void clickOnCloseButtonInInvoiceDetailsModalWindow() throws Exception {
        invoiceDetailsModalWindowPage.closeButton.click();

    }

    @Then("verify the headers should be displayed in the Invoice Details modal window")
    public void verifyTheHeadersShouldBeDisplayedInTheInvoiceDetailsModalWindow(List<String> expectedHeaderList) throws Exception {
        Thread.sleep(2000);
        Assertions.assertTrue(invoiceDetailsModalWindowPage.invoiceDetailsTable.verifyAllHeaderLabel(expectedHeaderList),"ERROR> the headers are not displayed: "+expectedHeaderList.toString());
    }

}