package runner.stepsOrca.policy;


import configuration.CommonValues;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.pet.PetDetailPage;
import runner.stepsOrca.BaseSteps;
import utils.Level;
import utils.Logger;

import java.util.List;


public class PetDetailSteps extends BaseSteps {
    PetDetailPage petDetailPage = new PetDetailPage();

    @Then("the Pet Detail page should be displayed")
    public void thePetDetailPageShouldBeDisplayed() {
        Assertions.assertTrue(petDetailPage.petDetailLabel.controlIsDisplayed(), "ERROR! the pet detail page is not displayed");
    }

    @When("I click on the [{}] tab option on pet detail page")
    public void iClickOnTheClaimsTabOptionOnPetDetailPage(String tabOption) throws Exception {
        if (petDetailPage.petDetailTabOption.containsKey(tabOption))
            petDetailPage.petDetailTabOption.get(tabOption).click();
        else
            throw new Exception("Error the option in tab " + tabOption + " does not exist");
    }

    @And("the claim table should be displayed with the columns")
    public void theClaimTableShouldBeDisplayedWithTheColumns(List<String> expectedLabels) throws Exception {
        Assertions.assertTrue(petDetailPage.claimsTable.verifyAllHeaderLabel(expectedLabels),
                "Some labels in the table is missing, actual [" + petDetailPage.claimsTable.getAllHeaderLabel().toString() + " vs expected [" + expectedLabels.toString() + "]");
    }

    @And("I get the {} value in Pet Detail in {}")
    public void iGetThePetnameValueInPetDetailInPetName(String textbox, String variableName) throws Exception {
        String value = petDetailPage.petDetailTextBox.get(textbox).getTextAttribute("value");
        CommonValues.variables.put(variableName, value);
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variableName) + "] in [" + variableName + "]");
    }
}