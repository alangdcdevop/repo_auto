package runner.stepsOrca.policy;

import configuration.CommonValues;
import configuration.Configuration;
import control.Table;
import entities.orca.policy.*;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.JavascriptExecutor;
import pages.akc.CompleteYourEnrollmentPage;
import pages.akc.GetQuotePage;
import pages.orca.akcActivate.AkcActivatePage;
import pages.orca.claim.ClaimDetails;
import pages.orca.followUps.FollowUpsPage;
import pages.orca.mclead.RegistrationMcleadPage;
import pages.orca.orcaDashBoard.OrcaDashboard;
import pages.orca.policy.*;
import pages.orca.policy.backdate.BackDateSection;
import pages.orca.policy.noteTab.AddNoteSection;
import pages.ppi.PortalPolicyDetailsPage;
import runner.stepsOrca.BaseSteps;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PolicySteps extends BaseSteps {
    PolicyDetailsPage policyDetailsPage = new PolicyDetailsPage();

    ClaimDetails claimDetails = new ClaimDetails();
    MoveClaimDialog moveClaimDialog = new MoveClaimDialog();
    PolicySearchSection policySearchSection = new PolicySearchSection();

    AkcActivatePage akcActivatePage = new AkcActivatePage();
    CompleteYourEnrollmentPage completeYourEnrollmentPage = new CompleteYourEnrollmentPage();
    PolicyMakeChangesPage policyMakeChangesPage = new PolicyMakeChangesPage();

    PolicyChangesForNewPet policyChangesForNewPet = new PolicyChangesForNewPet();

    PortalPolicyDetailsPage portalPolicyDetailsPage = new PortalPolicyDetailsPage();

    PolicyCancelPage policyCancelPage = new PolicyCancelPage();

    BackDateSection backDateSection = new BackDateSection();
    AddNoteSection addNoteSection = new AddNoteSection();
    OrcaDashboard orcaDashboard = new OrcaDashboard();
    EditPaymentPage editPaymentPage = new EditPaymentPage();
    FollowUpsPage followUpsPage = new FollowUpsPage();


    @Then("the policy detail form with labels should be displayed")
    public void thePolicyDetailFormWithLabelsShouldBeDisplayed(List<String> labels) throws Exception {
        List<String> isNotDisplayedList = new ArrayList<>();
        for (String label : labels) {
            if (!policyDetailsPage.labelMap.containsKey(label))
                throw new Exception("ERROR> Please add the label [" + label + "] in the mapping page");

            if (policyDetailsPage.labelMap.containsKey(label) && !policyDetailsPage.labelMap.get(label).controlIsDisplayed())
                isNotDisplayedList.add(label);
        }
        Assertions.assertTrue(isNotDisplayedList.size() == 0, "ERROR> Some labels are not displayed on Policy Details: \n " + isNotDisplayedList.toString());
    }

    @And("click on [{}] tab option on policy detail page")
    public void clickOnCoverageSTabOption(String tabOption) throws Exception {
        policyDetailsPage.tabOptionLabelsMap.get(tabOption).click();
    }

    @And("^click on (Active|Upcoming|Expired) on Policy Term on policy detail page$")
    public void clickOnActiveOnPolicyTerm(String value) throws Exception {
        Thread.sleep(5000);
        if (value.contains("Active")) {
            policyDetailsPage.activeLink.waitUntilControlIsDisplayed();
            policyDetailsPage.activeLink.controlIsClickable();
            policyDetailsPage.activeLink.click();
        } else if (value.contains("Upcoming")) {
            policyDetailsPage.upcomingLink.waitUntilControlIsDisplayed();
            policyDetailsPage.upcomingLink.controlIsClickable();
            policyDetailsPage.upcomingLink.click();
        } else {
            policyDetailsPage.expiredLink.waitUntilControlIsDisplayed();
            policyDetailsPage.expiredLink.controlIsClickable();
            policyDetailsPage.expiredLink.click();
        }
        Thread.sleep(5000);
    }

    @And("click on Past on Policy Term on policy detail page")
    public void clickOnPastOnPolicyTermOnPolicyDetailPage() throws Exception {
        policyDetailsPage.pastCoverageLink.click();
    }

    @Then("^verify the (Active|Upcoming) pet detail should be displayed$")
    public void verifyTheActivePetDetailShouldBeDisplayed(String value) throws InterruptedException {
        Thread.sleep(2500);
        Assertions.assertTrue(policyDetailsPage.coveragePeriodLink.controlIsDisplayed(), "ERROR! the coverage on active link is not displayed on coverage tab");
    }

    @And("^click on \\[\\+\\] button on (active pet detail|under warning active pet detail|upcoming pet detail)$")
    public void clickOnButtonOnActivePetDetail(String site) throws Exception {
        policyDetailsPage = new PolicyDetailsPage();
        policyDetailsPage.plusPetDetailButton.controlIsDisplayed();
        policyDetailsPage.plusPetDetailButton.click();
    }

    @And("click on the petname label in the pet table")
    public void clickOnThePetnameLabelInThePetTable() throws Exception {
        policyDetailsPage.petsTable.clickLinkXpath(1, 1);
    }

    @And("the status control should be {string} on Policy Detail Page")
    public void theControlShouldBeOnPolicyDetailPage(String expectedResult) throws Exception {
        policyDetailsPage.statusSelect.controlIsDisplayed(20);
        String actualResult = policyDetailsPage.statusSelect.getTextOptionSelected();
        Assertions.assertEquals(expectedResult, actualResult, "ERROR! the status values is  different, actual: " + actualResult + " vs expected: " + expectedResult);
    }

    @And("the status label should be {string} on Policy Detail Page")
    public void theStatusLabelShouldBeOnPolicyDetailPage(String expectedResult) throws Exception {
        String actualResult = policyDetailsPage.policyStatusLabel.getText();
        Assertions.assertEquals(expectedResult, actualResult, "ERROR! the status values is  different, actual: " + actualResult + " vs expected: " + expectedResult);
    }

    @And("select the {string} option on Status on Policy Detail Page")
    public void selectTheOptionOnStatusOnPolicyDetailPage(String option) throws Exception {
        policyDetailsPage.statusSelect.selectValue(option);
        Thread.sleep(3000);
    }

    @And("click on [save] button on Policy Detail Page")
    public void clickOnButtonOnPolicyDetailPage() throws Exception {
        policyDetailsPage.saveButton.click();
        Thread.sleep(3000);
    }

    @And("I click on [Add New] button on claims tab")
    public void iClickOnAddNewButtonOnClaimsTab() throws Exception {
        policyDetailsPage.addNewClaimButton.click();
    }

    @And("I click on [Move Claims] button on claims tab")
    public void iClickOnMoveClaimsButtonOnClaimsTab() throws Exception {
        policyDetailsPage.moveClaimButton.click();
    }

    @And("select {string} claim to move to {string}")
    public void selectClaimToMoveTo(String claimNumber, String policyNumertoMove) throws Exception {
        moveClaimDialog.moveClaim(this.replaceConfigurationValues(policyNumertoMove),
                this.replaceConfigurationValues(claimNumber));
    }

    @And("click on customer tab in bottom section")
    public void clickOnCustomerTabInBottomSection() throws Exception {
        policyDetailsPage.tabOptionLabelsMap.get("Customer(s)").click();
        Thread.sleep(3000);
    }

    @And("verify the customer {} is displayed")
    public void verifyTheCustomerDefaultUerIsDisplayed(String email) {
        Assertions.assertTrue(policyDetailsPage.emailCustomer(this.replaceConfigurationValues(email)), "ERROR ! email: " + this.replaceConfigurationValues(email) + "is not displayed in customer tab");
    }

    @And("I select the value {string} in marketChannel dropdown")
    public void iClickMarketChannelDropdownSelectPET(String petValue) throws Exception {
        policySearchSection.marketchannelSelect.selectValueContainsOption(petValue);
    }

    @And("I search Policy with the next value")
    public void iSeachPolicyWithTheNextValue(PolicySearchEntity policySearchEntity) throws Exception {
        policySearchSection.clearButton.click();
        if (!policySearchEntity.getMarketChannel().isEmpty())
            policySearchSection.marketchannelSelect.selectValueContainsOption(this.replaceConfigurationValues(policySearchEntity.getMarketChannel()));

        if (!policySearchEntity.getPolicyNumber().isEmpty())
            policySearchSection.policyNumberTextBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(policySearchEntity.getPolicyNumber())));

        if (!policySearchEntity.getPostalCode().isEmpty())
            policySearchSection.postalCodeTextBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(policySearchEntity.getPostalCode())));

        if (!policySearchEntity.getLastName().isEmpty())
            policySearchSection.lastNameTextBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(policySearchEntity.getLastName())));

        if (!policySearchEntity.getEmailAddress().isEmpty())
            policySearchSection.emailAddressTextBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(policySearchEntity.getEmailAddress())));

        if (!policySearchEntity.getPhoneNum().isEmpty())
            policySearchSection.phoneNumberTextBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(policySearchEntity.getPhoneNum())));

        if (!policySearchEntity.getBillingId().isEmpty())
            policySearchSection.billingIdTextBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(policySearchEntity.getBillingId())));


        if (!policySearchEntity.getRegstrationNum().isEmpty())
            policySearchSection.registrationNumberTextBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(policySearchEntity.getRegstrationNum())));


        if (!policySearchEntity.getLinkedPolicy().isEmpty())
            policySearchSection.linkedPolicyTextBox.setText(this.replaceConfigurationValues(this.replaceConfigurationValues(policySearchEntity.getLinkedPolicy())));
        policySearchSection.runSearchButton.click();
    }

    @DataTableType
    public PolicySearchEntity getEntity(Map<String, String> entity) {

        PolicySearchEntity tmp = new PolicySearchEntity();

        if (entity.containsKey("Market Channel"))
            tmp.setMarketChannel(entity.get("Market Channel"));

        if (entity.containsKey("Policy No"))
            tmp.setPolicyNumber(entity.get("Policy No"));

        if (entity.containsKey("Postal Code"))
            tmp.setPostalCode(entity.get("Postal Code"));

        if (entity.containsKey("Last Name"))
            tmp.setLastName(entity.get("Last Name"));

        if (entity.containsKey("Email address"))
            tmp.setEmailAddress(entity.get("Email address"));

        if (entity.containsKey("Phone No"))
            tmp.setPhoneNum(entity.get("Phone No"));

        if (entity.containsKey("Billing Id"))
            tmp.setBillingId(entity.get("Billing Id"));

        if (entity.containsKey("Registration No"))
            tmp.setRegstrationNum(entity.get("Registration No"));

        if (entity.containsKey("Linked Policy"))
            tmp.setLinkedPolicy(entity.get("Linked Policy"));

        return tmp;

    }

    @And("verify the value {string} is displayed in the result search")
    public void verifyTheValueIsDisplayedInTheResultSearch(String expectedResult) throws Exception {
        Assertions.assertTrue(policySearchSection.searchResultTable.checkIfValueIsDisplayedInTable(this.replaceConfigurationValues(expectedResult)),
                "ERROR! the value : [" + this.replaceConfigurationValues(expectedResult) + "] is not displayed in the policy search result section");
    }

    @Given("I go to the AKC Petpartnes")
    public void iGoToTheAKCPetpartnes() {
        Session.getInstance().getDriver().get(Configuration.WEB_UI_AKC);
    }

    @Then("I click activate coverage button")
    public void iClickActivateCoverageButton() throws Exception {
        akcActivatePage.activateCoverageButton.click();
        akcActivatePage.activateCoverageButton2.click();
    }

    @Then("I enter registration number and Zipcode")
    public void iEnterRegistrationNumberAndZipcode(DataTable dataTable) throws Exception {
        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
        for (Map<String, String> dataa : data) {
            akcActivatePage.registrationNumberTexbox.setText(this.replaceConfigurationValues(dataa.get("Registration No")));
            akcActivatePage.zipCodeTextbox.setText((this.replaceConfigurationValues(dataa.get("Postal Code"))));
        }
    }

    @And("I click lookup Pet button")
    public void iClickLookupPetButton() throws Exception {

        akcActivatePage.lookupPetButton.click();
        Thread.sleep(3000);
    }

    @And("I select customer source value as {string}")
    public void iSelectCustomerSourceValue(String value) throws Exception{
        pages.akc.GetQuotePage getQuotePage= new GetQuotePage();
        getQuotePage.customerSource.selectValue(this.replaceConfigurationValues(value));
    }

    @Then("I click choose coverage button")
    public void iClickChooseCoverageButton() throws Exception {

        akcActivatePage.chooseCoverageButton.click();
        Thread.sleep(3000);
    }

    @And("I click application acknowledgments radio button")
    public void iClickApplicationAcknowledgmentsRadioButton() throws Exception {
        if (completeYourEnrollmentPage.iAgreeThatByCheckingOption.controlIsDisplayed(5)) {
           completeYourEnrollmentPage.iAgreeThatByCheckingOption.select();
        }
        if (completeYourEnrollmentPage.iAgreeToGoPaperlessOption.controlIsDisplayed(5)) {
            completeYourEnrollmentPage.iAgreeToGoPaperlessOption.select();
        }

        if (completeYourEnrollmentPage.byCheckingBoxOption.controlIsDisplayed(5)) {
            completeYourEnrollmentPage.byCheckingBoxOption.select();
        }
        completeYourEnrollmentPage.enrollNowButton.controlIsClickable();
        completeYourEnrollmentPage.enrollNowButton.click();

    }

    @Then("I select coverage for pet")
    public void iSelectCoverageForPet() throws Exception {
        akcActivatePage.initial30DaysOfPet.controlIsDisplayed(10);
        akcActivatePage.initial30DaysOfPet.click();
    }

    @And("I set linkedPolicy to Textbox {string}")
    public void iSetLinkedPolicyToTextbox(String value) throws Exception {
        policySearchSection.setLinkedPolicyTextbox.setText(this.replaceConfigurationValues(value));
    }

    @Then("I click on {string} option in HAS YOUR PET EVER BEEN DIAGNOSED WITH OR SHOWN SYMPTOMS OF DIABETES?")
    public void iClickOnNoOptionInHASYOURPETEVERBEENDIAGNOSEDWITHORSHOWNSYMPTOMSOFDIABETES(String option) throws Exception {

        if (option.contains("No")) {
            akcActivatePage.noHasYourPetOption.click();
        } else if (option.contains("Yes")) {
            akcActivatePage.yesHasYourPetOption.click();
        }
    }

    @And("I click on get Quote button in McLead Details")
    public void clickOnGetQuoteInMcLeadDetails() throws Exception{
        RegistrationMcleadPage registrationMcleadPage = new RegistrationMcleadPage();
        registrationMcleadPage.getquoteMcLeadDetails.click();
    }
    @Then("I click {string} dropdown")
    public void iClickDropdown(String options) throws Exception {
        Thread.sleep(2500);
        policyMakeChangesPage.policyActionsButton.click();
    }

    @And("I select {string}")
    public void iSelect(String value) throws Exception {
        Thread.sleep(2500);
        policyMakeChangesPage.changeEffectiveDateButton.click();

    }

    @And("I set new effective date")
    public void iSetNewEffectiveDate(DataTable dataTable) throws Exception {

        List<Map<String, String>> data = dataTable.asMaps(String.class, String.class);
        for (Map<String, String> dataa : data) {
            policyMakeChangesPage.newEffectiveDateButton.clear();
            policyMakeChangesPage.newEffectiveDateButton.setText(this.replaceConfigurationValues(dataa.get("New Effective Date")));
        }
    }

    @Then("I set the notes for changes")
    public void iSetTheNotesForChanges() throws Exception {
        policyMakeChangesPage.notesTextbox.setText("Test");

    }

    @And("click on [save] button on Change Effective page")
    public void clickOnSaveButtonOnChangeEffectivePage() throws Exception {
        policyMakeChangesPage.saveButton.click();
    }

    @Then("I click Make Changes button")
    public void iClickMakeChangesButton() throws Exception {
        Thread.sleep(3000);
        policyMakeChangesPage.makeChangeButton.click();
    }

    @Then("I select {string} option")
    public void iSelectMakeChangesOption(String option) throws Exception {
        Thread.sleep(2500);
        if (option.contains("Make Changes")) {
            Thread.sleep(2500);
            policyMakeChangesPage.makechangeOption.click();
        } else if (option.contains("Transfer Sale")) {
            policyMakeChangesPage.transferSaleButton.click();
        }

    }

    @Then("I click Add Pet button")
    public void iClickAddPetButton() throws Exception {
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,700)");
        Thread.sleep(2500);
        policyMakeChangesPage.addPetButton.click();
    }

    @And("I select {string} option Under the Add pet")
    public void iSelectExistingPetOptionUnderTheAddPet(String value) throws Exception {
        if (value.contains("Existing Pet")) {
            Thread.sleep(3000);
            policyMakeChangesPage.existingPetButton.click();
        } else if (value.contains("New Pet")) {
            policyMakeChangesPage.newPetButton.click();
        }

    }

    @When("I Provide active {string} and click run search")
    public void iProvideActivePolicyNumberAndClickRunSearch(String value) throws Exception {

        policyMakeChangesPage.policynumberTextBox.setText(this.replaceConfigurationValues(value));
        policySearchSection.runSearchButton.click();

    }

    @Then("I click Make changes button with zero premiums amount")
    public void iClickMakeChangesButtonWithZeroPremiumsAmount() throws Exception {
        policyMakeChangesPage.makeChangeButton2.click();
    }

    @And("I click {string} button")
    public void iClickButton(String option) throws Exception {
        Thread.sleep(2500);
        JavascriptExecutor js = (JavascriptExecutor) Session.getInstance().getDriver();
        js.executeScript("window.scrollBy(0,700)");
        if (option.contains("Active")) {
            Thread.sleep(2500);
            policyMakeChangesPage.activeButton.waitUntilControlIsDisplayed();
            policyMakeChangesPage.activeButton.click();
        } else if (option.contains("Upcoming")) {
            policyMakeChangesPage.upcomingButton.click();

        }
    }

    @Then("I click select button on pet search page")
    public void iClickSelectButtonOnPetSearchPage() throws Exception {
        policyMakeChangesPage.selectButton.click();
    }

    @And("I select {string} Coverage on Make Changes page")
    public void iSelectCoverageOnMakeChangesPage(String value) throws Exception {
        if (value.contains("AccidentCare")) {
            Thread.sleep(3000);
            policyMakeChangesPage.accidentCareRadiobutton.click();
        } else if (value.contains("CompanionCare")) {
            policyMakeChangesPage.companionCareRadiobutton.click();
        }
    }

    @When("I select The Coverage for  {string} on Make changes page")
    public void iSelectTheCoverageForOnMakeChangesPage(String value) throws Exception {
        if (value.contains("Support Plus")) {
            policyMakeChangesPage.supportPlusCheckbox.check();
        } else if (value.contains("DefenderPlus")) {
            policyMakeChangesPage.defenderPlusCheckbox.check();
        } else if (value.contains("Defender")) {
            policyMakeChangesPage.defenderCheckbox.check();
        } else if (value.contains("AlternativePlus")) {
            policyMakeChangesPage.alternativePlusCheckbox.check();
        } else if (value.contains("Exam Plus")) {
            policyMakeChangesPage.examPlusCheckbox.check();
        }

    }

    @And("I click [save] button Make changes page")
    public void iClickSaveButtonMakeChangesPage() throws Exception {
        policyMakeChangesPage.saveButtonMakeChangesPage.click();
    }

    @Then("I set the pet name {string} on Add coverage Page")
    public void iSetThePetNameTestOnAddCoveragePage(String value) throws Exception {
        policyChangesForNewPet.petNameTextBox.setText(this.replaceConfigurationValues(value));
    }

    @Then("I set the Year [{string}] of Brith Year for the pet")
    public void iSetTheYearOfBrithYearForThePet(String year) throws Exception {
        policyChangesForNewPet.petBrithYearSelect.selectValueContainsOption(year);
        policyChangesForNewPet.petBrithDate.click();

    }

    @And("I set the Month {string} of Brith Month for the pet")
    public void iSetTheMonthMarOfBrithMonthForThePet(String month) throws Exception {
        policyChangesForNewPet.petDateOfBrithTextBox.clear();
        policyChangesForNewPet.petBrithMonthSelect.selectValueContainsOption(month);
    }

    @And("I set the pet information on Add coverage page")
    public void iSetThePetInformationOnAddCoveragePage(PolicyMakechangeEntity policyMakechangeEntity) throws Exception {
        if (!policyMakechangeEntity.getGender().isEmpty())
            policyChangesForNewPet.genderOfthePet.selectValueContainsOption(this.replaceConfigurationValues(policyMakechangeEntity.getGender()));
        if (!policyMakechangeEntity.getPetName().isEmpty())
            policyChangesForNewPet.petNameTextBox.setText(this.replaceConfigurationValues(policyMakechangeEntity.getPetName()));
        if (!policyMakechangeEntity.getSpecies().isEmpty())
            policyChangesForNewPet.speciesOfThePet.selectValueContainsOption(this.replaceConfigurationValues(policyMakechangeEntity.getSpecies()));
        if (!policyMakechangeEntity.getBreed().isEmpty())
            Thread.sleep(2000);
        policyChangesForNewPet.breedOfThePet.selectValueContainsOption(this.replaceConfigurationValues(policyMakechangeEntity.getBreed()));
    }

    @DataTableType
    public PolicyMakechangeEntity getentity(Map<String, String> entity) {
        PolicyMakechangeEntity tmpp = new PolicyMakechangeEntity();
        if (entity.containsKey("Gender"))
            tmpp.setGender(entity.get("Gender"));
        if (entity.containsKey("Pet name"))
            tmpp.setPetName(entity.get("Pet name"));
        if (entity.containsKey("Species"))
            tmpp.setSpecies(entity.get("Species"));
        if (entity.containsKey("Breed"))
            tmpp.setBreed(entity.get("Breed"));
        return tmpp;
    }

    @Then("I select [{string}] for Coverage on Add coverage page")
    public void iSelectForCoverageOnAddCoveragePage(String option) throws Exception {
        if (option.contains("HereditaryPlus"))
            policyChangesForNewPet.hereDitaryPlusCheckBox.click();
        if (option.contains("SupportPlus"))
            policyChangesForNewPet.supportPlusCheckBox.check();
        if (option.contains("Alternative Plus"))
            policyChangesForNewPet.alternativePlusCheckBox.check();
        if (option.contains("Exam Plus"))
            policyChangesForNewPet.examPlusCheckBox.check();
        if (option.contains("Defender Plus"))
            policyChangesForNewPet.defenderPlusCheckBox.check();
        if (option.contains("Defender"))
            policyChangesForNewPet.defenderCheckBox.check();

    }

    @And("I click [Save] button on quote details page")
    public void iClickSaveButtonOnQuoteDetailsPage() throws Exception {
        policyChangesForNewPet.saveButtonButton.controlIsDisplayed(10);
        policyChangesForNewPet.saveButtonButton.click();
    }

    @And("click on Add Pet tab under Coverage header")
    public void clickOnAddPetTabUnderCoverageHeader() throws Exception {
        portalPolicyDetailsPage.addPetButton.controlIsDisplayed(5);
        portalPolicyDetailsPage.addPetButton.click();
    }

    @And("click on Continue button in Effective Date pop up window")
    public void clickOnContinueButtonInEffectiveDatePopUpWindow() throws Exception {
        portalPolicyDetailsPage.popupContinueButton.click();
    }


    @And("Set Cancel Coverage Details on Cancel Coverage Page")
    public void setCancelCoverageDetailsOnCancelCoveragePage(PolicyCancelEntity policyCancelEntity) throws Exception {
        if (!policyCancelEntity.getCancelRequestOnTextBox().isEmpty())
            policyCancelPage.cancelRequestOnTextBox.clear();
        policyCancelPage.cancelRequestOnTextBox.setText(this.replaceConfigurationValues(policyCancelEntity.getCancelRequestOnTextBox()));
        policyCancelPage.body.click();
        if (!policyCancelEntity.getCancelReasonDropdown().isEmpty())
            policyCancelPage.cancelReasonDropdown.selectValue(this.replaceConfigurationValues(policyCancelEntity.getCancelReasonDropdown()));
        if (!policyCancelEntity.getCancelTypeDropdown().isEmpty())
            policyCancelPage.cancelTypeDropdown.selectValue(this.replaceConfigurationValues(policyCancelEntity.getCancelTypeDropdown()));
        if (!policyCancelEntity.getCancelNotesTextBox().isEmpty())
            policyCancelPage.cancelNotesTextBox.setText(this.replaceConfigurationValues(policyCancelEntity.getCancelNotesTextBox()));
    }


    @Then("I click [Save] Button on Cancel Coverage Page")
    public void iClickSaveButtonOnCancelCoveragePage() throws Exception {
        policyCancelPage.saveButton.click();
    }

    @And("I click {string} Button On Cancel Coverage Page")
    public void iClickButtonOnCancelCoveragePage(String option) throws Exception {
        policyCancelPage.returnPolicyButton.controlIsDisplayed(5);
        policyCancelPage.returnPolicyButton.click();
    }

    @DataTableType
    public PolicyCancelEntity geeEntity(Map<String, String> entity) {
        PolicyCancelEntity tmp = new PolicyCancelEntity();
        if (entity.containsKey("Request on"))
            tmp.setCancelRequestOnTextBox(entity.get("Request on"));
        if (entity.containsKey("Cancel Reason"))
            tmp.setCancelReasonDropdown(entity.get("Cancel Reason"));
        if (entity.containsKey("Cancel Type"))
            tmp.setCancelTypeDropdown(entity.get("Cancel Type"));
        if (entity.containsKey("Notes"))
            tmp.setCancelNotesTextBox(entity.get("Notes"));
        return tmp;
    }

    @And("I click Cancel Coverage Button for pet name {string} on cancel coverage page")
    public void iClickCancelCoverageButtonForPetNameOnCancelCoveragePage(String value) throws Exception {
        if (policyCancelPage.cancelCoverage.getText().contains(value)) {
            policyCancelPage.cancelPolicyButton.click();
        }
    }

    @And("I set the pet name {string}")
    public void iSetThePetName(String name) throws Exception {
        policyCancelPage.petnameTextBox.setText(name);
    }

    @And("I click {string} Button on Policy details page")
    public void iClickButtonOnPolicyDetailsPage(String option) throws Exception {
        if (option.contains("Submit Approve")) {
            policyCancelPage.submitApprovalButton.click();
        } else if (option.contains("Approve Changes")) {
            policyCancelPage.approveChangesButton.controlIsDisplayed(5);
            policyCancelPage.approveChangesButton.click();
        }
    }

    @And("select {string} in Policy Actions in Policy Detail Page")
    public void selectInPolicyActionsInPolicyDetailPage(String policyAction) throws Exception {
        policyDetailsPage.selectOptionPolicyActions(policyAction);
    }

    @And("configure the Backdate Full Term Policy")
    public void configureTheBackdateFullTermPolicy(Map<String, String> data) throws Exception {
        if (data.containsKey("New Effective Date"))
            backDateSection.newEffectiveDateTextBox.clearSetText(this.replaceConfigurationValues(data.get("New Effective Date")));

        if (data.get("Coverage Period").equals("FirstValue"))
            backDateSection.coveragePeriodSelect.firstValue();
        else
            backDateSection.coveragePeriodSelect.selectValue(this.replaceConfigurationValues(data.get("Coverage Period")));

        if (data.containsKey("Notes"))
            backDateSection.notesTextBox.setText(this.replaceConfigurationValues(data.get("Notes")));

        backDateSection.saveButton.click();


    }

    @And("^select on \\[(Make Changes|Transfer Sale)\\] option on Policy Term>Active>Policy detail page$")
    public void selectOnMakeChangesOptionOnPolicyTermActivePolicyDetailPage(String option) throws Exception {
        policyDetailsPage.makeChangesButton.controlIsDisplayed(5);
        policyDetailsPage.makeChangesButton.controlIsClickable();
        policyDetailsPage.makeChangesButton.click();

        if (option.contains("Make Changes")) {
            policyDetailsPage.makeChangesOption.controlIsDisplayed();
            policyDetailsPage.makeChangesOption.click();
        } else {
            policyDetailsPage.transferSaleOption.controlIsDisplayed();
            policyDetailsPage.transferSaleOption.click();
        }
    }


    @And("create a new Note using: {string} Policy Detail Page")
    public void createANewNoteUsingPolicyDetailPage(String noteData) throws Exception {
        policyDetailsPage.addNoteButton.click();
        //addNoteSection.detailTextBox.setText(this.replaceConfigurationValues(noteData));
        Session.getInstance().getDriver().switchTo().frame("noteTextBox_ifr");
        addNoteSection.typeHereTextBox.setText(this.replaceConfigurationValues(noteData));
        Thread.sleep(10000);
        Session.getInstance().getDriver().switchTo().defaultContent();
        this.scrollDown();
        addNoteSection.saveButton.controlIsClickable();
        addNoteSection.saveButton.click();

    }

    @Then("verify the {string} should be displayed on Policy Detail Page")
    public void verifyTheShouldBeDisplayedOnPolicyDetailPage(String expectedNote) {
        Assertions.assertTrue(policyDetailsPage.isNoteDisplayed(this.replaceConfigurationValues(expectedNote)), "ERROR> the note: [" + expectedNote + "] is not displayed");
    }


    @Then("verify the buttons are displayed in Policy Detail Page")
    public void verifyTheButtonsAreDisplayedInPolicyDetailPage(List<String> buttonNameList) {
        for (String buttonName : buttonNameList) {
            Assertions.assertTrue(policyDetailsPage.buttonsMap.get(buttonName).controlIsDisplayed(), "ERROR: the button: [" + buttonName + "] is not displayed");
        }
    }

    @And("select the {string} option on Hold Payment on Policy Detail Page")
    public void selectTheOptionOnHoldPaymentOnPolicyDetailPage(String option) throws Exception {
        policyDetailsPage.holdPaymentSelect.selectValue(this.replaceConfigurationValues(option));
    }

    @Then("^verify the headers should be displayed in the (Pet Detail Table|Upcoming Pet Detail Table)$")
    public void verifyTheHeadersShouldBeDisplayedInThePetDetailTable(String site, List<String> expectedHeaderList) throws Exception {
        Table assertTable = site.contains("Upcoming") ? policyDetailsPage.activeSecondPetDetailTable : policyDetailsPage.activePetDetailTable;
        Assertions.assertTrue(assertTable.verifyAllHeaderLabel(expectedHeaderList), "ERROR> the headers are not displayed: " + expectedHeaderList.toString());
    }

    @And("^click \\[(Submit for Approval|Discard Changes|Save|Approve Changes)\\] button on policy detail page$")
    public void clickSubmitForApprovalButtonOnPolicyDetailPage(String buttonName) throws Exception {
        policyDetailsPage.buttonsMap.get(buttonName).click();
    }

    @Then("^verify the \"(Active|Upcoming|Expired)\" link is displayed on policy detail$")
    public void verifyTheLinkIsDisplayedOnPolicyDetail(String linkName) {
        boolean isLinkDisplayed;
        if (linkName.contains("Active"))
            isLinkDisplayed = policyDetailsPage.activeLink.controlIsDisplayed();
        else if (linkName.contains("Upcoming"))
            isLinkDisplayed = policyDetailsPage.upcomingLink.controlIsDisplayed();
        else
            isLinkDisplayed = policyDetailsPage.expiredLink.controlIsDisplayed();

        Assertions.assertTrue(isLinkDisplayed, "ERROR> the [" + linkName + "] is not displayed, please review it.");
    }

    @And("^click on (Premium Tracker) link on policy detail$")
    public void clickOnLinkOnPolicyDetail(String linkName) throws Exception {
        policyDetailsPage.premiumTrackerLink.click();
    }

    @Then("verify the headers should be displayed in the Premium Tracker table")
    public void verifyTheHeadersShouldBeDisplayedInThePremiumTrackerTable(List<String> expectedHeaderList) throws Exception {
        Assertions.assertTrue(policyDetailsPage.premiumTrackerTable.verifyAllHeaderLabel(expectedHeaderList), "ERROR> the headers are not displayed: " + expectedHeaderList.toString());
    }

    @And("^verify if the next values (are|are not) displayed on (Pet Detail Table|Upcoming Pet Detail Table)$")
    public void verifyIfTheNextValuesAreDisplayedOnPetDetailTable(String verification, String site, List<String> expectedValuesTable) throws Exception {
        Table assertTable = site.contains("Upcoming") ? policyDetailsPage.activeSecondPetDetailTable : policyDetailsPage.activePetDetailTable;
        for (String value : expectedValuesTable) {
            if (verification.contains("are not")) {
                Assertions.assertFalse(assertTable.checkIfValueIsDisplayedInTable(value), "ERROR> the headers are displayed: " + value);
            } else {
                Assertions.assertTrue(assertTable.checkIfValueIsDisplayedInTable(value), "ERROR> the headers are not displayed: " + value);
            }
        }

    }


    @And("verify the Premium Tracker table in policy detail")
    public void verifyThePremiumTrackerTableInPolicyDetail(List<PremiumTrackerEntity> tableDataExpectedResult) throws Exception {
        int cpId = 0;
        int effectiveOn = 1;
        int endOn = 2;
        int netPremium = 3;
        int billedPremium = 4;
        String ignore = "IGNORE";
        boolean isTableEqual = true;
        String msgError = "";
        List<List<String>> tableActualResult = policyDetailsPage.premiumTrackerTable.getTableSpecialsValue();
        // we start from 1 because the posotion 0 is the name of columns
        for (int i = 0; i < tableDataExpectedResult.size(); i++) {
            PremiumTrackerEntity expected = tableDataExpectedResult.get(i);
            List<String> actual = tableActualResult.get(i);

            actual.set(cpId, expected.getCpId().contains(ignore) ? ignore : actual.get(cpId));
            actual.set(effectiveOn, expected.getEffectiveOn().contains(ignore) ? ignore : actual.get(effectiveOn));
            actual.set(endOn, expected.getEndOn().contains(ignore) ? ignore : actual.get(endOn));
            actual.set(netPremium, expected.getNetPremium().contains(ignore) ? ignore : actual.get(netPremium));
            actual.set(billedPremium, expected.getBilledPremium().contains(ignore) ? ignore : actual.get(billedPremium));

            if (!actual.get(cpId).contains(expected.getCpId()) ||
                    !actual.get(effectiveOn).contains(expected.getEffectiveOn()) ||
                    !actual.get(endOn).contains(expected.getEndOn()) ||
                    !actual.get(netPremium).contains(expected.getNetPremium()) ||
                    !actual.get(billedPremium).contains(expected.getBilledPremium())) {

                msgError = msgError + "\nERROR! the row [" + i + "] has different values: " +
                        "\nthe actual value: [ " + actual.get(cpId) + " | " + actual.get(effectiveOn) + " | " + actual.get(endOn) + " | " + actual.get(netPremium) + " | " + actual.get(billedPremium) + " ]" +
                        "\nthe expected value: [ " + expected.getCpId() + " | " + expected.getEffectiveOn() + " | " + expected.getEndOn() + " | " + expected.getNetPremium() + " | " + expected.getBilledPremium() + " ]";

                isTableEqual = false;
            }

        }
        Assertions.assertTrue(isTableEqual, "ERROR the values in product table are not the same: " + msgError);
    }

    @DataTableType
    public PremiumTrackerEntity getPremiumTrackerEntity(Map<String, String> data) {
        PremiumTrackerEntity entity = new PremiumTrackerEntity();
        entity.setCpId(this.replaceConfigurationValues(data.get("CP Id")))
                .setEffectiveOn(this.replaceConfigurationValues(data.get("Effective On")))
                .setEndOn(this.replaceConfigurationValues(data.get("End on")))
                .setNetPremium(this.replaceConfigurationValues(data.get("Net Premium")))
                .setBilledPremium(this.replaceConfigurationValues(data.get("Billed Premium")));

        return entity;
    }

    @DataTableType
    public TransactionTypeEntity getTransactionTypeEntity(Map<String, String> data) {
        TransactionTypeEntity entity = new TransactionTypeEntity();
        entity.setTransactionType(this.replaceConfigurationValues(data.get("Transaction Type")))
                .setPaymentType(this.replaceConfigurationValues(data.get("Payment Type")))
                .setDescription(this.replaceConfigurationValues(data.get("Description")))
                .setCreatedOn(this.replaceConfigurationValues(data.get("Created On")))
                .setAmount(this.replaceConfigurationValues(data.get("Amount")))
                .setBalance(this.replaceConfigurationValues(data.get("Balance")));

        return entity;
    }

    @And("^get the CP ID from (Active|Upcoming|Expired) to (.*) on policy detail page$")
    public void getTheCPIDFromActiveToVariablePolicyDetailPage(String type, String variableName) throws Exception {
        CommonValues.variables.put(variableName, policyDetailsPage.getTheCpId(type));
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variableName) + "] in [" + variableName + "]");
    }


    @And("verify the Cancellation Detail row with Pet Name: {string} in policy detail page")
    public void verifyTheCancellationDetailRowWithPetNameInPolicyDetailPage(String petName, String expectedMessage) throws Exception {
        petName = this.replaceConfigurationValues(petName);
        String actualResult = policyDetailsPage.getCancelDetailMessageInTable(petName);
        expectedMessage = this.replaceConfigurationValues(expectedMessage);
        Assertions.assertTrue(actualResult.contains(expectedMessage), "ERROR the expected: [" + expectedMessage + "] vs actual [" + actualResult + "]");
    }

    @And("verify the values for next controls in policy detail")
    public void verifyTheValuesForNextControlsInPolicyDetail(Map<String, String> expectedData) throws Exception {
        for (String expectedControl : expectedData.keySet()
        ) {
            String actualResult = policyDetailsPage.getValueFromControl(expectedControl);
            Assertions.assertTrue(actualResult.contains(this.replaceConfigurationValues(expectedData.get(expectedControl))),
                    "ERROR> control: [" + expectedControl + "] actual result: [" + actualResult + "] vs expected result: [" + this.replaceConfigurationValues(expectedData.get(expectedControl)) + "]");
        }
    }

    @When("Click on Certificate Invoice link on Transactions table")
    public void clickOnCertificateInvoiceLinkOnTransactionsTable() throws Exception {
        policyDetailsPage.certificateInvoiceLink.click();
    }

    @And("verify the Transactions Table in policy detail page")
    public void verifyTheTransactionsTableInPolicyDetail(List<TransactionTypeEntity> tableDataExpectedResult) throws Exception {
        int transactionType = 0;
        int paymentType = 1;
        int description = 2;
        int createdOn = 3;
        int amount = 4;
        int balance = 5;
        String ignore = "IGNORE";
        boolean isTableEqual = true;
        String msgError = "";
        List<List<String>> tableActualResult = policyDetailsPage.transactionTypeTable.getTableSpecialsValue();

        // we start from 1 because the posotion 0 is the name of columns
        for (int i = 1; i < tableDataExpectedResult.size(); i++) {
            TransactionTypeEntity expected = tableDataExpectedResult.get(i);
            List<String> actual = tableActualResult.get(i);

            actual.set(transactionType, expected.getTransactionType().contains(ignore) ? ignore : actual.get(transactionType));
            actual.set(paymentType, expected.getPaymentType().contains(ignore) ? ignore : actual.get(paymentType));
            actual.set(description, expected.getDescription().contains(ignore) ? ignore : actual.get(description));
            actual.set(createdOn, expected.getCreatedOn().contains(ignore) ? ignore : actual.get(createdOn));
            actual.set(amount, expected.getAmount().contains(ignore) ? ignore : actual.get(amount));
            actual.set(balance, expected.getBalance().contains(ignore) ? ignore : actual.get(balance));

            if (!actual.get(transactionType).contains(expected.getTransactionType()) ||
                    !actual.get(paymentType).contains(expected.getPaymentType()) ||
                    !actual.get(description).contains(expected.getDescription()) ||
                    !actual.get(createdOn).contains(expected.getCreatedOn()) ||
                    !actual.get(amount).contains(expected.getAmount()) ||
                    !actual.get(balance).contains(expected.getBalance())) {

                msgError = msgError + "\nERROR! the row [" + i + "] has different values: " +
                        "\nthe actual value: [ " + actual.get(transactionType) + " | " + actual.get(paymentType) + " | " + actual.get(description) + " | " + actual.get(createdOn) + " | " + actual.get(amount) + " | " + actual.get(balance) + " ]" +
                        "\nthe expected value: [ " + expected.getTransactionType() + " | " + expected.getPaymentType() + " | " + expected.getDescription() + " | " + expected.getCreatedOn() + " | " + expected.getAmount() + " | " + expected.getBalance() + " ]";

                isTableEqual = false;
            }

        }
        Assertions.assertTrue(isTableEqual, "ERROR the values in product table are not the same: " + msgError);
    }

    @And("verify the message is displayed in Upcoming Section")
    public void verifyTheMessageIsDisplayedInUpcomingSection(String message) throws Exception {
        String actualResult = policyDetailsPage.changesUpcomingLabel.getText();
        Assertions.assertTrue(actualResult.contains(message), "ERROR!  the actual result: [ " + actualResult + "] does not contain expected result: [" + message + "]");
    }

    @Then("I verify  {string} display on the  policy term")
    public void iVerifyDisplayOnThePolicyTerm(String expectedResult) throws Exception {
        if (policyDetailsPage.resultLabels.containsKey(expectedResult)) {
            Assertions.assertTrue(policyDetailsPage.resultLabels.get(expectedResult).getText().contains(this.replaceConfigurationValues(expectedResult)),
                    "ERROR! the value : [" + this.replaceConfigurationValues(expectedResult) + "] is not displayed in the notes Activated by label");
        }

    }

    @And("verify premium should be displayed as per {}")
    public void verifyPremiumShouldDisplayed(String value) throws Exception {
        Assertions.assertTrue(policyMakeChangesPage.premium.getText().contains(this.replaceConfigurationValues(value)), "ERROR! the Monthly Premium : [" + this.replaceConfigurationValues(value) + "] is not same after applied discount");
    }

    @And("I select {string} under Policy Actions drop down")
    public void iSelectUnderPolicyActionsDropDown(String option) throws Exception {
        policyDetailsPage.policyCancelButton.click();
    }

    @And("I select {string} option under Cancel Reason on Cancel Policy Page")
    public void iSelectOptionUnderCancelReasononCancelPolicyPage(String option) throws Exception {
        policyCancelPage.cancelReasonDropdown.selectValueContainsOption(option);
    }

    @And("I select {string} option under Cancel Type on Cancel Policy Page")
    public void iSelectOptionUnderCancelTypeOnCancelPolicyPage(String option) throws Exception {
        policyCancelPage.cancelTypeDropdown.selectValueContainsOption(option);
    }

    @Then("^I click \\[(Preview|Submit)\\] Button on Cancel Policy Page$")
    public void iClickButtonOnCancelPolicyPage(String value) throws Exception {

        policyCancelPage.buttonsMap.get(value).controlIsDisplayed(5);
        policyCancelPage.buttonsMap.get(value).click();
    }

    @And("I Enter {string} to note section on Cancel Policy Page")
    public void iEnterToNoteSectionOnCancelPolicyPage(String value) throws Exception {
        policyCancelPage.notesTextBox.setText(this.replaceConfigurationValues(value));
    }


    @And("I verify {string} is displayed on Policy Details Page")
    public void iVerifyIsDisplayedOnPolicyDetailsPage(String value) throws Exception {
        Assertions.assertTrue(policyDetailsPage.partnerLabel.getText().contains(this.replaceConfigurationValues(value)), "ERROR! the PetPartners : [" + this.replaceConfigurationValues(value) + "] is not displayed on Policy Details Page");
    }

    @And("click on view customer icon under Action")
    public void clickOnViewCustomerIconUnderAction() throws Exception {
        policyDetailsPage.viewCustomerIconInActionsLink.click();
    }

    @And("I get the value of {string} in the variable: {}")
    public void iGetTheValueOfInTheVariableSoldBy(String control, String variableName) throws Exception {
        String actualResult = policyDetailsPage.getValueFromControl(control);
        CommonValues.variables.put(variableName, actualResult);
        Logger.log(Level.INFO, this.getClass().getName() + "> save the value: [" + CommonValues.variables.get(variableName) + "] in [" + variableName + "]");

    }

    @And("I click on [Edit Payment] button on the policy details page")
    public void iClickOnEditPaymentButtonOnThePolicyDetailsPage() throws Exception {
        policyDetailsPage.editPaymentButton.click();
    }

    @And("I click {string} button on the Edit payment information table")
    public void iClickButtonOnTheEditPaymentInformationTable(String option) throws Exception {
        editPaymentPage.editPaymentButtons.get(option).click();
    }

    @When("I fill out the Payment option details")
    public void iFillOutThePaymentOptionDetails(PolicyPaymentEntity paymentEntity) throws Exception {

        if ((!paymentEntity.getPaymentType().isEmpty()))
            editPaymentPage.paymentType.selectValueContainsOption(this.replaceConfigurationValues(this.replaceConfigurationValues(paymentEntity.getPaymentType())));
        if (!paymentEntity.getCreditCardType().isEmpty())
            editPaymentPage.cardType.selectValueContainsOption(this.replaceConfigurationValues(paymentEntity.getCreditCardType()));
        if (!paymentEntity.getCardNumber().isEmpty())
            editPaymentPage.cardNumberTextBox.setText(this.replaceConfigurationValues(paymentEntity.getCardNumber()));
        if (!paymentEntity.getExpirationDate().isEmpty())
            editPaymentPage.expirationDateTextBox.setTextAndEnter(this.replaceConfigurationValues(paymentEntity.getExpirationDate()));
        if (!paymentEntity.getCvv().isEmpty())
            editPaymentPage.cvvTextBox.setText(this.replaceConfigurationValues(paymentEntity.getCvv()));
    }

    @DataTableType
    public PolicyPaymentEntity getEnntity(Map<String, String> paymentEntity) {

        PolicyPaymentEntity payment = new PolicyPaymentEntity();
        if (paymentEntity.containsKey("Payment Type"))
            payment.setPaymentType(paymentEntity.get("Payment Type"));
        if (paymentEntity.containsKey("Credit Card Type"))
            payment.setCreditCardType(paymentEntity.get("Credit Card Type"));
        if (paymentEntity.containsKey("Card Number"))
            payment.setCardNumber(paymentEntity.get("Card Number"));
        if (paymentEntity.containsKey("Expiration Date"))
            payment.setExpirationDate(paymentEntity.get("Expiration Date"));
        if (paymentEntity.containsKey("Cvv"))
            payment.setCvv(paymentEntity.get("Cvv"));
        return payment;
    }

    @And("I click on [{}] button on the Edit Payment page")
    public void iClickOnButtonOnTheEditPaymentPage(String button) throws Exception {
        if (button.contains("Save")){
            editPaymentPage.saveButton.click();
        } else if (button.contains("Cancel")) {
            editPaymentPage.cancelButton.click();

        }
    }
    @Then("I verify hold payment status should be {string}")
    public void iVerifyHoldPaymentStatusShouldBe(String expectedResult) throws Exception {
        policyDetailsPage.holdPaymentSelect.controlIsDisplayed(20);
        String actualResult = policyDetailsPage.holdPaymentSelect.getTextOptionSelected();
        Assertions.assertEquals(expectedResult, actualResult, "ERROR! the status values is  different, actual: " + actualResult + " vs expected: " + expectedResult);
    }

    @When("I select the value [{}] on Followup details page")
    public void iSelectTheValueOnFollowupDetailsPage(String value) throws Exception {
        followUpsPage.complainTypeDropDown.selectValueContainsOption(value);
    }

    @And("I click on [Add New] button on the Follow-Up\\(s) tab")
    public void iClickOnAddNewButtonOnTheFollowUpSTab() throws Exception {
        followUpsPage.addNewButtonFollowUps.click();
    }
    @When("I select the value [{}] on the follow up type dropdown")
    public void iSelectTheValueOnTheFollowUpTypeDropdown(String value) throws Exception {
     followUpsPage.followupTypeDropDown.selectValueContainsOption(value);
    }

    @And("I click on {string} button on the Follow ups page")
    public void iClickOnButtonOnTheFollowUpsPage(String button) throws Exception {
        if (button.contains("Save")){
            followUpsPage.saveButtonFollowUpPage.click();
        } else if (button.contains("Cancel")) {
            followUpsPage.cancelButtonFollowUpPage.click();

        }
    }

    @And("click on {string} in the result search")
    public void clickOnInTheResultSearch(String value) throws Exception {
        policySearchSection.searchResultTable.clickOnLinkCellContains(this.replaceConfigurationValues(value));
    }
}