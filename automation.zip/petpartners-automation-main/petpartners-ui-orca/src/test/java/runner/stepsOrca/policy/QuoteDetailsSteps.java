package runner.stepsOrca.policy;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.policy.PolicyChangesForNewPet;
import pages.orca.quote.QuoteDetailsPage;
import runner.stepsOrca.BaseSteps;

import java.util.List;

public class QuoteDetailsSteps extends BaseSteps {
    QuoteDetailsPage quoteDetailsPage = new QuoteDetailsPage();

    PolicyChangesForNewPet policyChangesForNewPet =new PolicyChangesForNewPet();

    @When("click on MakeChanges button in quote detail page")
    public void clickOnMakeChangesButtonInQuoteDetailPage() throws Exception {
        quoteDetailsPage.petTableMakeChangesButton.click();
    }

    @Then("verify updated pet details in Quote details page")
    public void verifyUpdatedPetDetailsInQuoteDetailsPage(List<String> expectedPetDetails) throws Exception {
        for (String sElement : expectedPetDetails) {
            Assertions.assertTrue(quoteDetailsPage.covPetDetailsTable.checkIfValueIsDisplayedInTable(sElement),
                    "ERROR: " + sElement + " is not displayed");
        }
    }

    @Then("verify updated coverage and product details in Quote details page")
    public void verifyUpdatedCoverageAndProductDetailsInQuoteDetailsPage(List<String> expectedCovProdDetails) throws Exception {
        for (String sElement : expectedCovProdDetails) {
            Assertions.assertTrue(quoteDetailsPage.coverageDetailsTable.checkIfValueIsDisplayedInTable(sElement),
                    "ERROR: " + sElement + " is not displayed");
        }
    }
    @And("^click on \\[(Return to Policy|Save)\\] button in Quote Details Page$")
    public void clickOnReturnToPolicyButtonInQuoteDetailsPage(String controlName) throws Exception {
        if (controlName.contains("Save")){
            quoteDetailsPage.saveButton.controlIsDisplayed();
            quoteDetailsPage.saveButton.click();
        }else{
            quoteDetailsPage.returnToPolicyButton.controlIsDisplayed();
            quoteDetailsPage.returnToPolicyButton.click();
        }
    }

    @And("^select \\[(New Pet|Existing Pet)\\] option in \\+Add Pet button in quote detail page$")
    public void selectNewPetButtonQuoteDetail(String optionName) throws Exception {
        quoteDetailsPage.addPetButton.click();
        if (optionName.contains("New Pet")) {
            quoteDetailsPage.addPetButton.controlIsDisplayed();
            quoteDetailsPage.newPetOption.click();
        }else{
            quoteDetailsPage.existingPetOption.controlIsDisplayed();
        }

    }

    @And("verify the Pet Name: {string} is displayed quote detail page")
    public void verifyThePetNameIsDisplayedQuoteDetailPage(String expectedPetName) throws Exception {
        expectedPetName=this.replaceConfigurationValues(expectedPetName);
        boolean isDisplayed=quoteDetailsPage.covPetDetailsTable.checkIfValueIsDisplayedInTable(expectedPetName);
        Assertions.assertTrue(isDisplayed,"ERROR: the pet name: ["+expectedPetName+"] is not displayed in the table in quote detail - coverage table");
    }

    @And("click on (Cancel Coverage) button for Pet Name {string} in quote detail page")
    public void clickOnCancelCoverageButtonForPetNameInQuoteDetailPage(String petName) throws Exception {
        petName=this.replaceConfigurationValues(petName);
        quoteDetailsPage.clickCancelButtonInRow(petName);
    }

    @And("verify the message is displayed in quote detail for {string}")
    public void verifyTheMessageIsDisplayedInQuoteDetailFor(String petName,String expectedResult) throws Exception {
        petName=this.replaceConfigurationValues(petName);
        expectedResult= this.replaceConfigurationValues(expectedResult);
        String actualResult=quoteDetailsPage.getMessageInPetNameRow(petName);
        Assertions.assertEquals(expectedResult,actualResult,"ERROR the actual result: ["+actualResult+"]  is different to expected result: ["+expectedResult+"]");

    }

    @And("^I click (Save|Return Policy) button on the quote details page$")
    public void iClickStringButtonOnTheQuoteDetailsPage(String value) throws Exception {
        if(value.contains("Save")){
            policyChangesForNewPet.saveButtonButton.click();
        } else if (value.contains("Return Policy")) {
            policyChangesForNewPet.returnPolicyButton.controlIsDisplayed(5);
            policyChangesForNewPet.returnPolicyButton.click();
        }
    }

    @And("I select {string} under the Group dropdown on the Quote Details page")
    public void iSelectUnderTheGroupDropdownOnTheQuoteDetailsPage(String value) throws Exception {
        quoteDetailsPage.groupDropDown.selectValueContainsOption(value);
    }
}