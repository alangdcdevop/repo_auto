package runner.stepsOrca.vet;

import configuration.CommonValues;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.orca.vet.VetDashboardPage;
import pages.orca.vet.VetDetailsPage;
import runner.stepsOrca.BaseSteps;
import utils.Level;
import utils.Logger;

import java.util.List;
import java.util.Map;

public class VetDetailsSteps extends BaseSteps {
    VetDashboardPage vetDashboardPage = new VetDashboardPage();
    VetDetailsPage vetDetailsPage = new VetDetailsPage();

    @And("^All the below field should be displayed on the 'Vet Dashboard' page$")
    public void allTheBelowFieldShouldBeDisplayedOnTheVetDashboardPage(List<String> fieldName) throws Throwable {
        for (String sFieldName : fieldName) {
            if( fieldName.contains("State")) {
                Assertions.assertTrue( vetDashboardPage.stateProvinceDropDown.controlIsDisplayed(),"Error: "+sFieldName+" is not displayed");
            }else if( fieldName.contains("Show All Duplicates")) {
                Assertions.assertTrue( vetDashboardPage.checkboxMap.get(fieldName).controlIsDisplayed(),"Error: "+sFieldName+" is not displayed");
            }else if( fieldName.contains("Clear") || fieldName.contains("Run Search")) {
                Assertions.assertTrue( vetDashboardPage.buttonMap.get(fieldName).controlIsDisplayed(),"Error: "+sFieldName+" is not displayed");
            }else{
                Assertions.assertTrue( vetDashboardPage.textBoxMap.get(fieldName).controlIsDisplayed(),"Error: "+sFieldName+" is not displayed");
            }
        }
    }

    @When("I clicks on {string} button under Actions column for any record in the grid")
    public void iClicksOnButtonUnderActionsColumnForAnyRecordInTheGrid(String buttonName) throws Throwable {
        vetDashboardPage.vetsTable.clickOnLinkCell(buttonName);
    }

    @Then("^all the below field should be displayed under 'Overview' section on 'Vet Details' page$")
    public void allTheBelowFieldShouldBeDisplayedUnderOverviewSectionOnVetDetailsPage(List<String> fieldName) throws Throwable {
        Assertions.assertTrue(vetDetailsPage.overviewSection.controlIsDisplayed(),"Error: "+vetDetailsPage.overviewSection.getText()+" is not displayed");
        for (String sFieldName : fieldName) {
            if( fieldName.contains("State/Province")) {
                Assertions.assertTrue(vetDetailsPage.stateProvinceDropDown.controlIsDisplayed(),"Error: "+sFieldName+" is not displayed");
            }else if( fieldName.contains("Pref. Delivery Method")) {
                 Assertions.assertTrue(vetDetailsPage.prefDeliveryMethodDropDown.controlIsDisplayed(),"Error: "+sFieldName+" is not displayed");
            } else if( fieldName.contains("Save") || fieldName.contains("Cancel")) {
                Assertions.assertTrue(vetDetailsPage.buttonMap.get(sFieldName).controlIsDisplayed(),"Error: "+sFieldName+" is not displayed");
            }else{
                Assertions.assertTrue( vetDashboardPage.textBoxMap.get(fieldName).controlIsDisplayed(),"Error: "+sFieldName+" is not displayed");
            }
        }
    }

    @And("I entered {string} in {string} TextBox on Vet Details page")
    public void iEnteredInTextBoxOnVetDetailsPage(String value, String fieldName) throws Throwable {
        if (fieldName.contains("Fax")) {
            vetDetailsPage.textBoxMap.get(fieldName).click();
            vetDetailsPage.textBoxMap.get(fieldName).setText(this.replaceConfigurationValues(value));
        } else {
            vetDetailsPage.textBoxMap.get(fieldName).clearSetText(this.replaceConfigurationValues(value));
        }
    }

    @When("I clicks on {string} button on 'Vet Details' page")
    public void iClicksOnButtonOnVetDetailsPage(String buttonName) throws Throwable{
        vetDetailsPage.buttonMap.get(buttonName).click();
    }

    @Then("Success message {string} is displayed on the 'Vet Details' page")
    public void successMessageIsDisplayedOnTheVetDetailsPage(String message) throws Throwable{
        Assertions.assertTrue(vetDetailsPage.successMessage.controlIsDisplayed(),"Error: "+vetDetailsPage.successMessage.getText()+" is not displayed");
        Assertions.assertTrue(vetDetailsPage.successMessage.getText().trim().contains(message) ,"Error: the message: ["+message+"] is not displayed");
    }

    @And("Click on {string} button after entering the newly created Vet name in the 'Name' TextBox")
    public void iClickOnButtonAfterEnteringTheNewlyCreatedVetNameInTheNameTextbox(String buttonName) throws Throwable {
        vetDashboardPage.nameTextBox.setText(CommonValues.variables.get("Vet Name"));
        vetDashboardPage.stateProvinceDropDown.selectValue(CommonValues.variables.get("StateProvince"));
        vetDashboardPage.buttonMap.get(buttonName).click();
    }

    @And("Searched Result - 'Newly created Vet', are displayed in a grid in below columns details")
    public void searchResultsNewVetAreDisplayedInAGridWithColumnsDetails(List<String> columnName) throws Throwable {
        Assertions.assertTrue(vetDashboardPage.vetsTable.verifyAllHeaderLabel(columnName), "Some Column Name in the table is missing, actual [" + vetDashboardPage.vetsTable.getAllHeaderLabel().toString() + " vs expected [" + columnName.toString() + "]");
        Assertions.assertTrue(vetDashboardPage.vetsTable.checkIfValueIsDisplayedInTable(CommonValues.variables.get("Vet Name")), "ERROR! the value : [" + CommonValues.variables.get("Vet Name") + "] is not displayed in the grid");
    }

    @And("Click on {string} button after entering the Vet name {string} and select state {string}")
    public void iClickOnButtonAfterEnteringTheVetNameInTheNameTextBox(String buttonName, String vetName,String stateName) throws Throwable {
        vetDashboardPage.nameTextBox.setText(vetName);
        vetDashboardPage.stateProvinceDropDown.selectValueContainsOption(stateName);
        vetDashboardPage.buttonMap.get(buttonName).click();
    }

    @And("Searched Result {string} are displayed in a grid in below columns details")
    public void searchResultsAreDisplayedInAGridWithColumnsDetails(String searchedName, List<String> columnName) throws Throwable {
        Assertions.assertTrue(vetDashboardPage.vetsTable.verifyAllHeaderLabel(columnName),
                "Some Column Name in the table is missing, actual [" + vetDashboardPage.vetsTable.getAllHeaderLabel().toString() + " vs expected [" + columnName.toString() + "]");
        Assertions.assertTrue(vetDashboardPage.vetsTable.checkIfValueIsDisplayedInTable(searchedName),
                "ERROR! the value : [" + searchedName + "] is not displayed in the grid");
    }


    @And("I select {string} option in [Pref. Delivery Method] dropdown in view detail page")
    public void iSelectOptionInPrefDeliveryMethodDropdownInViewDetailPage(String option) throws Exception {
        vetDetailsPage.prefDeliveryMethodDropDown.selectValue(option);
    }


    @And("I entered {string} in Fax TextBox on Vet Details page")
    public void iEnteredInFaxTextBoxOnVetDetailsPage(String faxNumber) throws Exception {
       vetDetailsPage.faxTextBox.clearSetText(faxNumber);
        vetDetailsPage.faxTextBox.setText(faxNumber);
        vetDetailsPage.faxTextBox.getText();
    }

    @And("verify the next values in the next field in Vet Detail Page")
    public void verifyTheNextValuesInTheNextFieldInVetDetailPage(Map<String,String> expectedValues) throws Exception {
        for (String controlName:expectedValues.keySet()
             ) {
            String actualResult = vetDetailsPage.textBoxMap.get(controlName).getTextAttribute("value");
            String expectedResult = this.replaceConfigurationValues(expectedValues.get(controlName));
            Logger.log(Level.INFO, this.getClass().getName() + "Assert> the actual["+actualResult+"] vs expected ["+expectedResult+"] in the control: "+controlName + this.getClass().getSimpleName());
            Assertions.assertEquals(expectedResult,actualResult,"ERROR! the actual["+actualResult+"] vs expected ["+expectedResult+"] are not equal in the control: "+controlName);
        }


    }

    @Then("I get all the values of [Pref Delivery] picklist in {string}")
    public void iGetAllTheValuesOfPrefDeliveryPicklistIn(String variable) throws Exception {
        String actualResult =vetDetailsPage.prefDeliveryMethodDropDown.getAllValuesCommaSeparated();
        CommonValues.variables.put(variable,actualResult);
        Logger.log(Level.INFO,this.getClass().getName()+" variable: ["+variable+"] value: ["+CommonValues.variables.get(variable)+"]");
    }
}