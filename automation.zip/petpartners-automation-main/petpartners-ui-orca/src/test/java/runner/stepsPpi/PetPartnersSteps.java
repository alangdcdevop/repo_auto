package runner.stepsPpi;


import configuration.CommonValues;
import configuration.Configuration;
import entities.ppi.ClaimEntity;
import entities.ppi.CompleteEnrollmentEntity;
import entities.ppi.GetQuoteEntity;
import gifBuilder.ScreenShot;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.interactions.Actions;
import pages.ppi.*;
import pages.ppi.claims.ClaimPage;
import pages.ppi.home.HomePage;
import pages.ppi.landsOnPolicy.LeftMenuSection;
import runner.stepsOrca.BaseSteps;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.List;
import java.util.Map;

public class PetPartnersSteps extends BaseSteps {

    MainPage mainPage= new MainPage();
    GetQuotePage getQuotePage =  new GetQuotePage();
    SelectTestCoverage selectTestCoverage= new SelectTestCoverage();
    CompleteYourEnrollment completeYourEnrollment= new CompleteYourEnrollment();
    CongratulationEnrollment congratulationEnrollment= new CongratulationEnrollment();
    LoginPage loginPage = new LoginPage();
    HomePage homePage = new HomePage();
    ClaimPage claimPage = new ClaimPage();
    CreateAccountPage createAccountPage = new CreateAccountPage();
    LeftMenuSection leftMenuSection= new LeftMenuSection();

    @Given("I go to PPI PetPartners")
    public void iGoToPetPartners() {
        ScreenShot.addScreen(this.getClass().getName()+"> Go to URL: "+Configuration.WEB_UI_PPI);
        Logger.log(Level.INFO,this.getClass().getName()+"> Go to URL: "+Configuration.WEB_UI_PPI);
        Session.getInstance().getDriver().get(Configuration.WEB_UI_PPI);
        ScreenShot.addScreen(this.getClass().getName()+"> Go to URL: "+Configuration.WEB_UI_PPI);
    }

    @And("I fill the get quote on petpartners page")
    public void iFillTheGetQuoteOnPetpartnersPage(GetQuoteEntity getQuoteEntity) throws Exception {
        // commented becasuse qas envrionemtn has PPI directly to /enroll
        // mainPage.getQuoteButton.click();
         getQuotePage.fillGetQuoteForm(getQuoteEntity);
         Thread.sleep(15000);
    }

    @DataTableType
    public GetQuoteEntity quoteEntityEntry(Map<String,String> entry){
        return new GetQuoteEntity(this.replaceConfigurationValues(entry.get("petName")),
                                  this.replaceConfigurationValues(entry.get("zipCode")),
                                  this.replaceConfigurationValues(entry.get("dogOrCat")),
                                  this.replaceConfigurationValues(entry.get("petBreed")),
                                  this.replaceConfigurationValues(entry.get("petAge")),
                                  this.replaceConfigurationValues(entry.get("yesOrNoDiagnose")),
                                  this.replaceConfigurationValues(entry.get("email")));
    }


    @And("I complete enrollment process on petpartners page")
    public void iCompleteEnrollmentProcessOnPetpartnersPage(CompleteEnrollmentEntity completeEnrollmentEntity) throws Exception {
        this.scrollUp();
        selectTestCoverage.addToCartButton.controlIsClickable();
        selectTestCoverage.addToCartButton.click();
        completeYourEnrollment.fillCompleteYourEnrollment(completeEnrollmentEntity);
        Thread.sleep(1000);
    }

    @DataTableType
    public CompleteEnrollmentEntity enrollmentEntityEntry(Map<String,String> entry){
        CompleteEnrollmentEntity entity = new CompleteEnrollmentEntity();
        entity.setFirstName(this.replaceConfigurationValues(entry.get("firstName")))
                .setLastName(this.replaceConfigurationValues(entry.get("lastName")))
                .setAddress(this.replaceConfigurationValues(entry.get("address")))
                .setAptSuite(this.replaceConfigurationValues(entry.get("apt suite")))
                .setPhoneNumber(this.replaceConfigurationValues(entry.get("phone number")))
                .setNameOnCard(this.replaceConfigurationValues(entry.get("name on card")))
                .setCardNumber(this.replaceConfigurationValues(entry.get("card number")))
                .setExpiresMM(this.replaceConfigurationValues(entry.get("expires mm")))
                .setExpireYYYY(this.replaceConfigurationValues(entry.get("expires yyyy")))
                .setCvc(this.replaceConfigurationValues(entry.get("cvc")));

        if (entry.containsKey("email"))
            entity.setEmailAddress(this.replaceConfigurationValues(entry.get("email")));

        return entity;

    }

    @And("I get the policy number in Congratulation page on {}")
    public void iGetThePolicyNumberInCongratulationPageOnVariable(String variable ) throws Exception {
        CommonValues.variables.put(variable,congratulationEnrollment.policyNumber.getText().trim().replace("Policy","").replace(" ",""));
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }

    @Given("I go to url PetPartners{}")
    public void iGoToPetPartnersPortal(String  url) {
        String urlFinal= (Configuration.WEB_UI_PPI+url).replace("enroll","");
        Logger.log(Level.INFO,this.getClass().getName()+"> Go to URL: "+urlFinal);
        Session.getInstance().getDriver().get(urlFinal);
    }

    @And("login on petpartners portal")
    public void loginOnPetpartnersPortal() throws Exception {
        loginPage.login(Configuration.USER,Configuration.PASSWORD);
    }

    @And("I click on submit claim link on home page")
    public void iClickOnSubmitClaimLinkOnHomePage() throws Exception {
        homePage.submitClaimLink.controlIsDisplayed();
        homePage.submitClaimLink.click();
        leftMenuSection.claimsMenu.click();
        Thread.sleep(10000);
    }

    @And("I fill the claim detail section")
    public void iFillTheClaimDetailSection(ClaimEntity claimEntity) throws Exception {
        claimPage.fillClaim(claimEntity);

    }
    @DataTableType
    public ClaimEntity claimEntityEntry(Map<String,String> entry){
        ClaimEntity entity = new ClaimEntity();
        entity.setSelectPolicy(this.replaceConfigurationValues(entry.get("Select Policy")))
                .setDoesYourPetHaveAdditional(this.replaceConfigurationValues(entry.get("Does you pet have additional insurance")))
                .setInjuryOrIllness(this.replaceConfigurationValues(entry.get("injury or illness")))
                .setTellUsMoreAboutInjury(this.replaceConfigurationValues(entry.get("Tell us more about the injury or illness")))
                .setWhenDidYuFirstNoticeSignDate(this.replaceConfigurationValues(entry.get("When did you first notice signs")))
                .setTreatmentStartDate(this.replaceConfigurationValues(entry.get("Treatment Start Date")))
                .setUploadFile(this.replaceConfigurationValues(entry.get("Upload File")));
        return entity;

    }

    @And("creating user on petparners")
    public void creatingUserOnPetparners(Map<String,String> credentials) throws Exception {
        loginPage.createAccountButton.click();
        createAccountPage.createAccount(this.replaceConfigurationValues(credentials.get("email")),
                                        this.replaceConfigurationValues(credentials.get("password")),
                                        this.replaceConfigurationValues(credentials.get("confirm password")));
        Thread.sleep(10000);

    }


    @And("I clear & complete enrollment process on petpartners page")
    public void iClearCompleteEnrollmentProcessOnPetpartnersPage(CompleteEnrollmentEntity completeEnrollmentEntity) throws Exception {
        selectTestCoverage.addToCartButton.click();
        completeYourEnrollment.firstNameTextBox.clear();
        completeYourEnrollment.lastNameTextBox.clear();
        completeYourEnrollment.addressTestBox.clear();
        completeYourEnrollment.phoneNumberTextBox.clear();
       completeYourEnrollment.fillCompleteYourEnrollment(completeEnrollmentEntity);
    }

    @And("get the claim number in {}")
    public void getTheClaimNumberInClaimNumber(String variable) throws Exception {
        Thread.sleep(15000);
        CommonValues.variables.put(variable,claimPage.getClaimNumber());
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }
    @And("click login button in the menu section")
    public void clickLoginButtonInTheMenuSection() throws Exception {
        mainPage.loginLink.click();
    }
    @And("create a new account on portal Login Page")
    public void createANewAccountOnPortalLoginPage(Map<String,String> values) throws Exception {
        loginPage.createAccountButton.click();
        createAccountPage.createAccount(this.replaceConfigurationValues(values.get("email")),
                this.replaceConfigurationValues(values.get("password")),
                this.replaceConfigurationValues(values.get("confirm password")));
    }

    @And("I select the available upgrades in coverage")
    public void iSelectTheAvailableUpgradesInCoverage(List<String> availableUpgradeOption) throws Exception {
        for (String option:availableUpgradeOption) {
            if (selectTestCoverage.radioButtonMap.containsKey(option))
                selectTestCoverage.radioButtonMap.get(option).select();
            else
                throw new Exception("ERROR> the option: ["+option+"] does not exit in available upgrades section");
        }

    }

    @And("I click on any site out of modal")
    public void iClickOnAnySiteOutOfModal() {
        new Actions(Session.getInstance().getDriver()).moveByOffset(10,10).click().perform();
    }

    @And("I complete enrollment process on petpartners page after applied Discount")
    public void iCompleteEnrollmentProcessAfterAppliedDiscount(CompleteEnrollmentEntity completeEnrollmentEntity) throws Exception {
        //Thread.sleep(2000);
        completeYourEnrollment.firstNameTextBox.waitUntilControlIsDisplayed();
       completeYourEnrollment.fillCompleteYourEnrollment(completeEnrollmentEntity);
        Thread.sleep(1000);
    }

    @And("I get the price in Congratulation page on {}")
    public void iGetThePriceInCongratulationPageOnVariable(String variable) throws Exception {
        CommonValues.variables.put(variable,congratulationEnrollment.petOverviewPrice.getText().trim().replace("Price","").replace(" ",""));
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }

    @And("I apply Partner Code {string} as a Group Code on petpartners page")
    public void iApplyPartnerCodeAsAGroupCode(String partnerCode) throws Exception{
        selectTestCoverage.addToCartButton.controlIsClickable();
        selectTestCoverage.addToCartButton.click();
        CommonValues.variables.put("monthlyPremiumBeforeDiscount",this.replaceConfigurationValues(completeYourEnrollment.premiumMonthly.getText().trim()));
        completeYourEnrollment.groupCodeTextBox.clearSetText(partnerCode.trim());
        completeYourEnrollment.applyButton.click();
        completeYourEnrollment.applyButton.waitUntilControlIsDisplayed();
        CommonValues.variables.put("discountApplied",this.replaceConfigurationValues(completeYourEnrollment.discount.getText().trim()));
        CommonValues.variables.put("monthlyPremiumAfterDiscount",this.replaceConfigurationValues(completeYourEnrollment.premiumMonthly.getText().trim()));
        Assertions.assertTrue(!CommonValues.variables.get("monthlyPremiumBeforeDiscount").equals(CommonValues.variables.get("monthlyPremiumAfterDiscount")),"Error: "+CommonValues.variables.get("monthlyPremiumBeforeDiscount")+" & "+CommonValues.variables.get("monthlyPremiumAfterDiscount")+" is not same");
    }
}

