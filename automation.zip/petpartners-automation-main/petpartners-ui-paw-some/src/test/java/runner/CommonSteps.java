package runner;

import configuration.CommonValues;
import configuration.Configuration;
import gifBuilder.ScreenShot;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.openqa.selenium.JavascriptExecutor;
import session.Session;
import utils.Level;
import utils.Logger;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class CommonSteps extends BaseSteps{
    @Given("open the PAW SOME PET web page")
    public void openTheAKCWebPage() {
        Logger.log(Level.INFO,this.getClass().getName()+"> Go to url: "+Configuration.WEB_URL);
        ScreenShot.addScreen(this.getClass().getName()+"> Go to url: "+Configuration.WEB_URL);
        Session.getInstance().getDriver().get(Configuration.WEB_URL);
        ScreenShot.addScreen(this.getClass().getName()+"> Go to url: "+Configuration.WEB_URL);
    }

    @And("i save the {} date on {} with format {}")
    public void iSaveTheCurrentDateOnCurrentDate(String date,String variable, String format) {
        if (date.equals("yesterday")){
            DateFormat dateFormat = new SimpleDateFormat(format);
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DATE, -1);
            CommonValues.variables.put(variable, dateFormat.format(cal.getTime()));
        }else{
            //current
            CommonValues.variables.put(variable, new SimpleDateFormat(format).format(new Date()));
        }
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }

    @And("i get a random value on {}")
    public void iGetARandomValueOnRANDOM(String variable) {
        CommonValues.variables.put(variable,new Date().getTime()+"");
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variable)+"] in ["+variable+"]");
    }

    @Given("open the url {string}")
    public void openTheUrl(String url) {
        ScreenShot.addScreen(this.getClass().getName()+"> Go to url: "+url);
        Session.getInstance().getDriver().get(url);
        Logger.log(Level.INFO,this.getClass().getName()+"> Go to url: "+url);
        ScreenShot.addScreen(this.getClass().getName()+"> Go to url: "+url);
    }

    @And("close browser")
    public void closeBrowser() throws InterruptedException {
        Thread.sleep(3000);
        Session.getInstance().closeSession();
        Thread.sleep(3000);
    }

    @And("close the tab {string}")
    public void closeTheTab(String tabTitle) throws Exception {
        List<String> tabList=new ArrayList<String>(Session.getInstance().getDriver().getWindowHandles());
        Map<String, Integer> titlePositionTab= new HashMap<>();
        for (int i=0;i<tabList.size();i++) {
            Session.getInstance().getDriver().switchTo().window(tabList.get(i));
            titlePositionTab.put(Session.getInstance().getDriver().getTitle(),i);
            Logger.log(Level.INFO,this.getClass().getName()+"> tabs: "+Session.getInstance().getDriver().getTitle());
        }
        if (!titlePositionTab.containsKey(this.replaceConfigurationValues(tabTitle)))
            throw new Exception("The tab name "+this.replaceConfigurationValues(tabTitle)+" does not exist! review if the tab name");

        Session.getInstance().getDriver().switchTo().window(tabList.get(titlePositionTab.get(this.replaceConfigurationValues(tabTitle))));
        Session.getInstance().getDriver().close();
        Session.getInstance().getDriver().switchTo().window(tabList.get(0));
        Logger.log(Level.INFO,this.getClass().getName()+"> current tab: "+Session.getInstance().getDriver().getTitle());
    }

    @And("go to the tab {string}")
    public void goToTheLinkForThePolicyNumber(String tabTitle) throws Exception {
        Thread.sleep(5000);
        List<String> tabList=new ArrayList<String>(Session.getInstance().getDriver().getWindowHandles());
        Map<String, Integer> titlePositionTab= new HashMap<>();
        Logger.log(Level.INFO,this.getClass().getName()+"> tabs: "+tabList.size());
        for (int i=0;i<tabList.size();i++) {
            Session.getInstance().getDriver().switchTo().window(tabList.get(i));
            titlePositionTab.put(Session.getInstance().getDriver().getTitle(),i);
            Logger.log(Level.INFO,this.getClass().getName()+"> tabs: "+Session.getInstance().getDriver().getTitle());
        }
        if (!titlePositionTab.containsKey(this.replaceConfigurationValues(tabTitle)))
            throw new Exception("The tab name "+this.replaceConfigurationValues(tabTitle)+" does not exist! review if the tab name");

        Session.getInstance().getDriver().switchTo().window(tabList.get(titlePositionTab.get(this.replaceConfigurationValues(tabTitle))));
        Logger.log(Level.INFO,this.getClass().getName()+"> current tab: "+Session.getInstance().getDriver().getTitle());
    }

    @And("I open a new tab with url {string}")
    public void iOpenANewTab(String url) throws InterruptedException {
        ScreenShot.addScreen(this.getClass().getName()+"> open new tab using the url: "+url);
        Logger.log(Level.INFO,this.getClass().getName()+"> open new tab using the url: "+url);
        Thread.sleep(2000);
        JavascriptExecutor jse = (JavascriptExecutor)Session.getInstance().getDriver();
        jse.executeScript("window.open()");
        List<String> tabList=new ArrayList<String>(Session.getInstance().getDriver().getWindowHandles());
        Session.getInstance().getDriver().switchTo().window(tabList.get(tabList.size()-1));
        Session.getInstance().getDriver().get(url);
        Thread.sleep(2000);
        ScreenShot.addScreen(this.getClass().getName()+"> open new tab using the url: "+url);
    }

}
