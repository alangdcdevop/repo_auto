package runner;

import configuration.CommonValues;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.pawsome.CongratulationEnrollmentPage;
import utils.Level;
import utils.Logger;

public class CongratulationSteps {
    CongratulationEnrollmentPage congratulationEnrollmentPage = new CongratulationEnrollmentPage();
    @Then("verify the {string} is displayed")
    public void verifyTheIsDisplayed(String message) {
        Assertions.assertTrue(congratulationEnrollmentPage.congratulationEnrollmentLabel.controlIsDisplayed(),"ERROR> the "+message+" is not displayed in congratulation page");
    }

    @And("verify the Portal Login is displayed on Congratulation Page")
    public void verifyThePortalLoginIsDisplayedOnCongratulationPage() {
        Assertions.assertTrue(congratulationEnrollmentPage.portalLoginButton.controlIsDisplayed(),"ERROR> the Portal Login is not displayed in congratulation page");

    }

    @And("click on Portal Login in Congratulation on Your enrollment page")
    public void clickOnPortalLoginInCongratulationOnYourEnrollmentPage() throws Exception {
        congratulationEnrollmentPage.portalLoginButton.click();
    }

    @And("I get the policy number in Congratulation page on {}")
    public void iGetThePolicyNumberInCongratulationPageOnPolicyNumber(String variableKey) throws Exception {
        CommonValues.variables.put(variableKey,congratulationEnrollmentPage.policyNumberLabel.getText().replace("Policy ",""));
        Logger.log(Level.INFO,this.getClass().getName()+"> save the value: ["+CommonValues.variables.get(variableKey)+"] in ["+variableKey+"]");
    }

    @And("the monthly total value should be {} in Congratulation Page")
    public void theMonthlyTotalValueShouldBeInCongratulationPage(String expectedResult) throws Exception {
        Assertions.assertTrue(congratulationEnrollmentPage.monthlyTotalLabel.getText().contains(expectedResult),
                "ERROR the cost for the policy should be : "+expectedResult+ "but it is "+congratulationEnrollmentPage.monthlyTotalLabel.getText()+" in Congratulation Page");

    }
}
