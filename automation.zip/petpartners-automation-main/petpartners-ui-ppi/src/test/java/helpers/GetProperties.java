package helpers;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class GetProperties {
    private static GetProperties getProperties = null;
    private String urlWeb;
    private String user;
    private String password;
    private String browser;
    private String urlOrcaWeb;

    private String apiHost;
    private boolean generateGifImage;

    private boolean isEnabledOrcaMfa;

    private GetProperties() {
        Properties properties = new Properties();
        String propFileName = System.getProperty("propertyFile") == null ? "qa.properties" : System.getProperty("propertyFile");
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
        if (inputStream != null) {
            try {
                properties.load(inputStream);
                urlWeb = properties.getProperty("urlWeb");
                user = properties.getProperty("user");
                password = properties.getProperty("password");
                browser = properties.getProperty("browser");
                urlOrcaWeb = properties.getProperty("urlOrcaWeb");
                generateGifImage = Boolean.parseBoolean(properties.getProperty("generateGifImage"));
                apiHost = properties.getProperty("apiHost");
                isEnabledOrcaMfa = Boolean.parseBoolean(properties.getProperty("isEnabledOrcaMFA"));
                inputStream.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public static GetProperties getInstance() {
        if (getProperties == null)
            getProperties = new GetProperties();
        return getProperties;
    }

    public String getUrlWeb() {
        return urlWeb;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public String getBrowser() {
        return browser;
    }

    public String getUrlOrcaWeb() {
        return urlOrcaWeb;
    }

    public boolean isGenerateGifImage() {
        return generateGifImage;
    }

    public String getApiHost() {
        return apiHost;
    }

    public boolean isEnabledOrcaMfa() {
        return isEnabledOrcaMfa;
    }
}
