package runner;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import pages.ppi.GetQuotePage;
import pages.ppi.activateCertificate.DayPetInsuranceCoveragePage;

import java.util.Map;

public class ActivateCertificateStep extends  BaseSteps {
    DayPetInsuranceCoveragePage dayPetInsuranceCoveragePage = new DayPetInsuranceCoveragePage();
    GetQuotePage getQuotePage = new GetQuotePage();

    @And("click on Activate your 30-day pet insurance coverage link")
    public void clickOnActivateYourDayPetInsuranceCoverageLink() throws Exception {
        dayPetInsuranceCoveragePage.activateCertificate.click();
    }

    @When("filling the lookup - Your pet's quote section")
    public void fillingTheYourPetSQuoteSection( Map <String,String> input) throws Exception {
        if (this.replaceConfigurationValues(input.get("Look up activation")).equals("PetPartners Certificate")){
            getQuotePage.petpartnersCertificateRadioButton.click();
        }else{
            getQuotePage.akcReuniteEnrollmentRadioButton.click();
        }
        getQuotePage.activationCodeTextBox.setText(this.replaceConfigurationValues(input.get("ACTIVATION CODE")));
        getQuotePage.zipCodeCertificateTextBox.setText(this.replaceConfigurationValues(input.get("ZIP CODE")));
    }

    @And("click on the Look Up Pet expand button")
    public void clickOnTheLookUpPetExpandButton() throws Exception {
        dayPetInsuranceCoveragePage.lookUpPetExpandButton.click();
    }
}

