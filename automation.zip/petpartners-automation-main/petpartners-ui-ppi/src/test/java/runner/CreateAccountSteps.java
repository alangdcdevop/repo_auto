package runner;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.ppi.CreateAccountPage;
import pages.ppi.LoginPage;

import java.util.Map;

public class CreateAccountSteps extends BaseSteps{
    CreateAccountPage createAccountPage = new CreateAccountPage();
    LoginPage loginPage = new LoginPage();
    @Then("the create account page should be displayed")
    public void theCreateAccountPageShouldBeDisplayed() throws Exception {
        Assertions.assertTrue(createAccountPage.createAccountLabel.controlIsDisplayed(),"ERROR! the  create account page is not displayed");
    }
    @And("create a new account")
    public void createANewAccount(Map<String,String> values) throws Exception {
        loginPage.createAccountButton.click();
        createAccountPage.createAccount(this.replaceConfigurationValues(values.get("email")),
                this.replaceConfigurationValues(values.get("password")),
                this.replaceConfigurationValues(values.get("confirm password")));
    }
}
