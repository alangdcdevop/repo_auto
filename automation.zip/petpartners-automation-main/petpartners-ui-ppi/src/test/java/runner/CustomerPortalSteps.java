package runner;

import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.ppi.CustomerPortalMainPage;
import pages.ppi.landsOnPolicy.LeftMenuSection;

public class CustomerPortalSteps extends BaseSteps {
    CustomerPortalMainPage customerPortalMainPage = new CustomerPortalMainPage();
    LeftMenuSection leftMenuSection = new LeftMenuSection();

    @Then("the portal custom page should be displayed")
    public void thePortalCustomPageShouldBeDisplayed() throws Exception {
        leftMenuSection.homeMenu.controlIsClickable();
        leftMenuSection.homeMenu.click();
        leftMenuSection.claimsMenu.click();
        leftMenuSection.homeMenu.click();
        Assertions.assertTrue( customerPortalMainPage.welcomeCustomerLink.controlIsDisplayed(),"ERROR!! the Portal Customer PPI is not displayed, the control welcome customer is not displayed");
    }
}
