package runner;

import entities.ppi.CompleteEnrollmentEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;
import pages.ppi.CompleteYourEnrollment;
import pages.ppi.SelectTestCoverage;

import java.util.Map;

public class EnrollmentSteps extends BaseSteps {
    CompleteYourEnrollment completeYourEnrollment = new CompleteYourEnrollment();
    SelectTestCoverage selectTestCoverage = new SelectTestCoverage();

    @Then("the Complete your enrollment page should be open")
    public void theCompleteYoutEnrollmentPageShouldBeOpen() {
        Assertions.assertTrue(completeYourEnrollment.firstNameTextBox.controlIsDisplayed(), "ERROR the enrollment page is not displayed");
    }

    @And("I complete enrollment process on petpartners page")
    public void iCompleteEnrollmentProcessOnPetpartnersPage(CompleteEnrollmentEntity completeEnrollmentEntity) throws Exception {
        completeYourEnrollment.fillCompleteYourEnrollment(completeEnrollmentEntity);
        Thread.sleep(2000);

    }

    @DataTableType
    public CompleteEnrollmentEntity enrollmentEntityEntry(Map<String, String> entry) {
        CompleteEnrollmentEntity entity = new CompleteEnrollmentEntity();
        if (entry.containsKey("firstName"))
            entity.setFirstName(this.replaceConfigurationValues(entry.get("firstName")));
        if (entry.containsKey("lastName"))
            entity.setLastName(this.replaceConfigurationValues(entry.get("lastName")));
        if (entry.containsKey("address"))
            entity.setAddress(this.replaceConfigurationValues(entry.get("address")));
        if (entry.containsKey("apt suite"))
            entity.setAptSuite(this.replaceConfigurationValues(entry.get("apt suite")));
        if (entry.containsKey("phone number"))
            entity.setPhoneNumber(this.replaceConfigurationValues(entry.get("phone number")));
        if (entry.containsKey("name on card"))
            entity.setNameOnCard(this.replaceConfigurationValues(entry.get("name on card")));
        if (entry.containsKey("card number"))
            entity.setCardNumber(this.replaceConfigurationValues(entry.get("card number")));
        if (entry.containsKey("expires mm"))
            entity.setExpiresMM(this.replaceConfigurationValues(entry.get("expires mm")));
        if (entry.containsKey("expires yyyy"))
            entity.setExpireYYYY(this.replaceConfigurationValues(entry.get("expires yyyy")));
        if (entry.containsKey("cvc"))
            entity.setCvc(this.replaceConfigurationValues(entry.get("cvc")));
        if (entry.containsKey("email"))
            entity.setEmailAddress(this.replaceConfigurationValues(entry.get("email")));
        return entity;

    }


    @And("Complete the enrollment for certificate activation")
    public void completeTheEnrollmentForCertificateActivation() throws Exception {
        this.scrollDown();
        completeYourEnrollment.agreeApplicationRadioButton.click();
        if (completeYourEnrollment.byCheckingThisBoxRadioButton.controlIsDisplayed(10))
            completeYourEnrollment.byCheckingThisBoxRadioButton.click();
        completeYourEnrollment.enrollNowButton.click();

    }


    @And("select the checkin option in Complete your enrollment page")
    public void selectTheCheckinOptionInCompleteYourEnrollmentPage() throws Exception {
        completeYourEnrollment.agreeApplicationRadioButton.click();
    }

    @And("click on Enroll Now button")
    public void clickOnEnrollNowButton() throws Exception {
        completeYourEnrollment.enrollNowButton.click();
    }

    @And("click on {string} link in complete your enrollment page")
    public void clickOnLinkInCompleteYourEnrollmentPage(String lnkName) throws Exception {
        Thread.sleep(3000);
        if (lnkName.equals("Edit Plan Details"))
            completeYourEnrollment.editPlanDetailsLink.click();
        else if (lnkName.equals("Remove Plan"))
            completeYourEnrollment.removePlanLink.click();
        else if (lnkName.equals("Show Term Details"))
            completeYourEnrollment.showTermDetailsLink.click();
    }

    @And("Click {string} button in Remove Plan confirmation popup")
    public void clickButtonInRemovePlanConfirmationPopup(String sYesNo) throws Exception {
        Thread.sleep(2000);
        if (sYesNo.equals("Yes"))
            completeYourEnrollment.removePlanYesButton.click();
        else
            completeYourEnrollment.removePlanNoButton.click();
    }

    @Then("Verify {string} is displayed in complete your enrollment page")
    public void verifyIsDisplayedInCompleteYourEnrollmentPage(String sExpectedResult) throws Exception {
        Assertions.assertTrue(completeYourEnrollment.cartIsEmptyLabel.getText().contains(sExpectedResult),
                "ERROR: "+sExpectedResult+ " is not displayed");
    }

    @And("verify values {string},{string},{string},{string} in Selected Term Details")
    public void verifyValuesInSelectedTermDetails(String sDeductible, String sCoinsurance, String sIncident, String sAnnual) throws Exception {
        Assertions.assertTrue(completeYourEnrollment.showTermDeductible.getText().contains(sDeductible),
                "ERROR: "+sDeductible+ " is not displayed");
        Assertions.assertTrue(completeYourEnrollment.showTermCoinsurance.getText().contains(sCoinsurance),
                "ERROR: "+sCoinsurance+ " is not displayed");
        Assertions.assertTrue(completeYourEnrollment.showTermIncident.getText().contains(sIncident),
                "ERROR: "+sIncident+ " is not displayed");
        Assertions.assertTrue(completeYourEnrollment.showTermAnnual.getText().contains(sAnnual),
                "ERROR: "+sAnnual+ " is not displayed");

    }

    @And("Click Hide Term Details button and verify")
    public void clickHideTermDetailsButtonAndVerify() throws Exception {
        completeYourEnrollment.showTermDetailsLink.click();
    }
}
