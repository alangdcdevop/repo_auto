package runner;

import configuration.Configuration;
import entities.orca.MCleadCustomerDetail;
import entities.orca.MCleadPetDetail;
import helper.LoginHelper;
import helpers.GetProperties;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.Cookie;
import pages.orca.common.AlertSection;
import pages.orca.common.MenuSection;
import pages.orca.common.SubMenuSection;
import pages.orca.login.LoginPage;
import pages.orca.mclead.RegistrationMcleadPage;
import pages.orca.policy.PolicyDetailsPage;
import session.Session;
import utils.Level;
import utils.Logger;

import java.util.Map;


public class OrcaSteps extends BaseSteps {
    MenuSection menuSection = new MenuSection();
    PolicyDetailsPage policyDetailsPage= new PolicyDetailsPage();
    AlertSection alertSection= new AlertSection();
    LoginPage loginPage= new LoginPage();
    RegistrationMcleadPage registrationMcleadPage = new RegistrationMcleadPage();
    SubMenuSection subMenuSection= new SubMenuSection();

    @And("active the policy number: {string}")
    public void activeThePolicyNumber(String policyNumber) throws Exception {
        menuSection.optionMenu.get("Claims").click();
        menuSection.searchPoliciesTextBox.clearSetText(this.replaceConfigurationValues(policyNumber));
        menuSection.goButton.click();
        policyDetailsPage.statusSelect.selectValue("Active");
        Thread.sleep(3000);
        policyDetailsPage.saveButton.click();
        Thread.sleep(5000);
        policyDetailsPage.tabOptionLabelsMap.get("Customer(s)").click();
        Thread.sleep(5000);

    }

    @And("verify the message alert")
    public void verifyTheMessageDialog(String expectedResult) throws Exception {
        String actualResult = alertSection.successfullyAlertLabel.getText();
        expectedResult=this.replaceConfigurationValues(expectedResult);
        Assertions.assertTrue(actualResult.contains(expectedResult),
                "ERROR the message is not successfully, actual: [" + actualResult + "] vs expected: [" + expectedResult + "]");
    }

    @And("I am logged in Orca PetPartners")
    public void iAmLoggedInOrcaPetPartners() throws Exception {
        if (GetProperties.getInstance().isEnabledOrcaMfa()){
            // adding cookie to skip MFA
            String cookie = new LoginHelper().buildCookieInfoUser(GetProperties.getInstance().getApiHost(),
                    GetProperties.getInstance().getUser(),
                    GetProperties.getInstance().getPassword());
            Logger.log(Level.INFO, this.getClass().getName() + "adding the cookie: [userInfo] : ["+cookie+"]");
            Session.getInstance().getDriver().manage().addCookie(new Cookie("userInfo",cookie));
            Session.getInstance().getDriver().navigate().refresh();
            Thread.sleep(2000);
        }else{
            // classic login
            loginPage.loginSubStep(Configuration.USER,Configuration.PASSWORD);
        }
    }

    @When("adding a registration to Mclead")
    public void addingARegistrationToMclead() throws Exception {
        menuSection.optionMenu.get("Mclead").click();
        subMenuSection.optionSubMenu.get("Add Registration").click();
    }

    @And("filling the Mclead - PetDetails Sections")
    public void fillingTheMcleadPetDetailsSections(MCleadPetDetail mCleadPetDetail) throws Exception {
        registrationMcleadPage.fillPetDetailSection(mCleadPetDetail);
    }

    @And("filling the Mclead - Customer Details")
    public void fillingTheMcleadCustomerDetails(MCleadCustomerDetail mCleadCustomerDetail) throws Exception {
        registrationMcleadPage.fillCustomerDetailSection(mCleadCustomerDetail);
    }

    @And("click on Add Registration button in Mclead Page")
    public void clickOnAddRegistrationButtonInMcleadPage() throws Exception {
        this.scrollDown();
        registrationMcleadPage.addRegistrationButton.click();
    }

    @DataTableType
    public MCleadPetDetail mCleadPetDetailEntry(Map<String,String> entry){
        MCleadPetDetail entity = new MCleadPetDetail();
        entity.setRegistrationNo(this.replaceConfigurationValues(entry.get("Registration No")))
                .setRegistrationDate(this.replaceConfigurationValues(entry.get("Registration Date")))
                .setDateOfBirth(this.replaceConfigurationValues(entry.get("Date of Birth")))
                .setColor(this.replaceConfigurationValues(entry.get("Color")))
                .setMarketChannel(this.replaceConfigurationValues(entry.get("Market Channel")))
                .setPartner(this.replaceConfigurationValues(entry.get("Partner")))
                .setPetName(this.replaceConfigurationValues(entry.get("Pet Name")))
                .setSpecies(this.replaceConfigurationValues(entry.get("Species")))
                .setBreed(this.replaceConfigurationValues(entry.get("Breed")))
                .setGender(this.replaceConfigurationValues(entry.get("Gender")));
        return entity;
    }

    @DataTableType
    public MCleadCustomerDetail mCleadCustomerDetailEntry(Map<String,String> entry){
        MCleadCustomerDetail entity = new MCleadCustomerDetail();
        entity.setFirstName(this.replaceConfigurationValues(entry.get("First Name")))
                .setMiddleName(this.replaceConfigurationValues(entry.get("Middle Name")))
                .setLastName(this.replaceConfigurationValues(entry.get("Last Name")))
                .setAddress1(this.replaceConfigurationValues(entry.get("Address 1")))
                .setAddress2(this.replaceConfigurationValues(entry.get("Address 2")))
                .setCity(this.replaceConfigurationValues(entry.get("City")))
                .setStateProvince(this.replaceConfigurationValues(entry.get("State/Province")))
                .setPostalCode(this.replaceConfigurationValues(entry.get("Postal Code")))
                .setEmail(this.replaceConfigurationValues(entry.get("Email")))
                .setPhone(this.replaceConfigurationValues(entry.get("Phone")))
                .setSendEmail(this.replaceConfigurationValues(entry.get("Send Email")));
        return entity;
    }

    @And("verify the customer {} is displayed")
    public void verifyTheCustomerDefaultUserIsDisplayed(String email) {
        Assertions.assertTrue(policyDetailsPage.emailCustomer(this.replaceConfigurationValues(email)),"ERROR ! email: "+this.replaceConfigurationValues(email)+ "is not displayed in customer tab");
    }

}
