package runner;

import entities.ppi.ChangeCoverageEntity;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import pages.ppi.PortalCustomizeYourPlanPage;

import java.util.Map;

public class PortalCustomizeYourPlanSteps extends  BaseSteps {
    PortalCustomizeYourPlanPage portalCustomizeYourPlanPage = new PortalCustomizeYourPlanPage();

    @And("click on {string} option on available upgrades in ChangeCoverageOptions")
    public void clickOnOptionOnAvailableUpgradesInChangeCoverageOptions(String availableUpgradeOption) throws Exception {
        portalCustomizeYourPlanPage.radioButtonMap.get(availableUpgradeOption).click();

    }

    @And("customize coverage type and select options")
    public void fillCoverageDetails(ChangeCoverageEntity coverageEntityEntry) throws Exception {
        this.portalCustomizeYourPlanPage.fillCoverageOption(coverageEntityEntry);
    }

    @DataTableType
    public ChangeCoverageEntity changeCoverageEntity(Map<String, String> entry) {
        ChangeCoverageEntity entity = new ChangeCoverageEntity();
        entity.setPlanDetail(this.replaceConfigurationValues(entry.get("COVERAGE TYPE")))
                .setDeductible(this.replaceConfigurationValues(entry.get("DEDUCTIBLE")))
                .setCoinsurance(this.replaceConfigurationValues(entry.get("COINSURANCE")))
                .setAnnualLimit(this.replaceConfigurationValues(entry.get("ANNUAL LIMIT")));
        return entity;
    }

    @And("scrollDown window")
    public void scrollDownWindow() {
        this.scrollDown();
    }

    @And("click on {string} button in change coverage page")
    public void clickOnButtonInChangeCoveragePage(String addCartbutton) throws Exception {
        portalCustomizeYourPlanPage.addToCartButton.click();
        Thread.sleep(2000);
    }
}
