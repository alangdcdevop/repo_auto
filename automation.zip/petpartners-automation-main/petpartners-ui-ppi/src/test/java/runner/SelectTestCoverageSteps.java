package runner;

import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;
import pages.ppi.SelectTestCoverage;
import pages.ppi.yopEmailPages.MainEmailPage;
import session.Session;
import java.util.List;
import java.util.Map;
import entities.ppi.CoverageEntity;

public class SelectTestCoverageSteps extends  BaseSteps {
    SelectTestCoverage selectTestCoverage= new SelectTestCoverage();
    MainEmailPage mainEmailPage = new MainEmailPage();
    @Then("select {string} plan detail in pet coverage page")
    public void selectPlanDetailInEnrollPage(String option) throws Exception {
        selectTestCoverage.selectPlanDetail(option.toLowerCase());
    }

    @And("verify the expected result for the controls")
    public void verifyTheExpectedResultForTheControls(Map<String,String> expectedResultControl) throws Exception {
        String message="";
        Boolean areEqual=true;
        for (String control:expectedResultControl.keySet()) {
            String actualResult=selectTestCoverage.selectMap.get(control).getTextOptionDisable();
            String expectedResult= expectedResultControl.get(control);
            if (!actualResult.equals(expectedResult)){
                areEqual=false;
                message=message+"\nactual result: "+actualResult+ " [vs] expected result: "+expectedResult;
            }
        }

        Assertions.assertTrue(areEqual,"ERROR!!"+message);

    }

    @Then("verify the available upgrades should be displayed")
    public void verifyTheAvailableUpgradesShouldBeDisplayed(List<String> expectedControlDisplayed) {
        this.scrollDown();
        for (String control: expectedControlDisplayed) {
            Assertions.assertTrue(selectTestCoverage.radioButtonMap.get(control).controlIsDisplayed(),"ERROR the control: ["+control+"] is not displayed ");
        }
    }

    @And("click on {string} option on available upgrades")
    public void clickOnOptionOnAvailableUpgrades(String availableUpgradeOption) throws Exception {
         selectTestCoverage.radioButtonMap.get(availableUpgradeOption).click();

    }

    @And("click on {string} link in Policy Overview Section")
    public void clickOnLinkInPolicyOverviewSection(String emailQuote) throws Exception {
        selectTestCoverage.emailQuoteLink.click();
    }

    @And("click on {string} button on email quote dialog")
    public void clickOnButtonOnEmailQuoteDialog(String submitButton) throws Exception {
        selectTestCoverage.submitButton.click();
    }

    @Then("^Open your email in order to verify the (Quote Email|Welcome Email) from petpartners using \"(.*)\"$")
    public void openYourEmailInOrderToVerifyTheEmailFromPetpartners(String label,String email) throws Exception {
        mainEmailPage.emailNameTextBox.setText(this.replaceConfigurationValues(email));
        mainEmailPage.goButton.click();
        mainEmailPage.refreshButton.click();
        Thread.sleep(2000);
        Session.getInstance().getDriver().switchTo().frame("ifinbox");
        Assertions.assertTrue(mainEmailPage.emailSubjectLabel.controlIsDisplayed(),"ERROR! the email was not sent");
    }

    @And("click on {string} button in pet coverage page")
    public void clickOnButtonInPetCoveragePage(String addCartbutton) throws Exception {
        selectTestCoverage.addToCartButton.click();
        Thread.sleep(2000);
    }

    @Then("the message should be displayed")
    public void theMessageShoudBeDisplayed(String expectedResult) throws Exception {
        Thread.sleep(5000);
        String actualResult=selectTestCoverage.messageDialog.getText();
        Assertions.assertEquals(expectedResult,actualResult,"Error ! the message is wrong");
    }

    @And("click close button on dialog message")
    public void clickCloseButtonOnDialogMessage() throws Exception {
        selectTestCoverage.closeButton.click();
    }

    @Then("Open your YOPemail using {string}")
    public void openYourYOPemailUsing(String email) throws Exception {
        Thread.sleep(2000);
        mainEmailPage.emailNameTextBox.setText(this.replaceConfigurationValues(email));
        mainEmailPage.goButton.click();
        mainEmailPage.refreshButton.click();
        Thread.sleep(2000);
    }

    @And("check the PortalLogin button is displayed in the email")
    public void checkThePortalLoginButtonIsDisplayedInTheEmail() {
        Session.getInstance().getDriver().navigate().refresh();
        Session.getInstance().getDriver().switchTo().frame("ifmail");
        Assertions.assertTrue(mainEmailPage.portalLoginButton.controlIsDisplayed(),"ERROR! the portal login button is not displayed in the email");
    }

    @Then("verify the subject email")
    public void verifyTheSubjectEmail(String expectedResult) throws Exception {
        Session.getInstance().getDriver().switchTo().frame("ifmail");
        String actualResult=mainEmailPage.emailSubjectDetailLabel.getText();
        Assertions.assertEquals(this.replaceConfigurationValues(expectedResult),actualResult,"ERROR! the subject the email is wrong");
    }

    @And("click on Portal Login in email")
    public void clickOnPortalLoginInEmail() throws Exception {
        mainEmailPage.portalLoginButton.click();
    }

    @When("click in activate Initial Offer Only Button")
    public void clickInActivateInitialOfferOnlyButton() throws Exception {
        selectTestCoverage.activateInitialOfferOnly.click();
    }

    @And("i verify the policy overview")
    public void verifyDataPolicyOverview(Map<String,String> expectedResult) throws Exception {
        Assertions.assertTrue(selectTestCoverage.getBreedLabel(this.replaceConfigurationValues(expectedResult.get("PET BREED"))).controlIsDisplayed(),
                "ERROR the Pet Breed value is wrong, it is not displaying:"+this.replaceConfigurationValues(expectedResult.get("PET BREED")));
        Assertions.assertTrue(selectTestCoverage.getPetAgeLabel(this.replaceConfigurationValues(expectedResult.get("PET AGE"))).controlIsDisplayed(),
                "ERROR the Pet Age value is wrong, it is not displaying:"+this.replaceConfigurationValues(expectedResult.get("PET AGE")));
    }


    @And("i click on EDIT PET link on coverage page")
    public void iClickOnEDITPETLinkOnCoveragePage() throws Exception {
        selectTestCoverage.editPetLink.click();
        Thread.sleep(10000);    }



    @And("click on activateDayAndContinueCustomPlan on Select Pet Coverage Page")
    public void clickOnActivateDayAndContinueCustomPlanOnSelectPetCoveragePage() throws Exception {
        selectTestCoverage.activateCertAndContinueCustomPlan.click();
        Thread.sleep(3000);
    }

    @And("click on activateDayAndEnrollInAnnualPlan on Select Pet Coverage Page")
    public void clickOnActivateDayAndEnrollInAnnualPlanOnSelectPetCoveragePage() throws Exception {
        selectTestCoverage.activateAnnualPlan.click();
        Thread.sleep(2000);
    }

    @And("choose coverage type and select options")
    public void fillCoverageDetails(CoverageEntity coverageEntityEntry) throws Exception {
        this.selectTestCoverage.fillCoverageOption(coverageEntityEntry);
    }

    @DataTableType
    public CoverageEntity coverageEntity(Map<String, String> entry) {
        CoverageEntity entity = new CoverageEntity();
        entity.setPlanDetail(this.replaceConfigurationValues(entry.get("COVERAGE TYPE")))
                .setDeductible(this.replaceConfigurationValues(entry.get("DEDUCTIBLE")))
                .setCoinsurance(this.replaceConfigurationValues(entry.get("COINSURANCE")))
                .setAnnualLimit(this.replaceConfigurationValues(entry.get("ANNUAL LIMIT")));
        return entity;
    }

    @And("scrollUp window")
    public void scrollUpWindow() {
        this.scrollUp();
    }

}

